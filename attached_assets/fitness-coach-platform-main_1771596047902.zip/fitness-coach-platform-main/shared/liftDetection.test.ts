import { describe, it, expect } from "vitest";
import { detectMainLift, getAllKeywords } from "./liftDetection";

describe("detectMainLift", () => {
  it("detects squat variations", () => {
    expect(detectMainLift("Squat")).toBe("squat");
    expect(detectMainLift("squats")).toBe("squat");
    expect(detectMainLift("Back Squat")).toBe("squat");
    expect(detectMainLift("Squat Back")).toBe("squat");
    expect(detectMainLift("Front Squat")).toBe("squat");
    expect(detectMainLift("Squat Front")).toBe("squat");
    expect(detectMainLift("High Bar Squat")).toBe("squat");
    expect(detectMainLift("Squat High Bar")).toBe("squat");
    expect(detectMainLift("Low Bar Squat")).toBe("squat");
    expect(detectMainLift("Squat Low Bar")).toBe("squat");
    expect(detectMainLift("BARBELL SQUAT")).toBe("squat");
    expect(detectMainLift("Squat Barbell")).toBe("squat");
    expect(detectMainLift("BB Squat")).toBe("squat");
    expect(detectMainLift("Squat BB")).toBe("squat");
  });

  it("detects deadlift variations with flexible word order", () => {
    expect(detectMainLift("Deadlift")).toBe("deadlift");
    expect(detectMainLift("deadlifts")).toBe("deadlift");
    expect(detectMainLift("Sumo Deadlift")).toBe("deadlift");
    expect(detectMainLift("Deadlift Sumo")).toBe("deadlift");
    expect(detectMainLift("CONVENTIONAL DEADLIFT")).toBe("deadlift");
    expect(detectMainLift("Deadlift Conventional")).toBe("deadlift");
  });

  it("does not detect other deadlift variations", () => {
    expect(detectMainLift("Romanian Deadlift")).toBeNull();
    expect(detectMainLift("Stiff Leg Deadlift")).toBeNull();
    expect(detectMainLift("Trap Bar Deadlift")).toBeNull();
    expect(detectMainLift("Deficit Deadlift")).toBeNull();
    expect(detectMainLift("Block Deadlift")).toBeNull();
    expect(detectMainLift("Pause Deadlift")).toBeNull();
    expect(detectMainLift("RDL")).toBeNull();
  });

  it("detects bench press variations", () => {
    expect(detectMainLift("Bench Press")).toBe("bench");
    expect(detectMainLift("Bench")).toBe("bench");
    expect(detectMainLift("FLAT BENCH PRESS")).toBe("bench");
    expect(detectMainLift("Flat Bench")).toBe("bench");
    expect(detectMainLift("Incline Bench Press")).toBe("bench");
    expect(detectMainLift("Incline Bench")).toBe("bench");
    expect(detectMainLift("Decline Bench Press")).toBe("bench");
    expect(detectMainLift("Decline Bench")).toBe("bench");
    expect(detectMainLift("Close Grip Bench Press")).toBe("bench");
    expect(detectMainLift("CG Bench")).toBe("bench");
    expect(detectMainLift("Pause Bench")).toBe("bench");
    expect(detectMainLift("Paused Bench")).toBe("bench");
    expect(detectMainLift("TNG Bench")).toBe("bench");
    expect(detectMainLift("Touch And Go Bench")).toBe("bench");
    expect(detectMainLift("Barbell Bench Press")).toBe("bench");
    expect(detectMainLift("BB Bench Press")).toBe("bench");
  });

  it("returns null for non-main lifts", () => {
    expect(detectMainLift("Bicep Curl")).toBeNull();
    expect(detectMainLift("Lat Pulldown")).toBeNull();
    expect(detectMainLift("Leg Press")).toBeNull();
    expect(detectMainLift("Shoulder Press")).toBeNull();
    expect(detectMainLift("Lunges")).toBeNull();
    expect(detectMainLift("Rows")).toBeNull();
    expect(detectMainLift("Plank")).toBeNull();
  });

  it("is case-insensitive", () => {
    expect(detectMainLift("SQUAT")).toBe("squat");
    expect(detectMainLift("deadlift")).toBe("deadlift");
    expect(detectMainLift("BENCH PRESS")).toBe("bench");
    expect(detectMainLift("sQuAt")).toBe("squat");
  });

  it("handles whitespace", () => {
    expect(detectMainLift("  Squat  ")).toBe("squat");
    expect(detectMainLift("  Bench Press  ")).toBe("bench");
    expect(detectMainLift("  Sumo Deadlift  ")).toBe("deadlift");
  });
});

describe("getAllKeywords", () => {
  it("returns keywords for all three lifts", () => {
    const keywords = getAllKeywords();
    expect(keywords.squat.length).toBeGreaterThan(0);
    expect(keywords.deadlift.length).toBeGreaterThan(0);
    expect(keywords.bench.length).toBeGreaterThan(0);
  });
});
