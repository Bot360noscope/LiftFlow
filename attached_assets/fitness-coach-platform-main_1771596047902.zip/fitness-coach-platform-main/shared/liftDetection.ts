/**
 * Lift Detection Utility
 * 
 * Detects if an exercise name matches one of the 3 main lifts:
 * - Squat (including High Bar, Low Bar, Back, Front, Barbell variations)
 * - Deadlift (includes Sumo and Conventional - flexible word order)
 * - Bench Press
 * 
 * All matching is case-insensitive and handles flexible word ordering.
 */

export type MainLiftType = "squat" | "deadlift" | "bench";

/**
 * Detects if an exercise name matches a main lift.
 * Returns the lift type or null if no match.
 * Case-insensitive matching with flexible word ordering.
 */
export function detectMainLift(exerciseName: string): MainLiftType | null {
  // Normalize compound names: HighBarSquat → High Bar Squat
  let name = exerciseName.toLowerCase().trim();
  name = name.replace(/([a-z])([A-Z])/g, '$1 $2'); // camelCase → spaces
  name = name.toLowerCase();
  const words = name.split(/\s+/);

  // Check for SQUAT (including plurals)
  const hasSquat = words.some((w) => w === "squat" || w === "squats");
  if (hasSquat) {
    const validModifiers = ["high", "bar", "low", "back", "front", "barbell", "bb"];
    const hasValidModifier = words.some((w) => validModifiers.includes(w));
    if (words.length === 1 || hasValidModifier) {
      return "squat";
    }
  }

  // Check for DEADLIFT (including plurals)
  const hasDeadlift = words.some((w) => w === "deadlift" || w === "deadlifts");
  if (hasDeadlift) {
    const validModifiers = ["sumo", "conventional"];
    const hasValidModifier = words.some((w) => validModifiers.includes(w));
    if (words.length === 1 || hasValidModifier) {
      return "deadlift";
    }
  }

  // Check for BENCH PRESS
  const hasBench = words.includes("bench");
  if (hasBench) {
    const validModifiers = [
      "press",
      "flat",
      "incline",
      "decline",
      "close",
      "grip",
      "cg",
      "pause",
      "paused",
      "tng",
      "touch",
      "and",
      "go",
      "barbell",
      "bb",
    ];
    const hasValidModifier = words.some((w) => validModifiers.includes(w));
    if (words.length === 1 || hasValidModifier) {
      return "bench";
    }
  }

  return null;
}

/**
 * Returns all supported keywords grouped by lift type.
 * Useful for displaying to users.
 */
export function getAllKeywords(): Record<MainLiftType, string[]> {
  return {
    squat: [
      "squat",
      "squats",
      "high bar squat",
      "squat high bar",
      "low bar squat",
      "squat low bar",
      "back squat",
      "squat back",
      "front squat",
      "squat front",
      "barbell squat",
      "squat barbell",
      "bb squat",
      "squat bb",
    ],
    deadlift: [
      "deadlift",
      "deadlifts",
      "sumo deadlift",
      "deadlift sumo",
      "conventional deadlift",
      "deadlift conventional",
    ],
    bench: [
      "bench",
      "bench press",
      "flat bench",
      "flat bench press",
      "incline bench",
      "incline bench press",
      "decline bench",
      "decline bench press",
      "close grip bench",
      "close grip bench press",
      "cg bench",
      "pause bench",
      "paused bench",
      "touch and go bench",
      "tng bench",
      "barbell bench",
      "barbell bench press",
      "bb bench",
      "bb bench press",
    ],
  };
}
