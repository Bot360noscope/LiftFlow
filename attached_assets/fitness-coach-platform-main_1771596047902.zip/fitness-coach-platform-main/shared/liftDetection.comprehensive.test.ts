import { describe, it, expect } from "vitest";
import { detectMainLift } from "./liftDetection";

describe("detectMainLift - Comprehensive Variations", () => {
  describe("Front Squat variations", () => {
    it("detects front squat with spaces", () => {
      expect(detectMainLift("Front Squat")).toBe("squat");
      expect(detectMainLift("front squat")).toBe("squat");
      expect(detectMainLift("FRONT SQUAT")).toBe("squat");
      expect(detectMainLift("Squat Front")).toBe("squat");
      expect(detectMainLift("squat front")).toBe("squat");
    });

    it("detects front squat without spaces (compound)", () => {
      expect(detectMainLift("FrontSquat")).toBe("squat");
      expect(detectMainLift("frontsquat")).toBe("squat");
      expect(detectMainLift("SquatFront")).toBe("squat");
      expect(detectMainLift("squatfront")).toBe("squat");
    });

    it("detects front bar squat variations", () => {
      expect(detectMainLift("Front Bar Squat")).toBe("squat");
      expect(detectMainLift("FrontBarSquat")).toBe("squat");
      expect(detectMainLift("frontbarsquat")).toBe("squat");
      expect(detectMainLift("Squat Front Bar")).toBe("squat");
      expect(detectMainLift("Bar Front Squat")).toBe("squat");
    });
  });

  describe("Low Bar Squat variations", () => {
    it("detects low bar squat with spaces", () => {
      expect(detectMainLift("Low Bar Squat")).toBe("squat");
      expect(detectMainLift("low bar squat")).toBe("squat");
      expect(detectMainLift("LOW BAR SQUAT")).toBe("squat");
      expect(detectMainLift("Squat Low Bar")).toBe("squat");
      expect(detectMainLift("Bar Low Squat")).toBe("squat");
    });

    it("detects low bar squat without spaces (compound)", () => {
      expect(detectMainLift("LowBarSquat")).toBe("squat");
      expect(detectMainLift("lowbarsquat")).toBe("squat");
      expect(detectMainLift("SquatLowBar")).toBe("squat");
      expect(detectMainLift("squatlowbar")).toBe("squat");
    });
  });

  describe("High Bar Squat variations", () => {
    it("detects high bar squat with spaces", () => {
      expect(detectMainLift("High Bar Squat")).toBe("squat");
      expect(detectMainLift("high bar squat")).toBe("squat");
      expect(detectMainLift("Squat High Bar")).toBe("squat");
      expect(detectMainLift("Bar High Squat")).toBe("squat");
    });

    it("detects high bar squat without spaces (compound)", () => {
      expect(detectMainLift("HighBarSquat")).toBe("squat");
      expect(detectMainLift("highbarsquat")).toBe("squat");
      expect(detectMainLift("SquatHighBar")).toBe("squat");
    });
  });

  describe("Sumo Deadlift variations", () => {
    it("detects sumo deadlift with spaces", () => {
      expect(detectMainLift("Sumo Deadlift")).toBe("deadlift");
      expect(detectMainLift("sumo deadlift")).toBe("deadlift");
      expect(detectMainLift("SUMO DEADLIFT")).toBe("deadlift");
      expect(detectMainLift("Deadlift Sumo")).toBe("deadlift");
      expect(detectMainLift("deadlift sumo")).toBe("deadlift");
    });

    it("detects sumo deadlift without spaces (compound)", () => {
      expect(detectMainLift("SumoDeadlift")).toBe("deadlift");
      expect(detectMainLift("sumodeadlift")).toBe("deadlift");
      expect(detectMainLift("DeadliftSumo")).toBe("deadlift");
      expect(detectMainLift("deadliftsumo")).toBe("deadlift");
    });
  });

  describe("Close Grip Bench variations", () => {
    it("detects close grip bench with spaces", () => {
      expect(detectMainLift("Close Grip Bench")).toBe("bench");
      expect(detectMainLift("close grip bench")).toBe("bench");
      expect(detectMainLift("CLOSE GRIP BENCH")).toBe("bench");
      expect(detectMainLift("Close Grip Bench Press")).toBe("bench");
      expect(detectMainLift("Bench Close Grip")).toBe("bench");
      expect(detectMainLift("Bench Press Close Grip")).toBe("bench");
    });

    it("detects close grip bench without spaces (compound)", () => {
      expect(detectMainLift("CloseGripBench")).toBe("bench");
      expect(detectMainLift("closegripbench")).toBe("bench");
      expect(detectMainLift("BenchCloseGrip")).toBe("bench");
      expect(detectMainLift("benchclosegrip")).toBe("bench");
    });

    it("detects CG bench abbreviation", () => {
      expect(detectMainLift("CG Bench")).toBe("bench");
      expect(detectMainLift("cg bench")).toBe("bench");
      expect(detectMainLift("Bench CG")).toBe("bench");
      expect(detectMainLift("CG Bench Press")).toBe("bench");
    });
  });

  describe("Regular bench variations", () => {
    it("detects regular bench", () => {
      expect(detectMainLift("Bench")).toBe("bench");
      expect(detectMainLift("bench")).toBe("bench");
      expect(detectMainLift("Bench Press")).toBe("bench");
      expect(detectMainLift("bench press")).toBe("bench");
    });
  });

  describe("Edge cases and mixed variations", () => {
    it("handles extra whitespace", () => {
      expect(detectMainLift("  Front  Squat  ")).toBe("squat");
      expect(detectMainLift("  Sumo   Deadlift  ")).toBe("deadlift");
      expect(detectMainLift("  Close Grip  Bench  ")).toBe("bench");
    });

    it("handles mixed case compound words", () => {
      expect(detectMainLift("FrOnTsQuAt")).toBe("squat");
      expect(detectMainLift("SuMoDeAdLiFt")).toBe("deadlift");
      expect(detectMainLift("ClOsEgRiPbEnCh")).toBe("bench");
    });

    it("does not detect invalid variations", () => {
      expect(detectMainLift("Goblet Squat")).toBeNull();
      expect(detectMainLift("Romanian Deadlift")).toBeNull();
      expect(detectMainLift("Dumbbell Bench")).toBeNull();
      expect(detectMainLift("Leg Press")).toBeNull();
    });
  });
});
