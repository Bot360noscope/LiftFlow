SELECT id, name, email, role, userCode FROM users;
