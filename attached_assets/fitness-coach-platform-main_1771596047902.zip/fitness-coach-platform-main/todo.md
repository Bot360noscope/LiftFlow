# FitCoach Pro - Project TODO

## Phase 1: Database Schema & Planning
- [x] Design complete database schema for users, clients, programs, exercises, workouts, videos, chat
- [x] Create database migrations
- [x] Set up backend query helpers

## Phase 2: Coach Dashboard
- [x] Coach role assignment and authentication
- [x] Client management interface (add/view/manage clients)
- [x] Weekly program creation with Excel-like interface

## Phase 3: Client Workout Interface
- [x] Client authentication and profile
- [x] View assigned weekly program
- [x] Day selection interface (Day 1, 2, 3, etc.)
- [x] Exercise list with sets/reps display
- [x] "Done" button for each set completion
- [x] Weight input for each set
- [x] Workout session state management

## Phase 4: Video System
- [x] Video upload interface for clients
- [x] Link videos to specific exercises
- [x] S3 storage integration
- [x] Video library for coaches organized by client
- [x] Video library filtered by exercise type
- [x] Video playback interface

## Phase 6: Progress Tracking
- [x] Completed workout logging (auto-logs main lifts)
- [x] Weight progression tracking (manual PR entry)
- [x] Progress graphs and charts (Recharts visualization)
- [x] Historical data view (progress history table)
- [x] Personal records tracking (liftPRs table)
- [x] Note: 1RM calculations not implemented per user request

## Phase 7: Testing & Polish
- [x] Test coach workflow end-to-end
- [x] Test client workout flow
- [x] Test video upload and review
- [x] Test progress tracking accuracy
- [x] Create comprehensive vitest tests (22 tests passing)
- [x] Final checkpoint and deployment ready

## Current Work - User Requested Changes
- [x] Fix import errors in App.tsx
- [x] Build Excel-style program builder with inline editing
- [x] Add video categorization system
- [x] Implement category-based video filtering in library

## User Requested Changes - Session 2
- [x] Remove rest time field from program builder
- [x] Fix client adding functionality
- [x] Add user code generation system
- [x] Implement coach connection via user code
- [x] Add client code entry interface
- [x] Coach approval flow for new connections
- [x] Redesigned coach dashboard with spreadsheet-style layout
- [x] Updated client dashboard with coach connection interface

## Bug Fixes - Session 3
- [x] Fix program creation not working (fixed routing to /coach/program/new)
- [x] Fix client code connection not working (added userCode persistence and display)

## Excel-Style Rebuild - Session 4
- [x] Redesign database schema for Excel-sheet model (programs as blocks, weeks, days, exercises)
- [x] Create migration for new schema
- [x] Update backend query helpers for new structure
- [x] Update tRPC procedures for Excel-style data
- [x] Build Excel-style program builder (exercises as rows, days as columns)
- [x] Add inline editing for exercise cells (sets/reps)
- [x] Create coach dashboard with user code and program management
- [x] Create client dashboard with coach connection
- [x] Update routing for new structure
- [x] Implement completion checkboxes per exercise per day
- [x] Add client notes textbox per exercise per day
- [x] Create client view showing their program in Excel format
- [x] Test complete flow: create program, assign to client, client marks completion and adds notes

## Bug Fix - Coach Code Not Working
- [x] Fix role validation in connectToCoach
- [x] Ensure generateUserCode also sets coach role
- [x] Test complete flow: select coach role → generate code → client connects

## Temporary Changes - Session 5
- [x] Remove client requirement for creating programs
- [x] Allow coaches to create programs without selecting a client
- [x] Made clientId nullable in database schema
- [x] Continue debugging coach code connection issue

## Excel-Style Grid & Share Codes - Session 6
- [x] Review Excel file layout and structure
- [x] Add shareCode field to programBlocks table
- [x] Build Excel-style grid interface matching the provided file (free text cells)
- [x] Implement program share code generation and display
- [x] Update coach dashboard to remove coach code system
- [x] Create client dashboard with share code join
- [x] Create client program view with completion tracking and notes
- [x] Write vitest tests for auth and role-based access (7 tests passing)

## Coach Comments & Video - Session 7
- [x] Add coach comment column next to each exercise/week cell in program builder
- [x] Add video section per exercise/week in program builder (coach can view client videos)
- [x] Add optional video upload on client side per exercise/week (upload file or paste URL)
- [x] Update database with coachComment and videoUrl fields on exerciseCells
- [x] Add file upload endpoint for video storage (S3 via multer)

## Client-Program Linking & RPE - Session 8
- [x] Link clients with programs so clicking a client shows their program
- [x] Replace coach comment/notes column with RPE (Rate of Perceived Exertion)
- [x] Make client comments visible to coach in the program builder grid
- [x] Add notification ping/badge on client name when client adds a comment
- [x] Updated database schema (renamed coachComment to rpe, added coachLastViewedAt)
- [x] Set clientCommentedAt timestamp when client adds notes

## Delete Program Blocks - Session 9
- [x] Add delete procedure to backend (programBlocks.delete)
- [x] Add delete button to coach dashboard program list
- [x] Add delete button to program builder header
- [x] Add confirmation dialog before deletion

## Visual Bug Fix - Session 10
- [x] Fix Exercise column header being cut off in program builder (changed sticky left-10 to left-0)
- [x] Adjust column widths to ensure all text is fully visible

## Weight Column & Auto-Copy - Session 11
- [x] Add weight field to exerciseCells database schema (already existed)
- [x] Rename "Prescription" column header to "Sets/Reps"
- [x] Add "Weight" column to the left of Sets/Reps for each week
- [x] Implement auto-copy exercises (exercises automatically span all weeks by design)
- [x] Update backend procedures to handle weight field (already supported)
- [x] Update frontend to save weight field
- [x] Update client view to show weight column

## Bug Fix - Session 12
- [x] Fix useMemo import error in ProgramBuilder.tsx

## Program Structure Restructuring - Session 13
- [x] Flip the structure: exercises should span across WEEKS (not days)
- [x] Change tabs from "Day 1, Day 2" to "Week 1, Week 2, Week 3"
- [x] Change grid columns from "Week 1, Week 2" to "Day 1, Day 2, Day 3"
- [x] Each week shows the same exercises, but different days have different exercises
- [x] When adding exercise to Day 1, it auto-appears in Day 1 of all weeks
- [x] Update both ProgramBuilder and ClientProgram with new structure

## Bug Fix - Session 14
- [x] Fix useMemo import error in ClientProgram.tsx

## New Features - Session 15
- [x] Add logout button to navigation/header (already existed)
- [x] Add delete client functionality (backend procedure)
- [x] Add delete button to client list UI with confirmation dialog
- [x] Test logout and client deletion

## Bug Fix - Session 16
- [x] Fix nested button error in client list (delete button inside toggle button)

## New Feature - Session 17
- [x] Add "Add Client" button to coach dashboard
- [x] Add backend procedure to send client invite by email (inviteClient)
- [x] Add dialog to enter client email and send invite
- [x] Test adding clients directly without a program

## Feature Update - Session 18
- [x] Remove email invite system (inviteClient procedure)
- [x] Add coach code generation (similar to program share codes)
- [x] Replace "Add Client" button with "My Coach Code" button
- [x] Add code display and copy functionality
- [x] Add client-side "Join Coach" feature where clients enter coach code
- [x] Test coach code flow end-to-end

## Restructure - Session 19 - Cell-Level Exercise Names
- [x] Add exerciseName field to CellData (each cell has its own exercise name)
- [x] Add rowNumber field to database and backend
- [x] Move exercise name input from row header into each day's cell
- [x] Update save logic to save exercise name and rowNumber per cell
- [x] Update backend procedures to accept exerciseName and rowNumber
- [x] Remove dependency on exercises table for display (exercises now in cells)
- [x] Fix white line cutting through table header text (still needs fixing)
- [x] Update ClientProgram.tsx with same changes

## Session 20 - Client Layout & Auto-Copy
- [x] Update ClientProgram.tsx with same cell-level exercise layout as ProgramBuilder
- [x] Implement auto-copy: when exercise name is entered in Week 1, automatically copy to Week 2, 3, 4
- [x] Only copy exercise names, not weights/sets/reps (for progressive overload programming)

## Bug Fix - Session 21
- [x] Fix exercises not persisting after leaving the page
- [x] Investigate save logic for exercise cells
- [x] Ensure exerciseName and rowNumber are properly saved to database
- [x] Add blockId column to exerciseCells table
- [x] Update getBlockCells query to filter by blockId directly
- [x] Update upsert procedures to include blockId

## Bug Fix - Session 22 - Cells Overwriting Each Other
- [x] Fix upsert query missing rowNumber in WHERE clause
- [x] Cells were overwriting each other because query only checked exerciseId+weekNumber+dayNumber
- [x] Added rowNumber to WHERE clause so each cell is uniquely identified
- [x] Tested with multiple exercises - all save and load correctly now

## New Features - Session 23 - Auto-Save & Real-Time Notifications
- [x] Implement auto-save on cell blur (exercises save automatically when clicking away)
- [x] Add real-time polling for client notifications (coach dashboard checks for new comments every 10-15 seconds)
- [x] Display notification badges when clients add comments/videos
- [x] Test auto-save with multiple cells
- [x] Test real-time notifications on coach dashboard

## Bug Fix - Session 24 - Real-Time Notification Badge Not Appearing
- [x] Fix notification badge not appearing in real-time when client adds comments
- [x] Verify unreadComments query is refetching every 10 seconds
- [x] Check if badge updates after manual page refresh
- [x] Ensure polling works when page is in focus
- [x] Test end-to-end: client adds comment → coach sees badge within 10 seconds

## Session 25 - Multi-Client Testing & Client Weight Column
- [x] Fix client view to display weight column (already implemented in ClientProgram.tsx)
- [x] Test coach code generation with multiple clients (coach code RD9QJ2ZR generated successfully)
- [x] Create program and assign to multiple clients (Multi-Client Test Program created)
- [x] Test multiple clients connecting via coach code simultaneously
- [x] Test multiple clients marking completion and adding notes at the same time
- [x] Verify all data persists correctly for each client independently

## Session 26 - Live Camera Recording & Auto-Clear Notifications
- [x] Add markCommentsAsRead backend procedure
- [x] Implement live camera recording from phone with MediaRecorder API
- [x] Create CameraRecorder component with recording UI
- [x] Add camera recording button to client program video section
- [x] Integrate camera recording with existing video upload system
- [x] Fix blank video preview by adding muted attribute and object-cover class
- [x] Add auto-clear notification badge when coach opens client program
- [x] Add video compression to 720p before upload
- [x] Test camera recording on mobile devices

## Session 27 - Debug Camera Preview Blank Issue
- [x] Check browser console for errors when opening camera
- [x] Verify video element is receiving stream and playing
- [x] Debug canvas drawing loop with console logging
- [x] Test alternative canvas approach if needed

## Session 28 - Fix Camera Preview Refs Bug
- [x] Identified root cause: early returns for loading/error states unmounted video/canvas elements, making refs null
- [x] Rewrote CameraRecorder to always render video/canvas in DOM, using overlays for loading/error states
- [x] Camera preview now works correctly - confirmed by user

## Session 29 - Visual Exercise Completion Status
- [x] Change "Done" button behavior: mark exercise cell green when done, yellow when not done
- [x] Remove coach notification ping when client clicks "Done"
- [x] Update database to track completion status per exercise cell
- [x] Update ClientProgram UI to show green/yellow background based on completion
- [x] Update coach view to see completion status with green/yellow indicators
- [x] Client notes box: green (empty) if no comment, yellow with text if comment but not done, green with text if done


## Future Considerations - Mobile App & Infrastructure

### Option A: Capacitor App (Recommended - Keep Manus Backend)
- [x] Add Capacitor to existing React project
- [x] Configure for iOS and Android builds
- [x] Handle camera/microphone permissions for mobile
- [ ] Set up App Store and Google Play developer accounts
- [ ] Build and submit apps for review
- **Timeline:** 1-2 weeks
- **Benefit:** Keep all existing Manus infrastructure, just wrap as native app
- **Branding:** Only "Manus" visible during OAuth login, rest is fully branded

### Option B: Full Migration (Advanced - Remove Manus Entirely)
- [ ] Replace Manus OAuth with Google Sign-In
- [ ] Migrate database to Firebase Firestore or Supabase
- [ ] Move file storage to Cloudflare R2 or Google Cloud Storage
- [ ] Deploy backend to Cloudflare Workers or similar serverless
- [ ] Replace Manus LLM/notifications with Google/third-party services
- [ ] Build Capacitor app with new infrastructure
- **Timeline:** 3-4 weeks
- **Benefit:** Complete independence from Manus, full control
- **Complexity:** Significantly higher, requires infrastructure management

### Current Status
- Web app fully functional with Manus backend
- Camera recording working with canvas preview
- Visual completion status system (green/yellow/white indicators)
- Ready for mobile deployment whenever needed


## Session 30 - Video Download & Progress Tracking
- [x] Add download button to video display in ClientProgram
- [x] Add download button to video display in ProgramBuilder (coach view)
- [x] Create database schema for lift PRs (squats, deadlift, bench press)
- [x] Create Progress tab component for weight progression tracking
- [x] Build weight progression chart with 3 lines (squats, deadlift, bench)
- [x] Add manual PR entry section at bottom of Progress tab
- [x] Integrate Progress tab into ClientProgram (client view)
- [x] Integrate Progress tab into ProgramBuilder (coach view)
- [x] Deadlift includes both conventional and sumo as same data
- [x] Same view for both client and coach

## Session 31 - Move Progress Tab to Standalone User-Level Page
- [x] Remove Progress tab from ClientProgram (program view)
- [x] Remove Progress tab from ProgramBuilder (coach program view)
- [x] Create standalone Progress page at /client/progress and /coach/progress/:clientId
- [x] Add Progress navigation link to client dashboard
- [x] Add Progress navigation link to coach dashboard (per client)
- [x] Update ProgressTracker to work at user level, not program level


## Session 32 - Auto-Log Main Lifts from Program
- [x] Define keyword matching list for squat, deadlift, bench (case-insensitive)
- [x] Add server-side auto-log procedure that checks exercise name and logs to liftPRs
- [x] Update client "Done" handler to trigger auto-log when exercise matches a main lift
- [x] Keep manual entry on Progress page
- [x] Provide user with full keyword list
- [x] Add "Client Progress" button inside expanded client section on coach dashboard


## Session 33 - Add Coach Comment Input
- [x] Add coach comment input field in ProgramBuilder
- [x] Update database to store coach comments per exercise cell
- [x] Create tRPC procedure to save coach comments
- [x] Display coach comments to client in ClientProgram
- [x] Test end-to-end: coach enters comment → client sees it


## Bug Fix - Session 34 - Coach Comment Not Persisting
- [x] Debug autoSaveCell to check if coachComment is being sent to backend
- [x] Verify backend upsert procedure is saving coachComment to database
- [x] Check if coachComment is being loaded back from database correctly
- [x] Fixed: autoSaveCell was skipping save if only coachComment was filled (added coachComment to the check)
- [x] Fixed: upsertExerciseCell function in db.ts was not accepting coachComment parameter
- [x] Fixed: handleSave (Save All) was not sending coachComment in mutation and was skipping cells with only coachComment
- [x] Added coachCommentedAt to getBlockCells select statement for completeness


## UI Fixes & Polish
- [ ] Review and fix responsive layout issues on mobile devices
- [ ] Fix any overlapping or cut-off elements in program builder grid
- [ ] Ensure all buttons and inputs are properly sized for touch targets
- [ ] Review color contrast and readability across all pages
- [ ] Fix any scrolling issues in the Excel-style grid on smaller screens
- [ ] Ensure coach dashboard looks clean on both desktop and mobile
- [ ] Review client program view for mobile usability
- [ ] Fix any visual inconsistencies between coach and client views
- [x] Clean up console.log statements left from debugging
- [ ] Review loading states and error handling across all pages

## Freemium Model - Coach Client Limit
- [ ] Add client count tracking per coach (query coach's connected clients)
- [ ] Set free tier limit to 1 client per coach
- [ ] When coach tries to add a 2nd client, show popup/modal instead of adding
- [ ] Popup message: "You've reached your free client limit. Upgrade to add more clients."
- [ ] Popup includes button that opens external payment website (not embedded Stripe)
- [ ] Use window.open or Capacitor Browser plugin to redirect to payment site
- [ ] No in-app payment processing (Apple App Store compliant)
- [ ] After payment confirmed on external site, update coach's plan/tier in database
- [ ] Add plan/tier field to users table (free, premium, etc.)
- [ ] Gate "Add Client" / "Join Coach Code" behind client limit check
- [ ] Show current plan status somewhere on coach dashboard

## Capacitor App Store Preparation
- [x] Replace MediaRecorder VP9/WebM with HTML5 file input for mobile video capture
- [x] Fix OAuth flow to work with Capacitor URL scheme (Browser plugin)
- [x] Replace window.open downloads with Capacitor Browser plugin
- [x] Add NSCameraUsageDescription and NSMicrophoneUsageDescription to Info.plist
- [ ] Add Privacy Policy page
- [ ] Test full app flow in Capacitor iOS simulator

## Session 35 - UI Redesign (MyFitnessPal Green Theme)
- [x] Restyle global theme with MyFitnessPal-inspired green color palette
- [x] Client dashboard: make Join Coach and Join Program compact buttons (not full sections)
- [x] Client dashboard: make My Progress open directly (like My Programs)
- [x] Restyle coach dashboard to match new theme
- [x] Restyle ProgramBuilder and ClientProgram pages
- [x] Restyle Home/landing page
- [x] Clean up console.log statements
- [x] Fix responsive layout issues

## Session 36 - Rename to LiftFlow
- [x] Rename all "FitCoach Pro" references to "LiftFlow" across codebase
- [x] Update HTML title tag
- [x] Update VITE_APP_TITLE secret (built-in, updated via HTML title instead)

## Session 37 - Premium Tier System (Coach Client Limit)
- [x] Add `plan` field to users table (free/premium)
- [x] Generate database migration SQL for plan field
- [x] Apply migration via webdev_execute_sql
- [x] Create billing webhook endpoint for payment site callback
- [x] Add BILLING_WEBHOOK_SECRET environment variable
- [x] Add client count query in backend
- [x] Gate "Add Client" behind plan limit check
- [x] Build UpgradeModal component
- [x] Show upgrade modal when coach hits client limit
- [x] Write tests for billing webhook and client limits
- [x] Document webhook URL and secret for payment site integration

## Session 38 - Branding Fixes
- [x] Fix website title header from "FitCoach Pro" to "LiftFlow"
- [x] Replace black profile icon with green LiftFlow wave logo
- [x] Add client limit check to accept request flow (not just coach code generation)

## Session 39 - Fix Client Limit Enforcement
- [x] Debug why client limit is not enforcing (coaches can still add unlimited clients)
- [x] Identify all paths where coaches can add clients
- [x] Add server-side validation to acceptRequest and other client addition endpoints
- [x] Verify planStatus query returns correct clientCount (now only counts active clients)
- [x] Test all flows to ensure limit is enforced

## Session 40 - Update Favicon and Browser Title
- [x] Create LiftFlow favicon with wave logo
- [x] Update HTML to use new favicon
- [x] Verify browser tab title shows "LiftFlow"

## Session 41 - Add Plan Badge to Coach Header
- [x] Add plan status badge to coach dashboard header showing "Free (X/1)" or "Premium"

## Session 41 - Plan Badge and Program Count Fix
- [x] Fix program count not updating when deleting programs
- [x] Add plan status badge to coach dashboard header showing "Free (X/1)" or "Premium"

## Future Features
- [ ] Video compression - compress uploaded videos to reduce storage and bandwidth
- [x] Search button for coaches on client tab - filter/search through client list
- [ ] Auto-sort clients by recent activity - when client sends notification, move to top of list

## Session 42 - Support All Payment Tiers
- [x] Update database schema to support new tier names (free, per_user, per_user_10, enterprise)
- [x] Add userCount field to users table for per_user tier
- [x] Update getMyPlanStatus to return correct limits for each tier
- [x] Update plan badge to show tier-specific limits
- [x] Update billing webhook to handle all tier types and userCount
- [x] Update client limit enforcement to respect tier-specific limits

## Session 43 - Bug Fixes and Delete Data
- [x] Fix: Premium badge showing even for free tier users (badge logic checks plan !== 'free', should work correctly - may be browser cache)
- [x] Fix: Deleted programs still counted in program count (changed to refetch instead of optimistic update)
- [ ] Add delete account data function (delete all user data including programs, clients, videos, PRs)

## Session 44 - Fix Favicon and Logo SVGs
- [x] Fix favicon SVG rendering (crunched/distorted)
- [x] Fix logo SVG in header (crunched/distorted)

## Session 45 - Connect Payment Site
- [x] Update UpgradeModal to redirect to https://liftflowpay.manus.space/pricing
- [x] Simplify upgrade messaging (no pricing details, just "upgrade to add more clients")

## Session 45 - Fix Logo and Site Title
- [x] Change logo from wavy line to EKG/heartbeat style (sharp peaks like ⚡)
- [x] Fix site title from "FitCoach Pro" to "LiftFlow" everywhere (already done, browser cache issue)
- [x] Update UpgradeModal to redirect to https://liftflowpay.manus.space/pricing
- [x] Simplify upgrade messaging

## Session 46 - Client Search and Delete Account
- [x] Add client search bar in coach dashboard (filter by name/email)
- [x] Create backend endpoint to delete all user data
- [x] Add "Delete All My Data" button in coach/client dashboard
- [x] Confirm deletion with warning dialog

## Session 36 - Bug Fixes & Client Search
- [x] Fixed syntax errors in CoachDashboard.tsx (duplicate Search import, missing Dialog imports)
- [x] Fixed server/db.ts errors (missing sql import, missing liftPRs import, duplicate liftPRs import)
- [x] Added deleteAllUserData function to db.ts for future GDPR compliance
- [x] Implemented client search feature - search bar above client list to filter by name or email
- [ ] Delete account data feature (backend endpoint and UI) - removed incomplete implementation, to be added later

## Session 36 Continued - Client Search Bug
- [x] Fix client search not showing results - was filtering wrong data source (clients vs clientPrograms)
- [x] Moved filteredClients definition after clientPrograms to fix declaration order

## Session 36 - Client Search Empty State
- [x] Fix empty state message - now shows "No clients found" with search term when search has no results vs "No clients yet" when truly empty

## Session 36 - Client Search Still Broken
- [x] Fixed client search - filter was using wrong field names (name/email instead of clientName/clientEmail)

## Session 36 - Delete Account/Data Feature
- [x] Add backend tRPC endpoint for deleting all user data (account.deleteAllData)
- [x] Add delete account button and confirmation dialog to CoachDashboard
- [x] Add delete account button and confirmation dialog to ClientDashboard

## Session 36 - LiftFlow Icon Bug
- [x] Fixed LiftFlow icon - replaced old heartbeat SVG and Activity icon with clean dumbbell/barbell icon across all pages

## Session 36 - Restore Heartbeat Icon
- [x] Restored heartbeat/EKG icon and fixed the straight line rendering bug

## Session 36 - Match Exact Icon from Screenshot
- [x] Matched LiftFlow icon exactly to user's screenshot using the official Lucide Activity icon SVG path

## Session 36 - iOS/App Store Compatibility Audit
- [x] Audit MediaRecorder API usage - NOT SUPPORTED on iOS, blocks video recording
- [x] Check OAuth flow - needs Capacitor Browser plugin for mobile
- [x] Review file download/upload - window.open() limited on iOS
- [x] Check for iOS-incompatible web APIs - found 3 critical blockers
- [x] Document all compatibility issues and fixes needed - report created

## Session 36 - Capacitor iOS/Android Setup
- [x] Install Capacitor core, CLI, iOS, Android, Camera, Filesystem, Browser plugins
- [x] Initialize Capacitor and create iOS/Android projects
- [x] Replace MediaRecorder with HTML5 file input for mobile video capture
- [x] Fix OAuth flow for mobile platforms with Browser plugin
- [x] Fix file downloads with Capacitor Browser plugin
- [x] Configure iOS permissions (camera, microphone, photo library)
- [x] Create comprehensive iOS setup instructions (IOS_SETUP.md)

## Session 36 - Mobile Video Preview UX
- [x] Add video preview with thumbnail after recording
- [x] Add "Use This" button to confirm and upload
- [x] Add "Retake" button to record again

## Session 36 - Video Upload Bug
- [ ] Debug why video upload is greyed out for self-created programs
- [ ] Fix logic to allow video uploads without requiring a coach

## Session 36 - Web Video Preview & Trimming
- [x] Add preview/confirm/retake flow to web version (no longer auto-uploads)
- [x] Add video trimming UI with start/end time sliders
- [x] Implement video trimming logic using ffmpeg.wasm
- [x] Test on both web and mobile - all 29 tests passing

## Session 36 - Blank Preview on Second Recording
- [x] Fix video preview going blank when recording a second time
- [x] Ensure proper cleanup and state reset between recordings (reset trimming state in handleRetake)

## Session 36 - Black Preview Still Happening & Remove Video
- [x] Fix persistent black preview on second recording - restart canvas preview in handleRetake
- [x] Add remove/delete button for uploaded videos in ClientProgram and ProgramBuilder

## Session 36 - Retake Button Error
- [x] Fix "Video or canvas ref missing" error - added canvasRef check in handleRetake

## Session 36 - Persistent Black Preview (Still Not Fixed)
- [x] Deep debug black preview - root cause: canvas removed from DOM during preview, stream disconnected from video element. Fixed by re-attaching stream and using double requestAnimationFrame to wait for DOM update
- [x] Update Capacitor checklist items in todo.md

## Session 36 - Privacy Policy & Video Compression
- [x] Create privacy policy popup component covering all data practices (12 sections)
- [x] Add privacy policy link to Home page footer, CoachDashboard, and ClientDashboard
- [x] Analyze current video file sizes and compression benefits
- [x] Report on video compression cost/benefit

## Session 36 - Terms of Service
- [x] Create Terms of Service popup component (13 sections)
- [x] Add ToS link to Home page footer, CoachDashboard, and ClientDashboard

## Session 36 - Custom Privacy Policy
- [x] Replace generic privacy policy with user's custom legal-reviewed text (Sam Albaayno, GDPR, Stripe, Apple-compliant)
- [x] Replace Terms of Service with user's custom legal-reviewed text (Sam Albaayno, England & Wales, Stripe, Apple-compliant)

## Session 36 - Subscription Info & Expiry Handling
- [x] Investigate current subscription/billing logic and what happens on expiry
- [x] Add planExpiresAt column to users table for subscription expiry tracking
- [x] Add account freeze logic - block coach dashboard if expired + more clients than free allows
- [x] Show freeze overlay with "remove clients or upgrade" message
- [x] Add tier badge in corner showing current plan + time remaining
- [x] Add clickable tier badge that opens package options popup (Free, Pro 10, Enterprise)
- [x] Update Terms of Service with subscription tier details and expiry policy
- [x] Update billing webhook to accept durationDays and calculate expiry date
- [x] Write vitest tests for subscription expiry handling (10 tests passing)

## Session 37 - Tier Badge Improvements
- [x] Show Per User tier as "Per User (6/6 clients)" in tier badge with actual client count/limit
- [x] Show expiry date in the package selection modal when clicking tier badge
- [x] Added Per User tier to package selection modal alongside Free, Pro 10, Enterprise

## Session 37 - Stacking Subscription Purchases
- [x] Make per_user and per_user_10 purchases stack (e.g. 10-pack + 4 per-user = 15 total with 1 free)
- [x] Update billing webhook to add userCount instead of overwriting (addUserSlots function)
- [x] Update client limit calculation to use stacked total (1 free + all purchased)
- [x] Update TierBadge to show combined total correctly
- [x] Write tests for stacking logic (5 new stacking tests, 44 total passing)

## Session 38 - Capacitor Mobile App Setup
- [x] Install Capacitor core and CLI packages
- [x] Initialize Capacitor with iOS and Android platforms (already existed)
- [x] Configure capacitor.config.ts with app metadata and push notification settings
- [x] Add native camera plugin (@capacitor/camera) and filesystem plugin
- [x] Add push notifications plugin (@capacitor/push-notifications)
- [x] Create push notifications utility (initializePushNotifications, getDeliveredNotifications, etc.)
- [x] Add Sign in with Apple plugin (@capacitor-community/apple-sign-in)
- [x] Create Apple Sign In utility (signInWithApple, isAppleSignInAvailable)
- [x] Install Capacitor assets plugin for icon/splash generation (@capacitor/assets)
- [x] Create comprehensive mobile deployment guide (MOBILE_DEPLOYMENT.md)
- [x] Create App Store metadata file with description, keywords, screenshots (APP_STORE_METADATA.md)
- [x] Create platform detection utility (isNativePlatform in nativeCamera.ts)
- [ ] Update video upload UI to use native camera on mobile (requires UI integration)
- [ ] Test iOS build with Xcode (requires Mac)

## Session 39 - Simplify Tier Badge Modal
- [x] Remove package selection UI from TierBadge modal
- [x] Show only current plan info (name, expiry, client count)
- [x] Replace package cards with single "Upgrade Plan" button linking to payment site
- [x] Keep same payment site URL with userId and email params
- [x] Reduced TierBadge from 425 lines to 228 lines (46% smaller)

## Session 40 - Performance Tab Mobile Fixes
- [x] Fix date section mobile layout (changed from 4-column to 2-column grid on mobile)
- [x] Fix date section overlapping notes (moved Notes to separate full-width row)
- [x] Add high bar squat to lift detection (already supported, added camelCase normalization)
- [x] Add low bar squat to lift detection (already supported, added camelCase normalization)
- [x] Add sumo deadlift to lift detection (already supported)
- [x] Fix duplicate PR logging (added deduplication: checks clientId + liftType + date)
- [x] Only log highest weight per exercise per day (updates existing PR if new weight is higher)

## Session 41 - Expand Lift Detection Variations
- [ ] Add all front squat variations (frontsquat, front squat, squat front, etc.)
- [ ] Add all low bar squat variations (lowbarsquat, low bar squat, squat low bar, etc.)
- [ ] Add all sumo deadlift variations (sumodeadlift, sumo deadlift, deadlift sumo, etc.)
- [ ] Add all close grip bench variations (closegripbench, close grip bench, cg bench, etc.)
- [ ] Handle compound words with no spaces (frontbarsquat, lowbarsquat, etc.)
- [ ] Write tests for all new variations

## Session 42 - Copy-on-Share for Programs
- [x] Add logic to detect if program is being shared vs created new (joinByShareCode)
- [x] Implement program cloning function (cloneProgramBlock in db.ts)
- [x] When sharing existing program, create independent copy for client
- [x] Keep original program in coach's programs list (template stays unassigned)
- [x] Update share UI - renamed "Unassigned Programs" to "Program Templates" with "Reusable" badge
- [x] Added "Shareable" indicator for templates with share codes
- [x] Client automatically becomes coach's client when joining via share code

## Session 43 - Fix Inflated Client Count Bug
- [x] Investigate why tier badge shows 36 clients instead of actual count (userCount = 35, not clientCount)
- [x] Check for duplicate coach-client relationships in database (no duplicates found)
- [x] Reset userCount to 0 for test account
- [x] Fix delete all data function to delete ALL user data:
  - Programs where user is coach (coachId) ✓
  - Programs where user is client (clientId) ✓
  - Exercise cells in those programs ✓
  - Lift PRs (clientId) ✓
  - Coach-client relationships (both coachId and clientId) ✓
  - Videos (clientId and coachId) ✓
  - Chat messages (senderId and receiverId) ✓
  - User account itself (full deletion) ✓

## Session 44 - Delete Confirmation Modal
- [x] Create confirmation modal component with DELETE text input
- [x] Add scary warning message about permanent deletion (red warning box with ⚠️)
- [x] Disable delete button until user types "DELETE" exactly
- [x] Update CoachDashboard to use confirmation modal
- [x] Reset confirmation text when modal closes or after deletion

## Session 45 - Auto-Delete Videos (2 Weeks After View OR 1 Month)
- [x] Add viewedAt timestamp to videos table
- [x] Track when coach views a video (markVideoViewed sets viewedAt on first view)
- [x] Create cleanup procedure to find videos meeting deletion criteria:
  - 2 weeks after viewedAt (if coach viewed), OR
  - 1 month after createdAt (regardless of view status)
- [x] Delete S3 files when deleting video records (storageDelete function)
- [x] Add API endpoint to trigger cleanup (videos.cleanup mutation)
- [x] Write tests for video cleanup logic (8 tests, 61 passing)

## Session 46 - Weight Carry-Forward Placeholder
- [x] Find where weight placeholder is set (ProgramBuilder.tsx line 537)
- [x] Create getWeightPlaceholder helper function to fetch previous week's weight
- [x] Update weight input placeholder to use dynamic value from previous week
- [x] Keep placeholder behavior (gray text, disappears when coach types)
- [x] Logic: Week 1 shows "e.g. 135 lbs", Week 2+ shows previous week's actual weight

## Session 47 - Move Privacy/Terms Links to Bottom Right
- [x] Find where Privacy Policy and Terms of Service links are currently placed (Home, CoachDashboard, ClientDashboard footers)
- [x] Move links to right side of footer using flex justify-between
- [x] Updated all three pages: Home.tsx, CoachDashboard.tsx, ClientDashboard.tsx
- [x] Links now appear on right side, Delete button on left

## Session 48 - Fix Program Count on Client Deletion
- [x] Find where client deletion happens (deleteCoachClientRelation in db.ts)
- [x] Update deletion logic to also remove client's program copies
- [x] Delete exercise cells for client programs before deleting programs
- [x] Ensure program count updates correctly after client deletion
- [x] Write 4 comprehensive tests for client deletion (all passing)
- [x] Test: Create template → share with client (2 programs) → delete client (1 program remains)

## Session 49 - Rebrand to LiftFlow
- [ ] Update VITE_APP_TITLE from "FitCoach Pro" to "LiftFlow"
- [ ] Update login page heading from "Sign up to FitCoach Pro" to "Sign up to LiftFlow"
- [ ] Find and use existing LiftFlow logo (heartbeat icon + text)
- [ ] Generate favicon from LiftFlow logo
- [ ] Update any other "FitCoach Pro" references to "LiftFlow"

## Session 43 - Capacitor Rebranding
- [x] Update Capacitor config appId from com.fitcoachpro.app to com.liftflow.app
- [x] Update Capacitor config appName from FitCoach Pro to LiftFlow

## Session 44 - Fix Subscription Upgrade Not Reflecting
- [x] Debug billing webhook to check if payment notifications are received
- [x] Verify webhook is updating user subscription in database
- [x] Create REST webhook endpoint at /api/webhooks/payment for payment site
- [x] Test end-to-end payment flow

## Session 45 - Migrate to Subscription-Based Payments
- [x] Add subscriptionStatus field to users table schema
- [x] Generate and apply database migration
- [x] Update webhook endpoint to accept subscription payload (status, periodEnd, absolute userCount)
- [x] Update webhook logic to set total slots instead of adding slots
- [x] Handle subscription status (active, canceled, past_due)
- [x] Update database functions to use absolute slot setting
- [x] Test webhook with subscription data

## Session 46 - Simplify to Fixed Tiers (Annual Only)
- [x] Update plan enum to: free, starter, growth, professional, enterprise
- [x] Update webhook to map plan names to slot counts
- [x] Update TierBadge to show new tier names
- [x] Remove per_user and per_user_10 references
- [x] Update all client limit logic for 5 tiers

## Session 47 - Fix Webhook 500 Error
- [x] Check webhook logs for error details
- [x] Fix webhook handler to map payment site tier names (tier_5, tier_10, tier_25) to LiftFlow plans
- [ ] Test webhook with payment site
- [ ] Verify account upgrades successfully
