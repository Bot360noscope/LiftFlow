# Mobile App Deployment Guide

This guide explains how to build and deploy the LiftFlow mobile app to the Apple App Store and Google Play Store.

## Prerequisites

### For iOS (App Store)
- **Mac computer** with macOS (required for Xcode)
- **Xcode** 15+ installed from the Mac App Store
- **Apple Developer Account** ($99/year) - [Sign up here](https://developer.apple.com/programs/)
- **CocoaPods** installed: `sudo gem install cocoapods`

### For Android (Play Store)
- **Android Studio** installed
- **Google Play Developer Account** ($25 one-time fee) - [Sign up here](https://play.google.com/console/signup)
- **Java Development Kit (JDK)** 17+

---

## Step 1: Build the Web App

Before building the mobile app, you need to build the web app first:

```bash
cd /home/ubuntu/fitness-coach-platform
pnpm build
```

This creates the `dist/client` folder that Capacitor will wrap.

---

## Step 2: Sync Native Projects

After building, sync the web assets to the native projects:

```bash
pnpm exec cap sync
```

This copies the built web app into the `ios/` and `android/` folders.

---

## Step 3: iOS Build & Deployment

### 3.1 Open Xcode

```bash
pnpm exec cap open ios
```

This opens the iOS project in Xcode.

### 3.2 Configure Signing & Capabilities

1. In Xcode, select the **App** target (not the Pods project)
2. Go to **Signing & Capabilities** tab
3. Select your **Team** (your Apple Developer account)
4. Xcode will automatically create a **Bundle Identifier**: `com.liftflow.app`
5. Enable these capabilities:
   - **Push Notifications**
   - **Sign in with Apple**

### 3.3 Configure Push Notifications (APNs)

1. Go to [Apple Developer Portal](https://developer.apple.com/account/)
2. Navigate to **Certificates, Identifiers & Profiles**
3. Create an **APNs Key**:
   - Click **Keys** → **+** button
   - Name it "LiftFlow Push Notifications"
   - Enable **Apple Push Notifications service (APNs)**
   - Download the `.p8` key file (save it securely!)
   - Note the **Key ID** and **Team ID**
4. In your backend, configure APNs with the downloaded key

### 3.4 Add App Icons & Splash Screens

1. Create a 1024x1024px app icon (PNG, no transparency)
2. Save it as `resources/icon.png` in the project root
3. Create a 2732x2732px splash screen
4. Save it as `resources/splash.png`
5. Run: `pnpm exec capacitor-assets generate`

This automatically generates all required icon sizes for iOS and Android.

### 3.5 Build for TestFlight

1. In Xcode, select **Any iOS Device (arm64)** as the build target
2. Go to **Product** → **Archive**
3. Wait for the build to complete
4. Click **Distribute App** → **App Store Connect** → **Upload**
5. Once uploaded, go to [App Store Connect](https://appstoreconnect.apple.com/)
6. Select your app → **TestFlight** tab
7. Add internal testers and send them the build

### 3.6 Submit to App Store

1. In App Store Connect, go to **App Store** tab
2. Fill in:
   - **App Name**: LiftFlow
   - **Subtitle**: AI-Powered Fitness Coaching
   - **Description**: (write a compelling description)
   - **Keywords**: fitness, coaching, workout, AI, form analysis
   - **Support URL**: https://liftflow.manus.space/support
   - **Privacy Policy URL**: https://liftflow.manus.space/privacy
   - **Screenshots**: (take 5-8 screenshots on iPhone and iPad)
3. Select the TestFlight build
4. Click **Submit for Review**
5. Wait 1-3 days for Apple's review

---

## Step 4: Android Build & Deployment

### 4.1 Open Android Studio

```bash
pnpm exec cap open android
```

### 4.2 Configure Signing

1. Create a keystore file:
```bash
keytool -genkey -v -keystore liftflow-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias liftflow
```

2. Edit `android/app/build.gradle`:
```gradle
android {
    ...
    signingConfigs {
        release {
            storeFile file("../../liftflow-release-key.jks")
            storePassword "YOUR_KEYSTORE_PASSWORD"
            keyAlias "liftflow"
            keyPassword "YOUR_KEY_PASSWORD"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            ...
        }
    }
}
```

### 4.3 Build Release APK/AAB

```bash
cd android
./gradlew bundleRelease
```

The `.aab` file will be in `android/app/build/outputs/bundle/release/app-release.aab`

### 4.4 Upload to Google Play Console

1. Go to [Google Play Console](https://play.google.com/console/)
2. Create a new app
3. Fill in app details (name, description, screenshots)
4. Go to **Production** → **Create new release**
5. Upload the `.aab` file
6. Fill in release notes
7. Click **Review release** → **Start rollout to Production**
8. Wait 1-3 days for Google's review

---

## Step 5: Configure Backend for Mobile

### 5.1 Store Push Notification Tokens

When a user installs the mobile app, their device token needs to be stored in your database:

```typescript
// In your tRPC router
savePushToken: protectedProcedure
  .input(z.object({ token: z.string(), platform: z.enum(['ios', 'android']) }))
  .mutation(async ({ input, ctx }) => {
    await db.savePushToken(ctx.user.id, input.token, input.platform);
    return { success: true };
  }),
```

### 5.2 Send Push Notifications

Use APNs for iOS and FCM for Android. Example with `node-apn`:

```typescript
import apn from 'apn';

const apnProvider = new apn.Provider({
  token: {
    key: process.env.APNS_KEY_PATH,
    keyId: process.env.APNS_KEY_ID,
    teamId: process.env.APNS_TEAM_ID,
  },
  production: true,
});

export async function sendPushNotification(deviceToken: string, title: string, body: string) {
  const notification = new apn.Notification();
  notification.alert = { title, body };
  notification.sound = 'default';
  notification.badge = 1;
  notification.topic = 'com.liftflow.app';

  await apnProvider.send(notification, deviceToken);
}
```

---

## Step 6: Update Mobile App

When you make changes to the web app:

1. Build the web app: `pnpm build`
2. Sync to native projects: `pnpm exec cap sync`
3. Increment version number in:
   - `ios/App/App/Info.plist` (CFBundleShortVersionString)
   - `android/app/build.gradle` (versionName and versionCode)
4. Rebuild and resubmit to App Store / Play Store

---

## Troubleshooting

### iOS Build Fails
- Make sure you're using the latest Xcode
- Run `cd ios && pod install` to update CocoaPods
- Clean build folder: **Product** → **Clean Build Folder**

### Android Build Fails
- Make sure Java 17+ is installed
- Run `cd android && ./gradlew clean`
- Check `android/app/build.gradle` for errors

### Push Notifications Not Working
- iOS: Make sure APNs key is configured correctly
- Android: Make sure FCM is set up in Firebase Console
- Check device token is being saved to database

---

## App Store Requirements Checklist

- [ ] App icons (1024x1024px)
- [ ] Screenshots (iPhone and iPad)
- [ ] App description and keywords
- [ ] Privacy policy URL
- [ ] Support URL
- [ ] Sign in with Apple (if using other social logins)
- [ ] Push notification permission request
- [ ] Camera permission request (for video uploads)

---

## Useful Commands

```bash
# Build web app
pnpm build

# Sync to native projects
pnpm exec cap sync

# Open iOS project in Xcode
pnpm exec cap open ios

# Open Android project in Android Studio
pnpm exec cap open android

# Generate app icons and splash screens
pnpm exec capacitor-assets generate

# Update Capacitor
pnpm update @capacitor/core @capacitor/cli @capacitor/ios @capacitor/android
```

---

## Resources

- [Capacitor Documentation](https://capacitorjs.com/docs)
- [Apple Developer Portal](https://developer.apple.com/)
- [Google Play Console](https://play.google.com/console/)
- [App Store Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [Google Play Policy Center](https://play.google.com/about/developer-content-policy/)
