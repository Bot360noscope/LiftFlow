# App Store Metadata

## App Name
**LiftFlow**

## Subtitle (30 characters max)
AI-Powered Fitness Coaching

## Description

Transform your fitness journey with LiftFlow — the intelligent coaching platform that brings professional guidance to your pocket.

**For Coaches:**
Create personalized workout programs, analyze client form with AI-powered video review, and track progress all in one place. LiftFlow helps you scale your coaching business while maintaining the personal touch your clients deserve.

**For Athletes:**
Get expert coaching, log workouts, track your personal records, and receive detailed form feedback on every lift. Your coach sees your progress in real-time and provides guidance exactly when you need it.

**Key Features:**

• **AI Form Analysis** - Upload workout videos and get instant feedback on technique, depth, and bar path
• **Custom Programs** - Build week-by-week training plans with exercise libraries and progression tracking
• **Real-Time Progress** - Track PRs, volume, and strength gains with beautiful analytics
• **Video Review** - Coaches can review and comment on every lift with timestamp-specific feedback
• **Seamless Communication** - Built-in chat keeps you connected with your coach
• **Flexible Plans** - Free tier for solo athletes, scalable plans for growing coaching businesses

Whether you're a strength coach managing dozens of clients or an athlete looking for expert guidance, LiftFlow adapts to your needs. No more juggling spreadsheets, messaging apps, and video platforms — everything you need is here.

**Privacy & Security:**
Your data is encrypted and secure. We never share your information with third parties. Read our full privacy policy at liftflow.manus.space/privacy

**Support:**
Questions? Visit liftflow.manus.space/support or email support@liftflow.app

---

## Keywords (100 characters max, comma-separated)
fitness,coaching,workout,strength,AI,form,video,training,gym,powerlifting,weightlifting,personal trainer

---

## Category
**Primary:** Health & Fitness
**Secondary:** Sports

---

## Age Rating
**4+** (No objectionable content)

---

## Support URL
https://liftflow.manus.space/support

---

## Privacy Policy URL
https://liftflow.manus.space/privacy

---

## Copyright
© 2026 LiftFlow. All rights reserved.

---

## Promotional Text (170 characters max)
Get AI-powered form analysis on every lift. Coaches: manage clients effortlessly. Athletes: train smarter with expert guidance.

---

## What's New (Version 1.0.0)
🎉 Welcome to LiftFlow!

• AI-powered video form analysis
• Custom workout programs
• Real-time progress tracking
• Coach-client communication
• PR tracking and analytics

---

## Screenshot Descriptions

### iPhone Screenshots (Required: 5-8 screenshots)
1. **Home Screen** - "Choose your role: Coach or Athlete"
2. **Coach Dashboard** - "Manage all your clients in one place"
3. **Program Builder** - "Create custom workout programs with ease"
4. **Video Analysis** - "AI-powered form feedback on every lift"
5. **Progress Tracking** - "Beautiful analytics to track strength gains"
6. **Client Chat** - "Stay connected with real-time messaging"

### iPad Screenshots (Required: 5-8 screenshots)
Same as iPhone but optimized for larger screen

---

## App Preview Video (Optional but recommended)
15-30 second video showing:
1. Opening the app and selecting "I'm a Coach"
2. Creating a new program
3. Uploading a workout video
4. Viewing AI form analysis results
5. Checking client progress analytics

---

## Review Notes for Apple
This app requires user authentication via Manus OAuth. Test credentials:
- Email: demo@liftflow.app
- Password: [Provide test password]

The app includes:
- Video upload for form analysis (uses device camera)
- Push notifications for coach-client communication
- Sign in with Apple (required capability)

All video processing happens server-side. No user-generated content is stored without moderation.

---

## Localization
**Initial Launch:** English (United States)
**Future:** Spanish, Portuguese, French, German

---

## Pricing
**Free** - 1 client
**Per User** - $5/user/month (pay as you grow)
**Pro 10** - $40/month (up to 10 clients)
**Enterprise** - $99/month (unlimited clients)

All pricing is handled via external payment processor (liftflowpay.manus.space)
