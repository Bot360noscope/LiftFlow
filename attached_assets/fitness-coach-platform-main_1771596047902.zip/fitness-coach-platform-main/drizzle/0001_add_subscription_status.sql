-- Add subscriptionStatus field to users table
ALTER TABLE users ADD COLUMN subscriptionStatus ENUM('active', 'canceled', 'past_due', 'none') NOT NULL DEFAULT 'none' COMMENT 'Subscription state';
