import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, date } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with coach/client roles for the fitness platform.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "coach", "client"]).default("client").notNull(),
  plan: mysqlEnum("plan", ["free", "starter", "growth", "professional", "enterprise"]).default("free").notNull(),
  userCount: int("userCount").default(0), // For per_user tier: number of users purchased
  planExpiresAt: timestamp("planExpiresAt"), // when the current subscription expires
  subscriptionStatus: mysqlEnum("subscriptionStatus", ["active", "canceled", "past_due", "none"]).default("none").notNull(), // Subscription state
  userCode: varchar("userCode", { length: 8 }).unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Coach-Client relationships
 */
export const coachClients = mysqlTable("coachClients", {
  id: int("id").autoincrement().primaryKey(),
  coachId: int("coachId").notNull(),
  clientId: int("clientId").notNull(),
  status: mysqlEnum("status", ["pending", "active", "inactive"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Program Blocks (Excel Sheets)
 * Each client can have multiple blocks/programs
 * A block represents a 6-12 week training program
 */
export const programBlocks = mysqlTable("programBlocks", {
  id: int("id").autoincrement().primaryKey(),
  coachId: int("coachId").notNull(),
  clientId: int("clientId"),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  shareCode: varchar("shareCode", { length: 12 }).unique(),
  totalWeeks: int("totalWeeks").notNull().default(8), // 6-12 weeks
  daysPerWeek: int("daysPerWeek").notNull().default(3), // typically 3-6 days
  status: mysqlEnum("status", ["draft", "active", "completed", "archived"]).default("draft").notNull(),
  startDate: date("startDate"),
  coachLastViewedAt: timestamp("coachLastViewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProgramBlock = typeof programBlocks.$inferSelect;
export type InsertProgramBlock = typeof programBlocks.$inferInsert;

/**
 * Exercises in the program
 * Each row in the Excel sheet
 */
export const exercises = mysqlTable("exercises", {
  id: int("id").autoincrement().primaryKey(),
  blockId: int("blockId").notNull(),
  dayNumber: int("dayNumber").notNull(), // which day this exercise belongs to (1-7)
  name: varchar("name", { length: 255 }).notNull(),
  orderIndex: int("orderIndex").notNull().default(0), // for sorting exercises
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Exercise = typeof exercises.$inferSelect;
export type InsertExercise = typeof exercises.$inferInsert;

/**
 * Exercise Cells
 * Each cell in the Excel sheet (intersection of exercise row and day column)
 * Contains: sets, reps, completion status, and client notes
 */
export const exerciseCells = mysqlTable("exerciseCells", {
  id: int("id").autoincrement().primaryKey(),
  blockId: int("blockId").notNull(), // reference to programBlocks
  exerciseId: int("exerciseId").notNull(),
  rowNumber: int("rowNumber").notNull(), // which row this cell belongs to (0-indexed)
  weekNumber: int("weekNumber").notNull(), // 1-12
  dayNumber: int("dayNumber").notNull(), // 1-7
  exerciseName: varchar("exerciseName", { length: 255 }), // each cell has its own exercise name
  sets: int("sets"),
  reps: int("reps"),
  weight: varchar("weight", { length: 50 }), // e.g., "135 lbs" or "RPE 8"
  notes: text("notes"), // prescription (e.g., "40×5 50×5 60×5")
  rpe: varchar("rpe", { length: 20 }), // Rate of Perceived Exertion (1-10)
  videoUrl: text("videoUrl"), // client-uploaded video URL for this cell
  isCompleted: boolean("isCompleted").default(false).notNull(),
  clientNotes: text("clientNotes"), // client feedback/notes
  clientCommentedAt: timestamp("clientCommentedAt"), // when client last commented
  coachComment: text("coachComment"), // coach feedback/instructions for this exercise
  coachCommentedAt: timestamp("coachCommentedAt"), // when coach last commented
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ExerciseCell = typeof exerciseCells.$inferSelect;
export type InsertExerciseCell = typeof exerciseCells.$inferInsert;

/**
 * Videos for form checks
 */
export const videos = mysqlTable("videos", {
  id: int("id").autoincrement().primaryKey(),
  clientId: int("clientId").notNull(),
  coachId: int("coachId").notNull(),
  exerciseCellId: int("exerciseCellId"), // optional link to specific exercise cell
  exerciseName: varchar("exerciseName", { length: 255 }),
  videoUrl: text("videoUrl").notNull(),
  category: mysqlEnum("category", ["form_check", "technique", "warm_up", "other"]).default("form_check"),
  notes: text("notes"),
  reviewed: boolean("reviewed").default(false).notNull(),
  reviewNotes: text("reviewNotes"),
  viewedAt: timestamp("viewedAt"), // when coach first viewed the video
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Video = typeof videos.$inferSelect;
export type InsertVideo = typeof videos.$inferInsert;

/**
 * Chat messages between coach and client
 */
export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  senderId: int("senderId").notNull(),
  receiverId: int("receiverId").notNull(),
  message: text("message").notNull(),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;


/**
 * Lift Personal Records (PRs)
 * Tracks weight progression for main lifts: squats, deadlift, bench press
 * Deadlift and sumo deadlift are treated as the same data
 */
export const liftPRs = mysqlTable("liftPRs", {
  id: int("id").autoincrement().primaryKey(),
  clientId: int("clientId").notNull(),
  coachId: int("coachId").notNull(),
  liftType: mysqlEnum("liftType", ["squat", "deadlift", "bench"]).notNull(), // deadlift includes sumo
  weight: varchar("weight", { length: 50 }).notNull(), // e.g., "225 lbs"
  date: date("date").notNull(), // when this PR was achieved
  notes: text("notes"), // optional notes about the lift
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LiftPR = typeof liftPRs.$inferSelect;
export type InsertLiftPR = typeof liftPRs.$inferInsert;
