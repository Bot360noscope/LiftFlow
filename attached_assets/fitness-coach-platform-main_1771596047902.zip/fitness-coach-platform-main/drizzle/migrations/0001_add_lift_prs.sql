CREATE TABLE `liftPRs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`clientId` int NOT NULL,
	`coachId` int NOT NULL,
	`liftType` enum('squat','deadlift','bench') NOT NULL,
	`weight` varchar(50) NOT NULL,
	`date` date NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `liftPRs_id` PRIMARY KEY (`id`)
);
