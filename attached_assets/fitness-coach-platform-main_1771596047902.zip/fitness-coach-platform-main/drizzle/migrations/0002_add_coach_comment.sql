-- Add coach comment fields to exerciseCells table
ALTER TABLE exerciseCells ADD COLUMN coachComment TEXT;
ALTER TABLE exerciseCells ADD COLUMN coachCommentedAt TIMESTAMP;
