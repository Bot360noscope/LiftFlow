CREATE TABLE `programBlocks` (
`id` int AUTO_INCREMENT NOT NULL,
`coachId` int NOT NULL,
`clientId` int NOT NULL,
`title` varchar(255) NOT NULL,
`description` text,
`totalWeeks` int NOT NULL DEFAULT 8,
`daysPerWeek` int NOT NULL DEFAULT 3,
`status` enum('draft','active','completed','archived') NOT NULL DEFAULT 'draft',
`startDate` date,
`createdAt` timestamp NOT NULL DEFAULT (now()),
`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
CONSTRAINT `programBlocks_id` PRIMARY KEY(`id`)
);

CREATE TABLE `exercises` (
`id` int AUTO_INCREMENT NOT NULL,
`blockId` int NOT NULL,
`name` varchar(255) NOT NULL,
`orderIndex` int NOT NULL DEFAULT 0,
`createdAt` timestamp NOT NULL DEFAULT (now()),
CONSTRAINT `exercises_id` PRIMARY KEY(`id`)
);

CREATE TABLE `exerciseCells` (
`id` int AUTO_INCREMENT NOT NULL,
`exerciseId` int NOT NULL,
`weekNumber` int NOT NULL,
`dayNumber` int NOT NULL,
`sets` int,
`reps` int,
`weight` varchar(50),
`notes` text,
`isCompleted` boolean NOT NULL DEFAULT false,
`clientNotes` text,
`completedAt` timestamp,
`createdAt` timestamp NOT NULL DEFAULT (now()),
`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
CONSTRAINT `exerciseCells_id` PRIMARY KEY(`id`)
);

CREATE TABLE `coachClients` (
`id` int AUTO_INCREMENT NOT NULL,
`coachId` int NOT NULL,
`clientId` int NOT NULL,
`status` enum('pending','active','inactive') NOT NULL DEFAULT 'pending',
`createdAt` timestamp NOT NULL DEFAULT (now()),
CONSTRAINT `coachClients_id` PRIMARY KEY(`id`)
);

CREATE TABLE `videos` (
`id` int AUTO_INCREMENT NOT NULL,
`clientId` int NOT NULL,
`coachId` int NOT NULL,
`exerciseCellId` int,
`exerciseName` varchar(255),
`videoUrl` text NOT NULL,
`category` enum('form_check','technique','warm_up','other') DEFAULT 'form_check',
`notes` text,
`reviewed` boolean NOT NULL DEFAULT false,
`reviewNotes` text,
`createdAt` timestamp NOT NULL DEFAULT (now()),
CONSTRAINT `videos_id` PRIMARY KEY(`id`)
);

CREATE TABLE `chatMessages` (
`id` int AUTO_INCREMENT NOT NULL,
`senderId` int NOT NULL,
`receiverId` int NOT NULL,
`message` text NOT NULL,
`read` boolean NOT NULL DEFAULT false,
`createdAt` timestamp NOT NULL DEFAULT (now()),
CONSTRAINT `chatMessages_id` PRIMARY KEY(`id`)
);
