-- Update plan enum to simplified tiers
ALTER TABLE users MODIFY COLUMN plan ENUM('free', 'starter_5', 'pro_10') NOT NULL DEFAULT 'free';
