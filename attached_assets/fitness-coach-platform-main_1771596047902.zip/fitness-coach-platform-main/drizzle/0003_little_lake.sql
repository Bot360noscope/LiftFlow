ALTER TABLE `users` ADD `userCode` varchar(8);--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_userCode_unique` UNIQUE(`userCode`);