# LiftFlow iOS Setup Instructions

## Prerequisites

1. **Mac computer** with macOS (required for Xcode)
2. **Xcode** installed (free from Mac App Store)
3. **iPhone** with USB cable
4. **Apple ID** (free, no developer account needed for testing)

---

## Step 1: Download the Project

1. Download the project checkpoint from Manus
2. Extract to a folder on your Mac (e.g., `~/Projects/fitness-coach-platform`)

---

## Step 2: Install Dependencies

Open Terminal and run:

```bash
cd ~/Projects/fitness-coach-platform
pnpm install
```

---

## Step 3: Build the Web App

```bash
pnpm run build
```

This creates the `dist/client` folder that Capacitor needs.

---

## Step 4: Sync iOS Project

```bash
npx cap sync ios
```

This copies your built web app into the iOS project.

---

## Step 5: Open in Xcode

```bash
npx cap open ios
```

Xcode will launch with your project.

---

## Step 6: Configure Signing (First Time Only)

1. In Xcode, click on **"App"** in the left sidebar (the blue icon)
2. Click on **"Signing & Capabilities"** tab
3. Check **"Automatically manage signing"**
4. Select your **Team** (your Apple ID)
   - If you don't see your Apple ID, click "Add Account..." and sign in
5. Xcode will automatically create a provisioning profile

---

## Step 7: Connect Your iPhone

1. Plug your iPhone into your Mac via USB
2. On your iPhone, tap **"Trust This Computer"** if prompted
3. In Xcode, at the top, select your iPhone from the device dropdown (next to the "App" scheme)

---

## Step 8: Run on Your iPhone

1. Click the **Play button** (▶️) in Xcode's toolbar
2. Xcode will build and install the app on your iPhone
3. **First time:** You'll see "Untrusted Developer" on your iPhone
   - Go to **Settings > General > VPN & Device Management**
   - Tap your Apple ID
   - Tap **"Trust [Your Name]"**
   - Go back to home screen and launch LiftFlow

---

## Step 9: Test the App

The app should now run on your iPhone! Test:
- ✅ Video recording (opens native camera)
- ✅ OAuth login (opens in Safari)
- ✅ Video downloads (opens in browser)

---

## Important Notes

### App Expires After 7 Days
- Free Apple ID apps expire after 7 days
- Just re-run from Xcode to reinstall
- For permanent installation, you need a $99/year Apple Developer account

### Production Domain for OAuth
- Currently, OAuth redirects to `your-production-domain.com`
- **You must update this** in `client/src/const.ts` line 15:
  ```typescript
  const redirectUri = isNative 
    ? `https://YOUR-ACTUAL-DOMAIN.manus.space/api/oauth/callback`
    : `${window.location.origin}/api/oauth/callback`;
  ```
- Replace with your actual published Manus domain

### Making Changes

After changing code:
1. `pnpm run build` - Rebuild web app
2. `npx cap sync ios` - Copy to iOS project
3. Click Play in Xcode - Run on iPhone

---

## Troubleshooting

### "No code signing identities found"
- Add your Apple ID in Xcode > Settings > Accounts

### "Failed to verify code signature"
- Trust your developer certificate on iPhone (Settings > General > VPN & Device Management)

### "Could not launch app"
- Make sure iPhone is unlocked
- Try unplugging and replugging the USB cable

### Video recording not working
- Check camera permissions in iPhone Settings > LiftFlow
- Make sure Info.plist has the permission strings (already added)

---

## Next Steps

### For TestFlight Distribution
1. Enroll in Apple Developer Program ($99/year)
2. Create an App Store Connect account
3. Archive the app in Xcode
4. Upload to App Store Connect
5. Add beta testers in TestFlight

### For App Store Release
1. Complete TestFlight setup
2. Add screenshots, description, icons
3. Submit for App Store review
4. Wait 1-3 days for approval

---

## Android Setup (Bonus)

Want to test on Android too?

```bash
npx cap open android
```

Opens in Android Studio. Similar process but no 7-day expiration!
