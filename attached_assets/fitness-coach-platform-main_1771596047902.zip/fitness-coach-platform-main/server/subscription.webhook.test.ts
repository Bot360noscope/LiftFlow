import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getUserByEmail, updateUserPlan } from "./db";

/**
 * Test suite for subscription-based webhook functionality
 * Tests the transition from one-time purchases to subscription model
 */
describe("Subscription Webhook", () => {
  const testEmail = "webhook-test@example.com";
  
  beforeAll(async () => {
    // Clean up any existing test user
    const existing = await getUserByEmail(testEmail);
    if (existing) {
      await updateUserPlan(existing.id, "free", 0, null, "none");
    }
  });

  afterAll(async () => {
    // Clean up test user
    const user = await getUserByEmail(testEmail);
    if (user) {
      await updateUserPlan(user.id, "free", 0, null, "none");
    }
  });

  it("should set absolute slot count for active subscription", async () => {
    const user = await getUserByEmail(testEmail);
    if (!user) {
      console.log("Test user not found, skipping test");
      return;
    }

    // Simulate subscription webhook with 10 total slots
    await updateUserPlan(
      user.id,
      "per_user",
      10, // Total slots, not additional
      new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
      "active"
    );

    const updated = await getUserByEmail(testEmail);
    expect(updated?.userCount).toBe(10);
    expect(updated?.plan).toBe("per_user");
    expect(updated?.subscriptionStatus).toBe("active");
  });

  it("should update to new slot count when subscription changes", async () => {
    const user = await getUserByEmail(testEmail);
    if (!user) {
      console.log("Test user not found, skipping test");
      return;
    }

    // User upgrades from 10 to 25 slots
    await updateUserPlan(
      user.id,
      "per_user",
      25, // New total slots
      new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
      "active"
    );

    const updated = await getUserByEmail(testEmail);
    expect(updated?.userCount).toBe(25); // Should be 25, not 35 (10+25)
    expect(updated?.subscriptionStatus).toBe("active");
  });

  it("should maintain access for canceled subscription until period end", async () => {
    const user = await getUserByEmail(testEmail);
    if (!user) {
      console.log("Test user not found, skipping test");
      return;
    }

    const periodEnd = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    // User cancels subscription
    await updateUserPlan(
      user.id,
      "per_user",
      25, // Keep current slots
      periodEnd,
      "canceled"
    );

    const updated = await getUserByEmail(testEmail);
    expect(updated?.userCount).toBe(25); // Slots remain
    expect(updated?.subscriptionStatus).toBe("canceled");
    expect(updated?.planExpiresAt).toBeTruthy();
  });

  it("should mark subscription as past_due on payment failure", async () => {
    const user = await getUserByEmail(testEmail);
    if (!user) {
      console.log("Test user not found, skipping test");
      return;
    }

    // Payment fails
    await updateUserPlan(
      user.id,
      "per_user",
      25,
      new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Grace period
      "past_due"
    );

    const updated = await getUserByEmail(testEmail);
    expect(updated?.subscriptionStatus).toBe("past_due");
  });

  it("should reset subscription status for free plan", async () => {
    const user = await getUserByEmail(testEmail);
    if (!user) {
      console.log("Test user not found, skipping test");
      return;
    }

    // Downgrade to free
    await updateUserPlan(user.id, "free", 0, null);

    const updated = await getUserByEmail(testEmail);
    expect(updated?.plan).toBe("free");
    expect(updated?.userCount).toBe(0);
    expect(updated?.subscriptionStatus).toBe("none");
    expect(updated?.planExpiresAt).toBeNull();
  });
});
