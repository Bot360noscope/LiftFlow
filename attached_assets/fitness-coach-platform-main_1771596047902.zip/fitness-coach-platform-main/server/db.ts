import { eq, and, or, desc, isNotNull, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  coachClients,
  programBlocks,
  exercises,
  exerciseCells,
  videos,
  chatMessages,
  liftPRs,
  type ProgramBlock,
  type Exercise,
  type ExerciseCell
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ===== User Management =====

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.userCode, code)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserCode(userId: number, code: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ userCode: code }).where(eq(users.id, userId));
}

export async function updateUserRole(userId: number, role: "coach" | "client") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

export async function updateUserPlan(
  userId: number,
  plan: "free" | "starter" | "growth" | "professional" | "enterprise",
  userCount?: number,
  planExpiresAt?: Date | null,
  subscriptionStatus?: "active" | "canceled" | "past_due" | "none"
) {
  const db = await getDb();
  if (!db) return;
  const updateData: any = { plan };
  if (userCount !== undefined) {
    updateData.userCount = userCount;
  }
  if (planExpiresAt !== undefined) {
    updateData.planExpiresAt = planExpiresAt;
  }
  if (subscriptionStatus !== undefined) {
    updateData.subscriptionStatus = subscriptionStatus;
  }
  if (plan === "free") {
    updateData.planExpiresAt = null; // free plan never expires
    updateData.subscriptionStatus = "none"; // free plan has no subscription
  }
  await db.update(users).set(updateData).where(eq(users.id, userId));
}

// Stack purchased client slots onto existing userCount
// e.g. buying 10-pack then 4 per-user = userCount becomes 14, total limit = 15 (14 + 1 free)
export async function addUserSlots(
  userId: number,
  slotsToAdd: number,
  plan: "per_user" | "per_user_10",
  planExpiresAt?: Date | null
) {
  const db = await getDb();
  if (!db) return;
  
  // Get current user to read existing userCount
  const existing = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  const currentCount = existing.length > 0 ? (existing[0].userCount || 0) : 0;
  
  const updateData: any = {
    plan,
    userCount: currentCount + slotsToAdd,
  };
  if (planExpiresAt !== undefined) {
    updateData.planExpiresAt = planExpiresAt;
  }
  await db.update(users).set(updateData).where(eq(users.id, userId));
}

// ===== Coach-Client Relationships =====

export async function getCoachClientCount(coachId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const clients = await db.select().from(coachClients).where(
    and(
      eq(coachClients.coachId, coachId),
      eq(coachClients.status, "active")
    )
  );
  return clients.length;
}

export async function createPendingClientRequest(coachId: number, clientId: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(coachClients).values({
    coachId,
    clientId,
    status: "pending",
  });
}

export async function getPendingClientRequests(coachId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select({
      id: coachClients.id,
      clientId: coachClients.clientId,
      clientName: users.name,
      clientEmail: users.email,
      createdAt: coachClients.createdAt,
    })
    .from(coachClients)
    .leftJoin(users, eq(coachClients.clientId, users.id))
    .where(and(
      eq(coachClients.coachId, coachId),
      eq(coachClients.status, "pending")
    ));
  
  return results;
}

export async function createCoachClientRelation(coachId: number, clientId: number) {
  const db = await getDb();
  if (!db) return;
  
  await db
    .update(coachClients)
    .set({ status: "active" })
    .where(and(
      eq(coachClients.coachId, coachId),
      eq(coachClients.clientId, clientId)
    ));
}

export async function rejectClientRequest(coachId: number, clientId: number) {
  const db = await getDb();
  if (!db) return;
  
  await db
    .delete(coachClients)
    .where(and(
      eq(coachClients.coachId, coachId),
      eq(coachClients.clientId, clientId),
      eq(coachClients.status, "pending")
    ));
}

export async function deleteCoachClientRelation(coachId: number, clientId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Delete client's program copies (programs where this client is assigned)
  const clientPrograms = await db
    .select({ id: programBlocks.id })
    .from(programBlocks)
    .where(and(
      eq(programBlocks.coachId, coachId),
      eq(programBlocks.clientId, clientId)
    ));
  
  for (const program of clientPrograms) {
    // Delete exercise cells for this program
    await db.delete(exerciseCells).where(eq(exerciseCells.blockId, program.id));
    // Delete the program
    await db.delete(programBlocks).where(eq(programBlocks.id, program.id));
  }
  
  // Delete coach-client relationship
  await db
    .delete(coachClients)
    .where(and(
      eq(coachClients.coachId, coachId),
      eq(coachClients.clientId, clientId)
    ));
}

export async function getCoachClients(coachId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select({
      clientId: coachClients.clientId,
      clientName: users.name,
      clientEmail: users.email,
      status: coachClients.status,
      createdAt: coachClients.createdAt,
    })
    .from(coachClients)
    .leftJoin(users, eq(coachClients.clientId, users.id))
    .where(and(
      eq(coachClients.coachId, coachId),
      eq(coachClients.status, "active")
    ));
  
  return results;
}

export async function getClientCoaches(clientId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select({
      coachId: coachClients.coachId,
      coachName: users.name,
      coachEmail: users.email,
      status: coachClients.status,
      createdAt: coachClients.createdAt,
    })
    .from(coachClients)
    .leftJoin(users, eq(coachClients.coachId, users.id))
    .where(and(
      eq(coachClients.clientId, clientId),
      eq(coachClients.status, "active")
    ));
  
  return results;
}

// ===== Program Blocks (Excel Sheets) =====

export async function createProgramBlock(data: {
  coachId: number;
  clientId?: number;
  title: string;
  description?: string;
  totalWeeks: number;
  daysPerWeek: number;
  startDate?: Date;
}) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.insert(programBlocks).values({
    ...data,
    status: "draft",
  });
  
  return { id: Number(result[0].insertId) };
}

export async function cloneProgramBlock(sourceBlockId: number, newCoachId: number, newClientId: number) {
  const db = await getDb();
  if (!db) return null;
  
  // Get the source program block
  const sourceBlock = await getProgramBlock(sourceBlockId);
  if (!sourceBlock) return null;
  
  // Create new program block (copy of source)
  const newBlock = await createProgramBlock({
    coachId: newCoachId,
    clientId: newClientId,
    title: sourceBlock.title,
    description: sourceBlock.description || undefined,
    totalWeeks: sourceBlock.totalWeeks,
    daysPerWeek: sourceBlock.daysPerWeek,
    startDate: sourceBlock.startDate || undefined,
  });
  
  if (!newBlock) return null;
  
  // Get all cells from source block
  const sourceCells = await getBlockCells(sourceBlockId);
  
  // Clone all cells to new block (reset completion status)
  for (const cell of sourceCells) {
    await db.insert(exerciseCells).values({
      blockId: newBlock.id,
      exerciseId: cell.exerciseId,
      exerciseName: cell.exerciseName,
      rowNumber: cell.rowNumber,
      weekNumber: cell.weekNumber,
      dayNumber: cell.dayNumber,
      sets: cell.sets,
      reps: cell.reps,
      weight: cell.weight,
      notes: cell.notes,
      rpe: cell.rpe,
      // Reset client-specific fields
      isCompleted: false,
      completedAt: null,
      clientNotes: null,
      clientCommentedAt: null,
      videoUrl: null,
      coachComment: null,
      coachCommentedAt: null,
    });
  }
  
  return newBlock;
}

export async function getProgramBlock(blockId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select()
    .from(programBlocks)
    .where(eq(programBlocks.id, blockId))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

export async function getCoachProgramBlocks(coachId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select({
      id: programBlocks.id,
      title: programBlocks.title,
      description: programBlocks.description,
      totalWeeks: programBlocks.totalWeeks,
      daysPerWeek: programBlocks.daysPerWeek,
      status: programBlocks.status,
      startDate: programBlocks.startDate,
      clientId: programBlocks.clientId,
      clientName: users.name,
      createdAt: programBlocks.createdAt,
    })
    .from(programBlocks)
    .leftJoin(users, eq(programBlocks.clientId, users.id))
    .where(eq(programBlocks.coachId, coachId))
    .orderBy(desc(programBlocks.createdAt));
  
  return results;
}

export async function getClientProgramBlocks(clientId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select()
    .from(programBlocks)
    .where(eq(programBlocks.clientId, clientId))
    .orderBy(desc(programBlocks.createdAt));
  
  return results;
}

export async function getProgramByShareCode(shareCode: string) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select()
    .from(programBlocks)
    .where(eq(programBlocks.shareCode, shareCode))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

export async function updateProgramBlock(blockId: number, data: Partial<ProgramBlock>) {
  const db = await getDb();
  if (!db) return;
  
  await db
    .update(programBlocks)
    .set(data)
    .where(eq(programBlocks.id, blockId));
}

export async function deleteProgramBlock(blockId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Delete all related data first (exercises, cells, etc.)
  const blockExercises = await getBlockExercises(blockId);
  for (const exercise of blockExercises) {
    // Delete exercise cells
    await db.delete(exerciseCells).where(eq(exerciseCells.exerciseId, exercise.id));
  }
  
  // Delete exercises
  await db.delete(exercises).where(eq(exercises.blockId, blockId));
  
  // Delete the program block
  await db.delete(programBlocks).where(eq(programBlocks.id, blockId));
}

// ===== Exercises =====

export async function createExercise(data: {
  blockId: number;
  dayNumber: number;
  name: string;
  orderIndex: number;
}) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.insert(exercises).values(data);
  return { id: Number(result[0].insertId) };
}

export async function getBlockExercises(blockId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select()
    .from(exercises)
    .where(eq(exercises.blockId, blockId))
    .orderBy(exercises.orderIndex);
  
  return results;
}

export async function updateExercise(exerciseId: number, data: Partial<Exercise>) {
  const db = await getDb();
  if (!db) return;
  
  await db
    .update(exercises)
    .set(data)
    .where(eq(exercises.id, exerciseId));
}

export async function deleteExercise(exerciseId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Delete all cells for this exercise first
  await db.delete(exerciseCells).where(eq(exerciseCells.exerciseId, exerciseId));
  // Then delete the exercise
  await db.delete(exercises).where(eq(exercises.id, exerciseId));
}

// ===== Exercise Cells =====

export async function upsertExerciseCell(data: {
  blockId: number;
  exerciseId: number;
  rowNumber: number;
  weekNumber: number;
  dayNumber: number;
  exerciseName?: string;
  sets?: number;
  reps?: number;
  weight?: string;
  notes?: string;
  rpe?: string;
  coachComment?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  
  // Check if cell exists
  const existing = await db
    .select()
    .from(exerciseCells)
    .where(and(
      eq(exerciseCells.exerciseId, data.exerciseId),
      eq(exerciseCells.rowNumber, data.rowNumber),
      eq(exerciseCells.weekNumber, data.weekNumber),
      eq(exerciseCells.dayNumber, data.dayNumber)
    ))
    .limit(1);
  
  if (existing.length > 0) {
    // Update existing cell
    await db
      .update(exerciseCells)
      .set(data)
      .where(eq(exerciseCells.id, existing[0].id));
    return { id: existing[0].id };
  } else {
    // Create new cell
    const result = await db.insert(exerciseCells).values(data);
    return { id: Number(result[0].insertId) };
  }
}

export async function getExerciseCells(exerciseId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select()
    .from(exerciseCells)
    .where(eq(exerciseCells.exerciseId, exerciseId));
  
  return results;
}

export async function getBlockCells(blockId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select({
      id: exerciseCells.id,
      exerciseId: exerciseCells.exerciseId,
      exerciseName: exerciseCells.exerciseName,
      rowNumber: exerciseCells.rowNumber,
      weekNumber: exerciseCells.weekNumber,
      dayNumber: exerciseCells.dayNumber,
      sets: exerciseCells.sets,
      reps: exerciseCells.reps,
      weight: exerciseCells.weight,
      notes: exerciseCells.notes,
      rpe: exerciseCells.rpe,
      clientCommentedAt: exerciseCells.clientCommentedAt,
      videoUrl: exerciseCells.videoUrl,
      isCompleted: exerciseCells.isCompleted,
      clientNotes: exerciseCells.clientNotes,
      completedAt: exerciseCells.completedAt,
      coachComment: exerciseCells.coachComment,
      coachCommentedAt: exerciseCells.coachCommentedAt,
    })
    .from(exerciseCells)
    .where(eq(exerciseCells.blockId, blockId));
  
  return results;
}

export async function updateExerciseCell(cellId: number, data: Partial<ExerciseCell>) {
  const db = await getDb();
  if (!db) return;
  
  await db
    .update(exerciseCells)
    .set(data)
    .where(eq(exerciseCells.id, cellId));
}

export async function markCellCompleted(cellId: number, clientNotes?: string) {
  const db = await getDb();
  if (!db) return;
  
  const updateData: Record<string, unknown> = {
    isCompleted: true,
    completedAt: new Date(),
    clientNotes: clientNotes || null,
  };
  if (clientNotes) {
    updateData.clientCommentedAt = new Date();
  }
  await db
    .update(exerciseCells)
    .set(updateData)
    .where(eq(exerciseCells.id, cellId));
}

// ===== Videos =====

export async function createVideo(data: {
  clientId: number;
  coachId: number;
  exerciseCellId?: number;
  exerciseName?: string;
  videoUrl: string;
  category?: "form_check" | "technique" | "warm_up" | "other";
  notes?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.insert(videos).values(data);
  return { id: Number(result[0].insertId) };
}

export async function getCoachVideos(coachId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select({
      id: videos.id,
      clientId: videos.clientId,
      clientName: users.name,
      exerciseCellId: videos.exerciseCellId,
      exerciseName: videos.exerciseName,
      videoUrl: videos.videoUrl,
      category: videos.category,
      notes: videos.notes,
      reviewed: videos.reviewed,
      reviewNotes: videos.reviewNotes,
      createdAt: videos.createdAt,
    })
    .from(videos)
    .leftJoin(users, eq(videos.clientId, users.id))
    .where(eq(videos.coachId, coachId))
    .orderBy(desc(videos.createdAt));
  
  return results;
}

export async function updateVideo(videoId: number, data: { reviewed?: boolean; reviewNotes?: string; viewedAt?: Date }) {
  const db = await getDb();
  if (!db) return;
  
  await db
    .update(videos)
    .set(data)
    .where(eq(videos.id, videoId));
}

export async function markVideoViewed(videoId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Only set viewedAt if it's not already set (first view)
  const video = await db.select().from(videos).where(eq(videos.id, videoId)).limit(1);
  if (video[0] && !video[0].viewedAt) {
    await db
      .update(videos)
      .set({ viewedAt: new Date() })
      .where(eq(videos.id, videoId));
  }
}

export async function getExpiredVideos() {
  const db = await getDb();
  if (!db) return [];
  
  const twoWeeksAgo = new Date();
  twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
  
  const oneMonthAgo = new Date();
  oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
  
  // Delete if:
  // 1. Viewed AND 2 weeks have passed since view, OR
  // 2. 1 month has passed since upload (regardless of view)
  return await db
    .select()
    .from(videos)
    .where(or(
      and(
        sql`${videos.viewedAt} IS NOT NULL`,
        sql`${videos.viewedAt} < ${twoWeeksAgo}`
      ),
      sql`${videos.createdAt} < ${oneMonthAgo}`
    ));
}

export async function deleteVideo(videoId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Get video URL before deleting to extract S3 key
  const video = await db.select().from(videos).where(eq(videos.id, videoId)).limit(1);
  
  // Delete from database
  await db.delete(videos).where(eq(videos.id, videoId));
  
  // Delete from S3 if video exists
  if (video[0]?.videoUrl) {
    try {
      const { storageDelete } = await import('./storage');
      // Extract S3 key from URL (assumes URL format: https://.../{key})
      const urlObj = new URL(video[0].videoUrl);
      const s3Key = urlObj.pathname.substring(1); // Remove leading /
      await storageDelete(s3Key);
    } catch (error) {
      console.error(`Failed to delete S3 file for video ${videoId}:`, error);
      // Don't throw - database record is already deleted
    }
  }
}

export async function cleanupExpiredVideos() {
  const expiredVideos = await getExpiredVideos();
  let deletedCount = 0;
  
  for (const video of expiredVideos) {
    try {
      await deleteVideo(video.id);
      deletedCount++;
    } catch (error) {
      console.error(`Failed to delete video ${video.id}:`, error);
    }
  }
  
  return { deletedCount, totalExpired: expiredVideos.length };
}

// ===== Chat Messages =====

export async function createChatMessage(data: {
  senderId: number;
  receiverId: number;
  message: string;
}) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.insert(chatMessages).values(data);
  return { id: Number(result[0].insertId) };
}

export async function getChatMessages(userId1: number, userId2: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select()
    .from(chatMessages)
    .where(
      and(
        eq(chatMessages.senderId, userId1),
        eq(chatMessages.receiverId, userId2)
      )
    )
    .orderBy(chatMessages.createdAt);
  
  return results;
}

// ===== Unread Client Comments =====

export async function getUnreadCommentCounts(coachId: number) {
  const db = await getDb();
  if (!db) return [];
  
  // Get all programs for this coach with their client comments
  const results = await db
    .select({
      blockId: programBlocks.id,
      clientId: programBlocks.clientId,
      clientName: users.name,
      coachLastViewedAt: programBlocks.coachLastViewedAt,
    })
    .from(programBlocks)
    .leftJoin(users, eq(programBlocks.clientId, users.id))
    .where(eq(programBlocks.coachId, coachId));
  
  // For each program, count cells with clientCommentedAt > coachLastViewedAt
  const counts = [];
  for (const program of results) {
    if (!program.clientId) continue;
    
    // Query cells directly by blockId (new cell-based model)
    const cells = await db
      .select({
        clientCommentedAt: exerciseCells.clientCommentedAt,
        clientNotes: exerciseCells.clientNotes,
      })
      .from(exerciseCells)
      .where(
        and(
          eq(exerciseCells.blockId, program.blockId),
          isNotNull(exerciseCells.clientNotes)
        )
      );
    
    // Count cells with client comments newer than coach's last view
    let unreadCount = 0;
    for (const cell of cells) {
      if (cell.clientNotes && cell.clientCommentedAt) {
        if (!program.coachLastViewedAt || cell.clientCommentedAt > program.coachLastViewedAt) {
          unreadCount++;
        }
      }
    }
    
    if (unreadCount > 0) {
      counts.push({
        blockId: program.blockId,
        clientId: program.clientId,
        clientName: program.clientName,
        unreadCount,
      });
    }
  }
  
  return counts;
}

export async function markProgramViewed(blockId: number) {
  const db = await getDb();
  if (!db) return;
  
  await db
    .update(programBlocks)
    .set({ coachLastViewedAt: new Date() })
    .where(eq(programBlocks.id, blockId));
}

export async function getClientProgramsForCoach(coachId: number) {
  const db = await getDb();
  if (!db) return [];
  
  // Get all clients and their programs for this coach
  const clients = await getCoachClients(coachId);
  const result = [];
  
  for (const client of clients) {
    const clientPrograms = await db
      .select({
        id: programBlocks.id,
        title: programBlocks.title,
        totalWeeks: programBlocks.totalWeeks,
        daysPerWeek: programBlocks.daysPerWeek,
        status: programBlocks.status,
        shareCode: programBlocks.shareCode,
        createdAt: programBlocks.createdAt,
      })
      .from(programBlocks)
      .where(
        and(
          eq(programBlocks.coachId, coachId),
          eq(programBlocks.clientId, client.clientId)
        )
      )
      .orderBy(desc(programBlocks.createdAt));
    
    result.push({
      clientId: client.clientId,
      clientName: client.clientName,
      clientEmail: client.clientEmail,
      programs: clientPrograms,
    });
  }
  
  return result;
}


export async function markBlockCommentsAsRead(blockId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Mark all cells in this block as having their comments read by coach
  await db
    .update(exerciseCells)
    .set({ clientCommentedAt: null })
    .where(eq(exerciseCells.blockId, blockId));
}


// ===== Lift PRs (Personal Records) =====

export async function addLiftPR(data: {
  clientId: number;
  coachId: number;
  liftType: "squat" | "deadlift" | "bench";
  weight: string;
  date: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  
  // Check if a PR already exists for this client, lift type, and date
  const existingPR = await db
    .select()
    .from(liftPRs)
    .where(
      and(
        eq(liftPRs.clientId, data.clientId),
        eq(liftPRs.liftType, data.liftType),
        eq(liftPRs.date, new Date(data.date))
      )
    )
    .limit(1);
  
  // If a PR exists for this lift on this date
  if (existingPR.length > 0) {
    const existingWeight = parseFloat(existingPR[0].weight);
    const newWeight = parseFloat(data.weight);
    
    // If new weight is higher, update the existing record
    if (newWeight > existingWeight) {
      await db
        .update(liftPRs)
        .set({ 
          weight: data.weight,
          notes: data.notes || null 
        })
        .where(eq(liftPRs.id, existingPR[0].id));
      return { id: existingPR[0].id };
    }
    
    // If new weight is same or lower, just return existing ID without updating
    return { id: existingPR[0].id };
  }
  
  const result = await db.insert(liftPRs).values({
    clientId: data.clientId,
    coachId: data.coachId,
    liftType: data.liftType,
    weight: data.weight,
    date: new Date(data.date),
    notes: data.notes || null,
  });
  
  return { id: Number(result[0].insertId) };
}

export async function getLiftPRs(clientId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const results = await db
    .select()
    .from(liftPRs)
    .where(eq(liftPRs.clientId, clientId))
    .orderBy(liftPRs.date);
  
  return results;
}

export async function deleteLiftPR(prId: number) {
  const db = await getDb();
  if (!db) return;
  
  await db.delete(liftPRs).where(eq(liftPRs.id, prId));
}

export async function updateLiftPR(prId: number, data: {
  weight?: string;
  date?: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) return;
  
  const updateData: Record<string, unknown> = {};
  if (data.weight !== undefined) updateData.weight = data.weight;
  if (data.date !== undefined) updateData.date = new Date(data.date);
  if (data.notes !== undefined) updateData.notes = data.notes;
  
  await db.update(liftPRs).set(updateData).where(eq(liftPRs.id, prId));
}

/**
 * Delete all data for a user (GDPR compliance - PERMANENT DELETION)
 * Removes: ALL programs, exercise cells, lift PRs, coach/client relationships, videos, chat messages, and user account
 * WARNING: This is irreversible. User cannot re-access data after deletion.
 */
export async function deleteAllUserData(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Get all programs where user is coach OR client
  const userPrograms = await db
    .select({ id: programBlocks.id })
    .from(programBlocks)
    .where(
      or(
        eq(programBlocks.coachId, userId),
        eq(programBlocks.clientId, userId)
      )
    );
  
  const programIds = userPrograms.map(p => p.id);
  
  // Delete exercise cells for all user's programs (as coach or client)
  if (programIds.length > 0) {
    await db.delete(exerciseCells).where(
      sql`${exerciseCells.blockId} IN (${sql.join(programIds.map(id => sql`${id}`), sql`, `)})`
    );
  }
  
  // Delete programs where user is coach
  await db.delete(programBlocks).where(eq(programBlocks.coachId, userId));
  
  // Delete programs where user is client
  await db.delete(programBlocks).where(eq(programBlocks.clientId, userId));
  
  // Delete lift PRs
  await db.delete(liftPRs).where(eq(liftPRs.clientId, userId));
  
  // Delete coach-client relationships (both directions)
  await db.delete(coachClients).where(
    or(
      eq(coachClients.coachId, userId),
      eq(coachClients.clientId, userId)
    )
  );
  
  // Delete chat messages (sent and received)
  await db.delete(chatMessages).where(
    or(
      eq(chatMessages.senderId, userId),
      eq(chatMessages.receiverId, userId)
    )
  );
  
  // Delete videos (where user is client or coach)
  await db.delete(videos).where(
    or(
      eq(videos.clientId, userId),
      eq(videos.coachId, userId)
    )
  );
  
  // Delete user account itself (PERMANENT)
  await db.delete(users).where(eq(users.id, userId));
  
  // Note: S3 files (videos, images) remain in storage but are orphaned
  // Consider adding S3 cleanup in production
  
  return { success: true };
}
