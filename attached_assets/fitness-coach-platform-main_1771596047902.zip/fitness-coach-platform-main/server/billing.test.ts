import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

// Mock context for testing
const createMockContext = (
  userId: number,
  role: "coach" | "client" = "coach",
  plan: "free" | "per_user" | "per_user_10" | "enterprise" = "free",
  userCount: number = 0
): TrpcContext => ({
  user: {
    id: userId,
    openId: `test-${userId}`,
    name: `Test User ${userId}`,
    email: `user${userId}@test.com`,
    loginMethod: "email",
    role,
    plan,
    userCount,
    userCode: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  },
  req: {} as any,
  res: {} as any,
});

describe("Billing & Plan Management", () => {
  const webhookSecret = process.env.BILLING_WEBHOOK_SECRET || "test-secret";

  it("should reject webhook with invalid secret", async () => {
    const caller = appRouter.createCaller(createMockContext(999));
    
    await expect(
      caller.billing.upgradeToPremium({
        userId: 1,
        webhookSecret: "wrong-secret",
        plan: "per_user",
      })
    ).rejects.toThrow("Invalid webhook secret");
  });

  it("should upgrade user to per_user tier with valid secret", async () => {
    const userId = 1;
    const caller = appRouter.createCaller(createMockContext(userId));
    
    const result = await caller.billing.upgradeToPremium({
      userId,
      webhookSecret,
      plan: "per_user",
      userCount: 5,
    });

    expect(result.success).toBe(true);
    expect(result.userId).toBe(userId);
    expect(result.plan).toBe("per_user");
  });

  it("should return plan status for free user", async () => {
    const userId = 2;
    const caller = appRouter.createCaller(createMockContext(userId, "coach", "free"));
    
    const status = await caller.billing.getMyPlanStatus();

    expect(status.plan).toBe("free");
    expect(status.clientLimit).toBe(1);
    expect(typeof status.clientCount).toBe("number");
  });

  it("should return unlimited clients for enterprise user", async () => {
    const userId = 3;
    const caller = appRouter.createCaller(createMockContext(userId, "coach", "enterprise"));
    
    const status = await caller.billing.getMyPlanStatus();

    expect(status.plan).toBe("enterprise");
    expect(status.clientLimit).toBeNull(); // null = unlimited
  });

  it("should return correct limit for per_user tier", async () => {
    const userId = 5;
    const caller = appRouter.createCaller(createMockContext(userId, "coach", "per_user", 5));
    
    const status = await caller.billing.getMyPlanStatus();

    expect(status.plan).toBe("per_user");
    expect(status.clientLimit).toBe(6); // 5 purchased + 1 free
  });

  it("should return stacked limit for per_user_10 tier", async () => {
    // per_user_10 with userCount=10 means 10 purchased + 1 free = 11 total
    const userId = 6;
    const caller = appRouter.createCaller(createMockContext(userId, "coach", "per_user_10", 10));
    
    const status = await caller.billing.getMyPlanStatus();

    expect(status.plan).toBe("per_user_10");
    expect(status.clientLimit).toBe(11); // 10 purchased + 1 free
    expect(status.userCount).toBe(10);
  });

  it("should count coach clients correctly", async () => {
    const coachId = 4;
    const count = await db.getCoachClientCount(coachId);
    
    expect(typeof count).toBe("number");
    expect(count).toBeGreaterThanOrEqual(0);
  });
});
