import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Helper to create mock context with planExpiresAt support
const createMockContext = (
  userId: number,
  role: "coach" | "client" = "coach",
  plan: "free" | "per_user" | "per_user_10" | "enterprise" = "free",
  userCount: number = 0,
  planExpiresAt: Date | null = null
): TrpcContext => ({
  user: {
    id: userId,
    openId: `test-expiry-${userId}`,
    name: `Test User ${userId}`,
    email: `user${userId}@test.com`,
    loginMethod: "email",
    role,
    plan,
    userCount,
    planExpiresAt,
    userCode: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  },
  req: {} as any,
  res: {} as any,
});

describe("Subscription Expiry Handling", () => {
  const webhookSecret = process.env.BILLING_WEBHOOK_SECRET || "test-secret";

  describe("getMyPlanStatus with expiry", () => {
    it("should show active plan with days remaining when not expired", async () => {
      const futureDate = new Date(Date.now() + 15 * 24 * 60 * 60 * 1000); // 15 days from now
      const ctx = createMockContext(100, "coach", "per_user_10", 10, futureDate);
      const caller = appRouter.createCaller(ctx);

      const status = await caller.billing.getMyPlanStatus();

      expect(status.plan).toBe("per_user_10");
      expect(status.isExpired).toBe(false);
      expect(status.isFrozen).toBe(false);
      expect(status.daysRemaining).toBeGreaterThan(0);
      expect(status.daysRemaining).toBeLessThanOrEqual(15);
      expect(status.clientLimit).toBe(11); // 10 purchased + 1 free
    });

    it("should show expired status when subscription has expired", async () => {
      const pastDate = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000); // 1 day ago
      const ctx = createMockContext(101, "coach", "per_user_10", 0, pastDate);
      const caller = appRouter.createCaller(ctx);

      const status = await caller.billing.getMyPlanStatus();

      expect(status.isExpired).toBe(true);
      expect(status.plan).toBe("free"); // effective plan reverts to free
      expect(status.originalPlan).toBe("per_user_10"); // original plan preserved
      expect(status.clientLimit).toBe(1); // free tier limit
      expect(status.daysRemaining).toBeNull();
    });

    it("should not freeze account if expired but has 0 or 1 clients", async () => {
      const pastDate = new Date(Date.now() - 5 * 24 * 60 * 60 * 1000); // 5 days ago
      const ctx = createMockContext(102, "coach", "per_user_10", 0, pastDate);
      const caller = appRouter.createCaller(ctx);

      const status = await caller.billing.getMyPlanStatus();

      expect(status.isExpired).toBe(true);
      // isFrozen depends on actual client count in DB, but for a user with no clients:
      // clientCount should be 0 or 1, so isFrozen should be false
      expect(status.isFrozen).toBe(false);
    });

    it("should not expire free plan even with planExpiresAt set", async () => {
      const pastDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 days ago
      const ctx = createMockContext(103, "coach", "free", 0, pastDate);
      const caller = appRouter.createCaller(ctx);

      const status = await caller.billing.getMyPlanStatus();

      expect(status.plan).toBe("free");
      expect(status.isExpired).toBe(false); // free plan never expires
      expect(status.isFrozen).toBe(false);
    });

    it("should show null daysRemaining for free plan", async () => {
      const ctx = createMockContext(104, "coach", "free", 0, null);
      const caller = appRouter.createCaller(ctx);

      const status = await caller.billing.getMyPlanStatus();

      expect(status.plan).toBe("free");
      expect(status.daysRemaining).toBeNull();
      expect(status.planExpiresAt).toBeNull();
    });

    it("should show null daysRemaining for premium plan without expiry date", async () => {
      const ctx = createMockContext(105, "coach", "enterprise", 0, null);
      const caller = appRouter.createCaller(ctx);

      const status = await caller.billing.getMyPlanStatus();

      expect(status.plan).toBe("enterprise");
      expect(status.isExpired).toBe(false);
      expect(status.daysRemaining).toBeNull();
      expect(status.clientLimit).toBeNull(); // unlimited
    });

    it("should preserve originalPlan when expired", async () => {
      const pastDate = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000);
      const ctx = createMockContext(106, "coach", "enterprise", 0, pastDate);
      const caller = appRouter.createCaller(ctx);

      const status = await caller.billing.getMyPlanStatus();

      expect(status.plan).toBe("free"); // effective
      expect(status.originalPlan).toBe("enterprise"); // original
      expect(status.isExpired).toBe(true);
    });
  });

  describe("upgradeToPremium with durationDays", () => {
    it("should accept durationDays parameter and return expiresAt", async () => {
      const ctx = createMockContext(200);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.billing.upgradeToPremium({
        userId: 200,
        webhookSecret,
        plan: "per_user_10",
        durationDays: 30,
      });

      expect(result.success).toBe(true);
      expect(result.plan).toBe("per_user_10");
      expect(result.slotsAdded).toBe(10); // per_user_10 always adds 10 slots
      expect(result.expiresAt).toBeTruthy();
      // expiresAt should be approximately 30 days from now
      const expiresAt = new Date(result.expiresAt!);
      const expectedDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      const diffMs = Math.abs(expiresAt.getTime() - expectedDate.getTime());
      expect(diffMs).toBeLessThan(5000); // within 5 seconds
    });

    it("should not set expiresAt for free plan even with durationDays", async () => {
      const ctx = createMockContext(201);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.billing.upgradeToPremium({
        userId: 201,
        webhookSecret,
        plan: "free",
        durationDays: 30,
      });

      expect(result.success).toBe(true);
      expect(result.plan).toBe("free");
      expect(result.slotsAdded).toBe(0); // free plan adds no slots
      expect(result.expiresAt).toBeNull();
    });

    it("should not set expiresAt when durationDays is not provided", async () => {
      const ctx = createMockContext(202);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.billing.upgradeToPremium({
        userId: 202,
        webhookSecret,
        plan: "per_user_10",
      });

      expect(result.success).toBe(true);
      expect(result.slotsAdded).toBe(10); // per_user_10 always adds 10
      expect(result.expiresAt).toBeNull();
    });
  });

  describe("stacking purchases", () => {
    it("should show stacked limit for per_user with 14 purchased slots", async () => {
      // Simulates: bought 10-pack (userCount=10) then 4 per-user (userCount=14)
      const futureDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      const ctx = createMockContext(300, "coach", "per_user", 14, futureDate);
      const caller = appRouter.createCaller(ctx);

      const status = await caller.billing.getMyPlanStatus();

      expect(status.plan).toBe("per_user");
      expect(status.clientLimit).toBe(15); // 14 purchased + 1 free = 15 total
      expect(status.userCount).toBe(14);
    });

    it("should show stacked limit for per_user_10 with 20 purchased slots", async () => {
      // Simulates: bought two 10-packs (userCount=20)
      const futureDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      const ctx = createMockContext(301, "coach", "per_user_10", 20, futureDate);
      const caller = appRouter.createCaller(ctx);

      const status = await caller.billing.getMyPlanStatus();

      expect(status.plan).toBe("per_user_10");
      expect(status.clientLimit).toBe(21); // 20 purchased + 1 free = 21 total
      expect(status.userCount).toBe(20);
    });

    it("per_user_10 upgrade should report 10 slotsAdded", async () => {
      const ctx = createMockContext(302);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.billing.upgradeToPremium({
        userId: 302,
        webhookSecret,
        plan: "per_user_10",
        durationDays: 30,
      });

      expect(result.slotsAdded).toBe(10);
    });

    it("per_user upgrade with userCount=4 should report 4 slotsAdded", async () => {
      const ctx = createMockContext(303);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.billing.upgradeToPremium({
        userId: 303,
        webhookSecret,
        plan: "per_user",
        userCount: 4,
        durationDays: 30,
      });

      expect(result.slotsAdded).toBe(4);
    });

    it("enterprise upgrade should report 0 slotsAdded (unlimited)", async () => {
      const ctx = createMockContext(304);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.billing.upgradeToPremium({
        userId: 304,
        webhookSecret,
        plan: "enterprise",
        durationDays: 30,
      });

      expect(result.slotsAdded).toBe(0); // enterprise doesn't use slots
    });
  });
});
