import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { detectMainLift } from "../shared/liftDetection";
import { exerciseCells, programBlocks } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// Custom procedures for role-based access
const coachProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "coach" && ctx.user.role !== "admin") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Only coaches can access this resource",
    });
  }
  return next({ ctx });
});

const clientProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "client" && ctx.user.role !== "admin") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Only clients can access this resource",
    });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  
  // Authentication
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    
    updateRole: protectedProcedure
      .input(z.object({ role: z.enum(["coach", "client"]) }))
      .mutation(async ({ ctx, input }) => {
        await db.updateUserRole(ctx.user.id, input.role);
        return { success: true };
      }),
    
    generateCoachCode: protectedProcedure.mutation(async ({ ctx }) => {
      // Generate a random 8-character code
      const code = Math.random().toString(36).substring(2, 10).toUpperCase();
      await db.updateUserCode(ctx.user.id, code);
      return { code };
    }),
  }),

  // Coach-Client Management
  clients: router({
    list: coachProcedure.query(async ({ ctx }) => {
      return await db.getCoachClients(ctx.user.id);
    }),
    
    pendingRequests: coachProcedure.query(async ({ ctx }) => {
      return await db.getPendingClientRequests(ctx.user.id);
    }),
    
    acceptRequest: coachProcedure
      .input(z.object({ clientId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        // Check client limit based on plan tier
        const plan = ctx.user.plan || "free";
        const clientCount = await db.getCoachClientCount(ctx.user.id);
        
        let clientLimit: number | null;
        if (plan === "free") {
          clientLimit = 1;
        } else if (plan === "starter") {
          clientLimit = 5;
        } else if (plan === "growth") {
          clientLimit = 10;
        } else if (plan === "professional") {
          clientLimit = 25;
        } else if (plan === "enterprise") {
          clientLimit = null; // unlimited
        } else {
          clientLimit = 1; // fallback
        }
        
        if (clientLimit !== null && clientCount >= clientLimit) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: `Your plan is limited to ${clientLimit} client${clientLimit > 1 ? 's' : ''}. Upgrade to add more clients.`,
          });
        }
        
        await db.createCoachClientRelation(ctx.user.id, input.clientId);
        return { success: true };
      }),
    
    rejectRequest: coachProcedure
      .input(z.object({ clientId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.rejectClientRequest(ctx.user.id, input.clientId);
        return { success: true };
      }),
    
    myCoaches: protectedProcedure.query(async ({ ctx }) => {
      return await db.getClientCoaches(ctx.user.id);
    }),
    
    deleteClient: coachProcedure
      .input(z.object({ clientId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteCoachClientRelation(ctx.user.id, input.clientId);
        return { success: true };
      }),
    
    joinCoachByCode: protectedProcedure
      .input(z.object({ coachCode: z.string() }))
      .mutation(async ({ ctx, input }) => {
        // Find coach by code
        const coach = await db.getUserByCode(input.coachCode);
        
        if (!coach) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Invalid coach code' });
        }
        
        if (coach.role !== 'coach' && coach.role !== 'admin') {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'This code does not belong to a coach' });
        }
        
        // Create pending client request
        await db.createPendingClientRequest(coach.id, ctx.user.id);
        return { success: true, coachName: coach.name };
      }),
  }),

  // Program Blocks (Excel Sheets)
  programBlocks: router({
    create: coachProcedure
      .input(z.object({
        clientId: z.number().optional(),
        title: z.string(),
        description: z.string().optional(),
        totalWeeks: z.number().min(1).max(16).default(8),
        daysPerWeek: z.number().min(1).max(7).default(4),
        startDate: z.date().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const block = await db.createProgramBlock({
          coachId: ctx.user.id,
          ...input,
        });
        return block;
      }),
    
    list: coachProcedure.query(async ({ ctx }) => {
      return await db.getCoachProgramBlocks(ctx.user.id);
    }),
    
    get: protectedProcedure
      .input(z.object({ blockId: z.number() }))
      .query(async ({ input }) => {
        const block = await db.getProgramBlock(input.blockId);
        if (!block) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Program block not found' });
        }
        const exercises = await db.getBlockExercises(input.blockId);
        const cells = await db.getBlockCells(input.blockId);
        return { ...block, exercises, cells };
      }),
    
    update: coachProcedure
      .input(z.object({
        blockId: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(['draft', 'active', 'completed', 'archived']).optional(),
      }))
      .mutation(async ({ input }) => {
        const { blockId, ...data } = input;
        await db.updateProgramBlock(blockId, data);
        return { success: true };
      }),
    
    generateShareCode: coachProcedure
      .input(z.object({ blockId: z.number() }))
      .mutation(async ({ input }) => {
        const code = Math.random().toString(36).substring(2, 8).toUpperCase();
        await db.updateProgramBlock(input.blockId, { shareCode: code } as any);
        return { shareCode: code };
      }),
    
    joinByShareCode: protectedProcedure
      .input(z.object({ shareCode: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const block = await db.getProgramByShareCode(input.shareCode.toUpperCase());
        if (!block) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Program not found with this code' });
        }
        // Clone the program for this client (original stays with coach)
        const clonedBlock = await db.cloneProgramBlock(block.id, block.coachId, ctx.user.id);
        if (!clonedBlock) {
          throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Failed to clone program' });
        }
        // Create coach-client relationship if not exists
        await db.createPendingClientRequest(block.coachId, ctx.user.id);
        // Auto-accept the client
        await db.createCoachClientRelation(block.coachId, ctx.user.id);
        return { success: true, programTitle: block.title };
      }),
    
    myBlocks: protectedProcedure.query(async ({ ctx }) => {
      return await db.getClientProgramBlocks(ctx.user.id);
    }),
    
    markViewed: coachProcedure
      .input(z.object({ blockId: z.number() }))
      .mutation(async ({ input }) => {
        await db.markProgramViewed(input.blockId);
        return { success: true };
      }),
    
    delete: coachProcedure
      .input(z.object({ blockId: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProgramBlock(input.blockId);
        return { success: true };
      }),
  }),
  
  // Coach notifications
  notifications: router({
    unreadComments: coachProcedure.query(async ({ ctx }) => {
      return await db.getUnreadCommentCounts(ctx.user.id);
    }),
    
    clientPrograms: coachProcedure.query(async ({ ctx }) => {
      return await db.getClientProgramsForCoach(ctx.user.id);
    }),
  }),

  // Exercises
  exercises: router({
    create: coachProcedure
      .input(z.object({
        blockId: z.number(),
        dayNumber: z.number(),
        name: z.string(),
        orderIndex: z.number(),
      }))
      .mutation(async ({ input }) => {
        const exercise = await db.createExercise(input);
        return exercise;
      }),
    
    update: coachProcedure
      .input(z.object({
        exerciseId: z.number(),
        name: z.string().optional(),
        orderIndex: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { exerciseId, ...data } = input;
        await db.updateExercise(exerciseId, data);
        return { success: true };
      }),
    
    delete: coachProcedure
      .input(z.object({ exerciseId: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteExercise(input.exerciseId);
        return { success: true };
      }),
  }),

  // Exercise Cells
  cells: router({
    upsert: coachProcedure
      .input(z.object({
        blockId: z.number(),
        exerciseId: z.number(),
        rowNumber: z.number(),
        weekNumber: z.number(),
        dayNumber: z.number(),
        exerciseName: z.string().optional(),
        sets: z.number().optional(),
        reps: z.number().optional(),
        weight: z.string().optional(),
        notes: z.string().optional(),
        rpe: z.string().optional(),
        coachComment: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const cell = await db.upsertExerciseCell(input);
        return cell;
      }),
    
    // Bulk upsert for saving entire grid at once
    bulkUpsert: coachProcedure
      .input(z.object({
        cells: z.array(z.object({
          blockId: z.number(),
          exerciseId: z.number(),
          rowNumber: z.number(),
          weekNumber: z.number(),
          dayNumber: z.number(),
          exerciseName: z.string().optional(),
          sets: z.number().optional(),
          reps: z.number().optional(),
          weight: z.string().optional(),
          notes: z.string().optional(),
          rpe: z.string().optional(),
          coachComment: z.string().optional(),
        })),
      }))
      .mutation(async ({ input }) => {
        for (const cell of input.cells) {
          await db.upsertExerciseCell(cell);
        }
        return { success: true };
      }),
    
    updateCompletion: protectedProcedure
      .input(z.object({
        cellId: z.number(),
        isCompleted: z.boolean(),
        clientNotes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (input.isCompleted) {
          await db.markCellCompleted(input.cellId, input.clientNotes);
          
          // Auto-log main lifts to Progress tracker
          try {
            const database = await db.getDb();
            if (database) {
              const [cell] = await database
                .select()
                .from(exerciseCells)
                .where(eq(exerciseCells.id, input.cellId))
                .limit(1);
              
              if (cell && cell.exerciseName && cell.weight) {
                const liftType = detectMainLift(cell.exerciseName);
                if (liftType) {
                  const [block] = await database
                    .select()
                    .from(programBlocks)
                    .where(eq(programBlocks.id, cell.blockId))
                    .limit(1);
                  
                  if (block) {
                    await db.addLiftPR({
                      clientId: ctx.user.id,
                      coachId: block.coachId,
                      liftType,
                      weight: cell.weight,
                      date: new Date().toISOString().split("T")[0],
                      notes: `Auto-logged from ${cell.exerciseName}`,
                    });
                  }
                }
              }
            }
          } catch (e) {
            console.error("Auto-log lift PR error:", e);
          }
        } else {
          const updateData: Record<string, unknown> = {
            isCompleted: false,
            completedAt: null,
            clientNotes: input.clientNotes || null,
          };
          if (input.clientNotes) {
            updateData.clientCommentedAt = new Date();
          }
          await db.updateExerciseCell(input.cellId, updateData);
        }
        return { success: true };
      }),
    
    uploadVideo: protectedProcedure
      .input(z.object({
        cellId: z.number(),
        videoUrl: z.string(),
      }))
      .mutation(async ({ input }) => {
        await db.updateExerciseCell(input.cellId, {
          videoUrl: input.videoUrl,
        });
        return { success: true };
      }),
    
    markCommentsAsRead: coachProcedure
      .input(z.object({
        blockId: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.markBlockCommentsAsRead(input.blockId);
        return { success: true };
      }),
  }),

  // Videos
  videos: router({
    cleanup: protectedProcedure.mutation(async () => {
      return await db.cleanupExpiredVideos();
    }),
    
    upload: protectedProcedure
      .input(z.object({
        coachId: z.number(),
        exerciseCellId: z.number().optional(),
        exerciseName: z.string().optional(),
        videoUrl: z.string(),
        category: z.enum(['form_check', 'technique', 'warm_up', 'other']).optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const video = await db.createVideo({
          clientId: ctx.user.id,
          ...input,
        });
        return video;
      }),
    
    coachList: coachProcedure.query(async ({ ctx }) => {
      const videos = await db.getCoachVideos(ctx.user.id);
      // Mark all videos as viewed when coach accesses the list
      for (const video of videos) {
        await db.markVideoViewed(video.id);
      }
      return videos;
    }),
    
    markReviewed: coachProcedure
      .input(z.object({
        videoId: z.number(),
        reviewNotes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.updateVideo(input.videoId, {
          reviewed: true,
          reviewNotes: input.reviewNotes,
        });
        return { success: true };
      }),
  }),

  // Lift PRs (Personal Records)
  liftPRs: router({
    list: protectedProcedure
      .input(z.object({ clientId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLiftPRs(input.clientId);
      }),
    
    add: protectedProcedure
      .input(z.object({
        clientId: z.number(),
        coachId: z.number(),
        liftType: z.enum(["squat", "deadlift", "bench"]),
        weight: z.string(),
        date: z.string(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.addLiftPR(input);
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteLiftPR(input.id);
        return { success: true };
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        weight: z.string().optional(),
        date: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateLiftPR(id, data);
        return { success: true };
      }),
  }),

  // Chat
  chat: router({
    send: protectedProcedure
      .input(z.object({
        receiverId: z.number(),
        message: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const msg = await db.createChatMessage({
          senderId: ctx.user.id,
          ...input,
        });
        return msg;
      }),
    
    getMessages: protectedProcedure
      .input(z.object({ otherUserId: z.number() }))
      .query(async ({ ctx, input }) => {
        return await db.getChatMessages(ctx.user.id, input.otherUserId);
      }),
  }),

  // Billing & Plan Management
  billing: router({
    // Webhook endpoint for external payment site to upgrade users
    // Purchases STACK: buying 10-user pack then 4 per-user = 1 free + 10 + 4 = 15 total
    upgradeToPremium: publicProcedure
      .input(z.object({
        userId: z.number(),
        webhookSecret: z.string(),
        plan: z.enum(["free", "starter", "growth", "professional", "enterprise"]),
        userCount: z.number().optional(), // Number of client slots to ADD (stacks with existing)
        durationDays: z.number().optional(), // Subscription duration in days
      }))
      .mutation(async ({ input }) => {
        console.log('[BILLING WEBHOOK] Received upgrade request:', { userId: input.userId, plan: input.plan, userCount: input.userCount, durationDays: input.durationDays });
        
        // Verify webhook secret
        const expectedSecret = process.env.BILLING_WEBHOOK_SECRET;
        if (!expectedSecret || input.webhookSecret !== expectedSecret) {
          console.log('[BILLING WEBHOOK] Invalid secret - expected:', expectedSecret?.substring(0, 5) + '...', 'got:', input.webhookSecret.substring(0, 5) + '...');
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Invalid webhook secret",
          });
        }
        
        console.log('[BILLING WEBHOOK] Secret verified successfully');

        // Calculate expiry date
        let planExpiresAt: Date | null = null;
        if (input.plan !== "free" && input.durationDays) {
          planExpiresAt = new Date(Date.now() + input.durationDays * 24 * 60 * 60 * 1000);
        }

        // Map plan to slot count
        let totalSlots = 0;
        if (input.plan === "starter") {
          totalSlots = 5;
        } else if (input.plan === "growth") {
          totalSlots = 10;
        } else if (input.plan === "professional") {
          totalSlots = 25;
        } else if (input.plan === "enterprise") {
          totalSlots = 999; // Unlimited represented as high number
        }

        // Update user plan with absolute slot count
        await db.updateUserPlan(input.userId, input.plan, totalSlots, planExpiresAt, "active");

        console.log('[BILLING WEBHOOK] Upgrade completed successfully:', { userId: input.userId, plan: input.plan, totalSlots, expiresAt: planExpiresAt });
        return { success: true, userId: input.userId, plan: input.plan, totalSlots, expiresAt: planExpiresAt };
      }),

    // Get current user's plan and client count
    // Client limit = 1 (free) + userCount (all purchased slots stacked together)
    // Enterprise = unlimited regardless of userCount
    getMyPlanStatus: protectedProcedure
      .query(async ({ ctx }) => {
        const clientCount = await db.getCoachClientCount(ctx.user.id);
        let plan = ctx.user.plan || "free";
        const planExpiresAt = (ctx.user as any).planExpiresAt as Date | null;
        const userCount = ctx.user.userCount || 0;
        
        // Check if subscription has expired
        const isExpired = planExpiresAt && plan !== "free" && new Date(planExpiresAt) < new Date();
        const effectivePlan = isExpired ? "free" : plan;
        
        // Calculate client limit based on tier
        let clientLimit: number | null;
        if (effectivePlan === "free") {
          clientLimit = 1;
        } else if (effectivePlan === "starter") {
          clientLimit = 5;
        } else if (effectivePlan === "growth") {
          clientLimit = 10;
        } else if (effectivePlan === "professional") {
          clientLimit = 25;
        } else if (effectivePlan === "enterprise") {
          clientLimit = null; // unlimited
        } else {
          clientLimit = 1; // fallback
        }
        
        // Account is frozen if expired and has more clients than free tier allows
        const isFrozen = isExpired && clientCount > 1;
        
        // Calculate days remaining
        let daysRemaining: number | null = null;
        if (planExpiresAt && !isExpired) {
          daysRemaining = Math.ceil((new Date(planExpiresAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        }
        
        return {
          plan: effectivePlan,
          originalPlan: plan,
          clientCount,
          clientLimit,
          userCount,
          isFrozen: !!isFrozen,
          isExpired: !!isExpired,
          planExpiresAt: planExpiresAt ? new Date(planExpiresAt) : null,
          daysRemaining,
        };
      }),
  }),

  // Account management
  account: router({
    deleteAllData: protectedProcedure
      .mutation(async ({ ctx }) => {
        await db.deleteAllUserData(ctx.user.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
