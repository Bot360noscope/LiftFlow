import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the database module
vi.mock("./db", () => ({
  getLiftPRs: vi.fn(),
  addLiftPR: vi.fn(),
  deleteLiftPR: vi.fn(),
  updateLiftPR: vi.fn(),
}));

import * as db from "./db";

describe("Lift PRs", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("getLiftPRs", () => {
    it("should return an array of PRs for a client", async () => {
      const mockPRs = [
        { id: 1, clientId: 1, coachId: 1, liftType: "squat", weight: "100", date: new Date("2026-01-01"), notes: null, createdAt: new Date() },
        { id: 2, clientId: 1, coachId: 1, liftType: "deadlift", weight: "140", date: new Date("2026-01-01"), notes: "Sumo", createdAt: new Date() },
        { id: 3, clientId: 1, coachId: 1, liftType: "bench", weight: "80", date: new Date("2026-01-01"), notes: null, createdAt: new Date() },
      ];
      vi.mocked(db.getLiftPRs).mockResolvedValue(mockPRs);

      const result = await db.getLiftPRs(1);
      expect(result).toHaveLength(3);
      expect(result[0].liftType).toBe("squat");
      expect(result[1].liftType).toBe("deadlift");
      expect(result[2].liftType).toBe("bench");
      expect(db.getLiftPRs).toHaveBeenCalledWith(1);
    });

    it("should return empty array when no PRs exist", async () => {
      vi.mocked(db.getLiftPRs).mockResolvedValue([]);

      const result = await db.getLiftPRs(999);
      expect(result).toHaveLength(0);
    });
  });

  describe("addLiftPR", () => {
    it("should add a new PR entry", async () => {
      vi.mocked(db.addLiftPR).mockResolvedValue({ id: 1 });

      const result = await db.addLiftPR({
        clientId: 1,
        coachId: 1,
        liftType: "squat",
        weight: "120",
        date: "2026-02-12",
        notes: "New PR!",
      });

      expect(result).toEqual({ id: 1 });
      expect(db.addLiftPR).toHaveBeenCalledWith({
        clientId: 1,
        coachId: 1,
        liftType: "squat",
        weight: "120",
        date: "2026-02-12",
        notes: "New PR!",
      });
    });

    it("should handle deadlift type (includes sumo)", async () => {
      vi.mocked(db.addLiftPR).mockResolvedValue({ id: 2 });

      const result = await db.addLiftPR({
        clientId: 1,
        coachId: 1,
        liftType: "deadlift",
        weight: "180",
        date: "2026-02-12",
        notes: "Sumo deadlift",
      });

      expect(result).toEqual({ id: 2 });
      expect(db.addLiftPR).toHaveBeenCalledWith(
        expect.objectContaining({ liftType: "deadlift", notes: "Sumo deadlift" })
      );
    });
  });

  describe("deleteLiftPR", () => {
    it("should delete a PR by id", async () => {
      vi.mocked(db.deleteLiftPR).mockResolvedValue(undefined);

      await db.deleteLiftPR(1);
      expect(db.deleteLiftPR).toHaveBeenCalledWith(1);
    });
  });

  describe("updateLiftPR", () => {
    it("should update weight of a PR", async () => {
      vi.mocked(db.updateLiftPR).mockResolvedValue(undefined);

      await db.updateLiftPR(1, { weight: "130" });
      expect(db.updateLiftPR).toHaveBeenCalledWith(1, { weight: "130" });
    });

    it("should update date and notes", async () => {
      vi.mocked(db.updateLiftPR).mockResolvedValue(undefined);

      await db.updateLiftPR(1, { date: "2026-03-01", notes: "Updated" });
      expect(db.updateLiftPR).toHaveBeenCalledWith(1, { date: "2026-03-01", notes: "Updated" });
    });
  });
});
