import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import multer from "multer";
import { nanoid } from "nanoid";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { storagePut } from "../storage";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // File upload endpoint
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 16 * 1024 * 1024 } });
  app.post("/api/upload", upload.single("file"), async (req, res) => {
    try {
      const file = req.file;
      if (!file) {
        res.status(400).json({ error: "No file provided" });
        return;
      }
      const ext = file.originalname.split(".").pop() || "mp4";
      const key = `videos/${nanoid()}.${ext}`;
      const { url } = await storagePut(key, file.buffer, file.mimetype);
      res.json({ url });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ error: "Upload failed" });
    }
  });

  // Download video endpoint
  app.get("/api/download", async (req, res) => {
    try {
      const { url } = req.query;
      if (!url || typeof url !== "string") {
        res.status(400).json({ error: "URL parameter required" });
        return;
      }
      const response = await fetch(url);
      if (!response.ok) {
        res.status(response.status).json({ error: "Failed to fetch video" });
        return;
      }
      const contentType = response.headers.get("content-type") || "video/webm";
      const filename = new URL(url).pathname.split("/").pop() || "video.webm";
      res.setHeader("Content-Type", contentType);
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.setHeader("Cache-Control", "no-cache");
      const buffer = await response.arrayBuffer();
      res.send(Buffer.from(buffer));
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ error: "Download failed" });
    }
  });

  // Payment webhook endpoint (REST API for payment site)
  app.post("/api/webhooks/payment", async (req, res) => {
    try {
      console.log('[PAYMENT WEBHOOK] Received payment notification:', req.body);
      
      const { email, plan, durationDays, webhookSecret, userCount, status, periodEnd } = req.body;
      
      // Verify webhook secret
      const expectedSecret = process.env.BILLING_WEBHOOK_SECRET;
      if (!expectedSecret || webhookSecret !== expectedSecret) {
        console.log('[PAYMENT WEBHOOK] Invalid secret');
        res.status(401).json({ success: false, error: 'Invalid webhook secret' });
        return;
      }
      
      console.log('[PAYMENT WEBHOOK] Secret verified, looking up user by email:', email);
      
      // Import db functions
      const db = await import('../db');
      
      // Find user by email
      const user = await db.getUserByEmail(email);
      if (!user) {
        console.log('[PAYMENT WEBHOOK] User not found:', email);
        res.status(404).json({ success: false, error: 'User not found' });
        return;
      }
      
      console.log('[PAYMENT WEBHOOK] Found user:', user.id, user.name);
      
      // Calculate expiry date from periodEnd or durationDays
      let planExpiresAt: Date | null = null;
      if (periodEnd) {
        // Use periodEnd from subscription (preferred)
        planExpiresAt = new Date(periodEnd);
      } else if (durationDays) {
        // Fallback to durationDays for backward compatibility
        planExpiresAt = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000);
      }
      
      // Determine subscription status
      const subscriptionStatus = status || 'active';
      
      // Map payment site tier names to LiftFlow plan names
      let liftflowPlan: string;
      let totalSlots = 0;
      
      if (plan === 'tier_5') {
        liftflowPlan = 'starter';
        totalSlots = 5;
      } else if (plan === 'tier_10') {
        liftflowPlan = 'growth';
        totalSlots = 10;
      } else if (plan === 'tier_25') {
        liftflowPlan = 'professional';
        totalSlots = 25;
      } else if (plan === 'enterprise') {
        liftflowPlan = 'enterprise';
        totalSlots = 999; // Unlimited
      } else if (plan === 'free') {
        liftflowPlan = 'free';
        totalSlots = 0;
      } else if (plan === 'starter' || plan === 'growth' || plan === 'professional') {
        // Already in LiftFlow format
        liftflowPlan = plan;
        if (plan === 'starter') totalSlots = 5;
        else if (plan === 'growth') totalSlots = 10;
        else if (plan === 'professional') totalSlots = 25;
      } else {
        // Fallback: use userCount if provided
        liftflowPlan = 'free';
        totalSlots = userCount || 0;
      }
      
      console.log('[PAYMENT WEBHOOK] Processing subscription:', {
        originalPlan: plan,
        liftflowPlan,
        totalSlots,
        status: subscriptionStatus,
        expires: planExpiresAt
      });
      
      // Handle subscription status
      if (subscriptionStatus === 'active') {
        // Active subscription - set total slots
        await db.updateUserPlan(user.id, liftflowPlan as any, totalSlots, planExpiresAt, subscriptionStatus);
        console.log('[PAYMENT WEBHOOK] Subscription activated with', totalSlots, 'total slots');
      } else if (subscriptionStatus === 'canceled') {
        // Canceled - maintain access until period end
        await db.updateUserPlan(user.id, liftflowPlan as any, totalSlots, planExpiresAt, subscriptionStatus);
        console.log('[PAYMENT WEBHOOK] Subscription canceled, access until:', planExpiresAt);
      } else if (subscriptionStatus === 'past_due') {
        // Payment failed - mark as past_due
        await db.updateUserPlan(user.id, liftflowPlan as any, totalSlots, planExpiresAt, subscriptionStatus);
        console.log('[PAYMENT WEBHOOK] Subscription past due');
      }
      
      console.log('[PAYMENT WEBHOOK] Upgrade completed successfully');
      res.json({ success: true });
    } catch (error) {
      console.error('[PAYMENT WEBHOOK] Error:', error);
      res.status(500).json({ success: false, error: 'Internal server error' });
    }
  });

  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
