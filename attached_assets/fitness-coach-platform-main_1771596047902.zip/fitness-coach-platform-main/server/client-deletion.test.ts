import { describe, it, expect, beforeEach } from "vitest";
import { 
  deleteCoachClientRelation, 
  createCoachClientRelation,
  getCoachPrograms,
  getDb
} from "./db";
import { programBlocks, exerciseCells, users, coachClients } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

describe("Client Deletion with Program Cleanup", () => {
  let coachId: number;
  let clientId: number;
  let templateProgramId: number;
  let clientProgramId: number;

  beforeEach(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Create coach
    const [coach] = await db.insert(users).values({
      openId: `test-coach-${Date.now()}`,
      name: "Test Coach",
      email: `coach-${Date.now()}@test.com`,
      role: "coach"
    });
    coachId = coach.insertId;

    // Create client
    const [client] = await db.insert(users).values({
      openId: `test-client-${Date.now()}`,
      name: "Test Client",
      email: `client-${Date.now()}@test.com`,
      role: "user"
    });
    clientId = client.insertId;

    // Create coach-client relationship
    await createCoachClientRelation(coachId, clientId);

    // Create template program (no client assigned)
    const [template] = await db.insert(programBlocks).values({
      coachId,
      clientId: null,
      name: "Template Program",
      weeks: 4,
      daysPerWeek: 3
    });
    templateProgramId = template.insertId;

    // Add cells to template
    await db.insert(exerciseCells).values([
      { blockId: templateProgramId, week: 1, day: 1, row: 1, col: "exercise", value: "Squat" },
      { blockId: templateProgramId, week: 1, day: 1, row: 1, col: "weight", value: "135" }
    ]);

    // Create client program copy
    const [clientProgram] = await db.insert(programBlocks).values({
      coachId,
      clientId,
      name: "Client Program Copy",
      weeks: 4,
      daysPerWeek: 3
    });
    clientProgramId = clientProgram.insertId;

    // Add cells to client program
    await db.insert(exerciseCells).values([
      { blockId: clientProgramId, week: 1, day: 1, row: 1, col: "exercise", value: "Squat" },
      { blockId: clientProgramId, week: 1, day: 1, row: 1, col: "weight", value: "135" }
    ]);
  });

  it("should delete client's program copy when deleting client", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Verify initial state: 2 programs (template + client copy)
    const programsBefore = await getCoachPrograms(coachId);
    expect(programsBefore.length).toBe(2);

    // Delete client
    await deleteCoachClientRelation(coachId, clientId);

    // Verify: Only 1 program remains (template)
    const programsAfter = await getCoachPrograms(coachId);
    expect(programsAfter.length).toBe(1);
    expect(programsAfter[0].id).toBe(templateProgramId);
  });

  it("should delete exercise cells when deleting client program", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Verify initial state: cells exist for client program
    const cellsBefore = await db
      .select()
      .from(exerciseCells)
      .where(eq(exerciseCells.blockId, clientProgramId));
    expect(cellsBefore.length).toBe(2);

    // Delete client
    await deleteCoachClientRelation(coachId, clientId);

    // Verify: Client program cells are deleted
    const cellsAfter = await db
      .select()
      .from(exerciseCells)
      .where(eq(exerciseCells.blockId, clientProgramId));
    expect(cellsAfter.length).toBe(0);
  });

  it("should NOT delete template program when deleting client", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Delete client
    await deleteCoachClientRelation(coachId, clientId);

    // Verify: Template program still exists
    const templateProgram = await db
      .select()
      .from(programBlocks)
      .where(eq(programBlocks.id, templateProgramId));
    expect(templateProgram.length).toBe(1);

    // Verify: Template cells still exist
    const templateCells = await db
      .select()
      .from(exerciseCells)
      .where(eq(exerciseCells.blockId, templateProgramId));
    expect(templateCells.length).toBe(2);
  });

  it("should delete coach-client relationship", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Verify initial state: relationship exists
    const relationshipBefore = await db
      .select()
      .from(coachClients)
      .where(and(
        eq(coachClients.coachId, coachId),
        eq(coachClients.clientId, clientId)
      ));
    expect(relationshipBefore.length).toBe(1);

    // Delete client
    await deleteCoachClientRelation(coachId, clientId);

    // Verify: Relationship is deleted
    const relationshipAfter = await db
      .select()
      .from(coachClients)
      .where(and(
        eq(coachClients.coachId, coachId),
        eq(coachClients.clientId, clientId)
      ));
    expect(relationshipAfter.length).toBe(0);
  });
});
