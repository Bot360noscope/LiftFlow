import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { useState } from "react";
import {
  Dumbbell,
  LogOut,
  TrendingUp,
  ChevronRight,
  UserPlus,
  KeyRound,
  Plus,
  Activity,
  Trash2,
} from "lucide-react";
import { PrivacyPolicy } from "@/components/PrivacyPolicy";
import { TermsOfService } from "@/components/TermsOfService";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function ClientDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [shareCode, setShareCode] = useState("");
  const [coachCode, setCoachCode] = useState("");
  const [joinCoachOpen, setJoinCoachOpen] = useState(false);
  const [joinProgramOpen, setJoinProgramOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const { data: myPrograms, refetch: refetchPrograms } = trpc.programBlocks.myBlocks.useQuery();
  const { data: progressData } = trpc.liftPRs.list.useQuery(
    { clientId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  const joinMutation = trpc.programBlocks.joinByShareCode.useMutation({
    onSuccess: (data: any) => {
      toast.success(`Joined program: ${data.programTitle}`);
      setShareCode("");
      setJoinProgramOpen(false);
      refetchPrograms();
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to join program");
    },
  });

  const deleteAllDataMutation = trpc.account.deleteAllData.useMutation({
    onSuccess: async () => {
      toast.success("All data deleted successfully");
      await logout();
      navigate("/");
    },
    onError: (error: any) => {
      toast.error(`Failed to delete data: ${error.message}`);
    },
  });

  const joinCoachMutation = trpc.clients.joinCoachByCode.useMutation({
    onSuccess: (data: any) => {
      toast.success(`Join request sent to ${data.coachName}!`);
      setCoachCode("");
      setJoinCoachOpen(false);
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to join coach");
    },
  });

  const handleJoin = () => {
    if (!shareCode.trim()) {
      toast.error("Please enter a share code");
      return;
    }
    joinMutation.mutate({ shareCode: shareCode.trim().toUpperCase() });
  };

  const handleJoinCoach = () => {
    if (!coachCode.trim()) {
      toast.error("Please enter a coach code");
      return;
    }
    joinCoachMutation.mutate({ coachCode: coachCode.trim().toUpperCase() });
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  // Get latest PRs for quick stats
  const latestSquat = progressData?.filter((p: any) => p.liftType === "squat").slice(-1)[0];
  const latestDeadlift = progressData?.filter((p: any) => p.liftType === "deadlift").slice(-1)[0];
  const latestBench = progressData?.filter((p: any) => p.liftType === "bench").slice(-1)[0];

  return (
    <div className="min-h-screen bg-background">
      {/* Top Header Bar */}
      <div className="bg-primary text-primary-foreground">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="text-lg font-bold tracking-tight">LiftFlow</span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={handleLogout}
              variant="ghost"
              size="sm"
              className="text-primary-foreground hover:bg-white/15"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 pb-8">
        {/* Welcome Section */}
        <div className="py-5">
          <h1 className="text-2xl font-bold text-foreground">
            Hey, {user?.name?.split(" ")[0] || "Athlete"}
          </h1>
          <p className="text-muted-foreground text-sm mt-0.5">Let's get after it today.</p>
        </div>

        {/* Quick Actions Row */}
        <div className="flex gap-2 mb-6">
          <Dialog open={joinCoachOpen} onOpenChange={setJoinCoachOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="flex-1 gap-1.5 h-9 text-xs font-medium">
                <UserPlus className="h-3.5 w-3.5" />
                Join Coach
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-sm">
              <DialogHeader>
                <DialogTitle>Join a Coach</DialogTitle>
              </DialogHeader>
              <p className="text-sm text-muted-foreground">
                Enter your coach's code to send them a join request.
              </p>
              <div className="flex gap-2 mt-2">
                <Input
                  value={coachCode}
                  onChange={(e) => setCoachCode(e.target.value.toUpperCase())}
                  placeholder="Coach code..."
                  className="flex-1 font-mono text-center tracking-wider"
                  maxLength={8}
                  onKeyDown={(e) => e.key === "Enter" && handleJoinCoach()}
                />
                <Button onClick={handleJoinCoach} disabled={joinCoachMutation.isPending} size="sm">
                  {joinCoachMutation.isPending ? "..." : "Join"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={joinProgramOpen} onOpenChange={setJoinProgramOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="flex-1 gap-1.5 h-9 text-xs font-medium">
                <KeyRound className="h-3.5 w-3.5" />
                Join Program
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-sm">
              <DialogHeader>
                <DialogTitle>Join a Program</DialogTitle>
              </DialogHeader>
              <p className="text-sm text-muted-foreground">
                Enter the share code from your coach to join a program.
              </p>
              <div className="flex gap-2 mt-2">
                <Input
                  value={shareCode}
                  onChange={(e) => setShareCode(e.target.value.toUpperCase())}
                  placeholder="Share code..."
                  className="flex-1 font-mono text-center tracking-wider"
                  maxLength={8}
                  onKeyDown={(e) => e.key === "Enter" && handleJoin()}
                />
                <Button onClick={handleJoin} disabled={joinMutation.isPending} size="sm">
                  {joinMutation.isPending ? "..." : "Join"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Progress Quick Stats */}
        <div
          className="bg-card rounded-xl border shadow-sm mb-4 cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => navigate("/client/progress")}
        >
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              <span className="font-semibold text-sm">My Progress</span>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
          <div className="grid grid-cols-3 divide-x">
            <div className="p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Squat</p>
              <p className="text-lg font-bold text-foreground mt-0.5">
                {latestSquat?.weight ? `${latestSquat.weight}` : "—"}
              </p>
              {latestSquat?.weight && (
                <p className="text-[10px] text-muted-foreground">lbs</p>
              )}
            </div>
            <div className="p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Bench</p>
              <p className="text-lg font-bold text-foreground mt-0.5">
                {latestBench?.weight ? `${latestBench.weight}` : "—"}
              </p>
              {latestBench?.weight && (
                <p className="text-[10px] text-muted-foreground">lbs</p>
              )}
            </div>
            <div className="p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Deadlift</p>
              <p className="text-lg font-bold text-foreground mt-0.5">
                {latestDeadlift?.weight ? `${latestDeadlift.weight}` : "—"}
              </p>
              {latestDeadlift?.weight && (
                <p className="text-[10px] text-muted-foreground">lbs</p>
              )}
            </div>
          </div>
        </div>

        {/* My Programs */}
        <div className="bg-card rounded-xl border shadow-sm">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <div className="flex items-center gap-2">
              <Dumbbell className="h-4 w-4 text-primary" />
              <span className="font-semibold text-sm">My Programs</span>
            </div>
            <span className="text-xs text-muted-foreground">
              {myPrograms?.length || 0} program{(myPrograms?.length || 0) !== 1 ? "s" : ""}
            </span>
          </div>

          {myPrograms && myPrograms.length > 0 ? (
            <div className="divide-y">
              {myPrograms.map((program: any) => (
                <div
                  key={program.id}
                  className="flex items-center justify-between px-4 py-3.5 hover:bg-accent/50 cursor-pointer transition-colors"
                  onClick={() => navigate(`/client/program/${program.id}`)}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm text-foreground truncate">{program.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {program.totalWeeks} weeks &middot; {program.daysPerWeek} days/week
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wider ${
                        program.status === "active"
                          ? "bg-primary/10 text-primary"
                          : program.status === "completed"
                          ? "bg-blue-50 text-blue-600"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {program.status}
                    </span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 px-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Plus className="h-6 w-6 text-primary" />
              </div>
              <p className="text-sm font-medium text-foreground mb-1">No programs yet</p>
              <p className="text-xs text-muted-foreground">
                Use "Join Program" above to enter your coach's share code.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Delete Account Section */}
      <div className="max-w-5xl mx-auto px-4 pb-8">
        <div className="border-t pt-6 mt-2 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            className="text-destructive hover:text-destructive hover:bg-destructive/10 text-xs"
            onClick={() => setDeleteDialogOpen(true)}
          >
            <Trash2 className="h-3.5 w-3.5 mr-1.5" />
            Delete All My Data
          </Button>
          <div className="flex items-center gap-3">
            <PrivacyPolicy
              trigger={
                <button className="text-xs text-muted-foreground underline hover:text-foreground transition-colors">
                  Privacy Policy
                </button>
              }
            />
            <span className="text-xs text-muted-foreground">&middot;</span>
            <TermsOfService
              trigger={
                <button className="text-xs text-muted-foreground underline hover:text-foreground transition-colors">
                  Terms of Service
                </button>
              }
            />
          </div>
        </div>
      </div>

      {/* Delete All Data Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete All My Data</DialogTitle>
            <DialogDescription>
              This will permanently delete all your data including:
            </DialogDescription>
          </DialogHeader>
          <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1 px-2">
            <li>All your programs and progress</li>
            <li>All personal records (PRs)</li>
            <li>All uploaded videos</li>
            <li>All coach connections</li>
          </ul>
          <p className="text-sm font-semibold text-destructive px-2">
            This action cannot be undone.
          </p>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                deleteAllDataMutation.mutate();
              }}
              disabled={deleteAllDataMutation.isPending}
            >
              {deleteAllDataMutation.isPending ? "Deleting..." : "Delete Everything"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
