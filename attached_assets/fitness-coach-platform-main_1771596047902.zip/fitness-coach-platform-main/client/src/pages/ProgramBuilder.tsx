import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useLocation, useRoute } from "wouter";
import { Capacitor } from "@capacitor/core";
import { Browser } from "@capacitor/browser";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  ArrowLeft,
  Plus,
  Trash,
  Copy,
  Check,
  Share2,
  ChevronDown,
  Save,
  Trash2,
  Video,
  MessageSquare,
  Download,
  X,
} from "lucide-react";

// Types for local grid state
interface GridRow {
  exerciseId: number | null;
  tempId: string;
  name: string;
}

interface CellData {
  cellId: number | null;
  exerciseName: string; // each cell has its own exercise name
  weight: string; // weight like "135 lbs" or "60 kg"
  prescription: string; // free text like "3×5" or "40×5 50×5 60×5"
  rpe: string; // Rate of Perceived Exertion
  videoUrl: string; // client video URL
  isCompleted: boolean;
  clientNotes: string;
  coachComment: string;
}

type GridState = Record<string, CellData>; // key: `${rowIdx}-${weekNum}-${dayNum}`

function cellKey(rowIdx: number, weekNum: number, dayNum: number) {
  return `${rowIdx}-${weekNum}-${dayNum}`;
}

const emptyCellData: CellData = {
  cellId: null,
  exerciseName: "",
  weight: "",
  prescription: "",
  rpe: "",
  videoUrl: "",
  isCompleted: false,
  clientNotes: "",
  coachComment: "",
};

export default function ProgramBuilder() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [, params] = useRoute("/coach/program/:id");
  const blockId = params?.id ? parseInt(params.id) : null;

  // Grid state
  const [rows, setRows] = useState<GridRow[]>([]);
  const [grid, setGrid] = useState<GridState>({});
  const [activeWeek, setActiveWeek] = useState(1);
  const [hasChanges, setHasChanges] = useState(false);
  const [shareCode, setShareCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [saving, setSaving] = useState(false);

  const utils = trpc.useUtils();

  // Fetch program data
  const { data: blockData, isLoading } = trpc.programBlocks.get.useQuery(
    { blockId: blockId! },
    { enabled: !!blockId }
  );

  const createExerciseMutation = trpc.exercises.create.useMutation();
  const updateExerciseMutation = trpc.exercises.update.useMutation();
  const deleteExerciseMutation = trpc.exercises.delete.useMutation();
  const cellUpsertMutation = trpc.cells.upsert.useMutation();
  const uploadVideoMutation = trpc.cells.uploadVideo.useMutation();
  const deleteProgramMutation = trpc.programBlocks.delete.useMutation({
    onSuccess: () => {
      toast.success("Program deleted successfully");
      navigate("/coach");
    },
    onError: (error) => {
      toast.error(`Failed to delete: ${error.message}`);
    },
  });

  const generateShareCodeMutation = trpc.programBlocks.generateShareCode.useMutation({
    onSuccess: (data) => {
      setShareCode(data.shareCode);
      toast.success("Share code generated!");
    },
  });

  const markCommentsAsReadMutation = trpc.cells.markCommentsAsRead.useMutation();

  // Initialize grid from fetched data
  useEffect(() => {
    if (!blockData) return;

    setShareCode(blockData.shareCode || null);

    // Mark all comments as read for this program when coach opens it
    if (blockId) {
      markCommentsAsReadMutation.mutate({ blockId });
    }

    // Load cells from database and figure out how many rows we need
    const newGrid: GridState = {};
    let maxRowNumber = 0;

    for (const cell of blockData.cells) {
      if (cell.rowNumber !== null && cell.rowNumber !== undefined) {
        const key = cellKey(cell.rowNumber, cell.weekNumber, cell.dayNumber);
        newGrid[key] = {
          cellId: cell.id,
          exerciseName: cell.exerciseName || "",
          weight: cell.weight || "",
          prescription: cell.notes || "",
          rpe: cell.rpe || "",
          videoUrl: cell.videoUrl || "",
          isCompleted: cell.isCompleted || false,
          clientNotes: cell.clientNotes || "",
          coachComment: (cell as any).coachComment || "",
        };
        maxRowNumber = Math.max(maxRowNumber, cell.rowNumber);
      }
    }

    // Create rows based on max row number found in cells, or default to 5 empty rows
    const numRows = Math.max(maxRowNumber + 1, 5);
    const initialRows: GridRow[] = Array.from({ length: numRows }, (_, i) => ({
      exerciseId: null,
      tempId: `row-${i}`,
      name: "", // name is no longer used, kept for compatibility
    }));

    setRows(initialRows);
    setGrid(newGrid);
    setHasChanges(false);
  }, [blockData]);

  // Get cell data helper
  const getCell = useCallback(
    (rowIdx: number, weekNum: number, dayNum: number): CellData => {
      const key = cellKey(rowIdx, weekNum, dayNum);
      return grid[key] || { ...emptyCellData };
    },
    [grid]
  );

  // Get placeholder for weight input (shows previous week's weight)
  const getWeightPlaceholder = useCallback(
    (rowIdx: number, weekNum: number, dayNum: number): string => {
      if (weekNum === 1) return "e.g. 135 lbs";
      
      // Look for previous week's weight for same exercise/day
      const prevWeekCell = getCell(rowIdx, weekNum - 1, dayNum);
      if (prevWeekCell.weight) {
        return prevWeekCell.weight;
      }
      
      return "e.g. 135 lbs";
    },
    [getCell]
  );

  // Update cell
  // Auto-save a single cell on blur
  const autoSaveCell = useCallback(
    async (rowIdx: number, weekNum: number, dayNum: number) => {
      if (!blockId) return;
      const cell = getCell(rowIdx, weekNum, dayNum);
      if (!cell.exerciseName && !cell.weight && !cell.prescription && !cell.rpe && !cell.coachComment) return;
      try {
        await cellUpsertMutation.mutateAsync({
          blockId: blockId,
          exerciseId: blockId,
          rowNumber: rowIdx,
          weekNumber: weekNum,
          dayNumber: dayNum,
          exerciseName: cell.exerciseName,
          weight: cell.weight,
          notes: cell.prescription,
          rpe: cell.rpe,
          coachComment: cell.coachComment,
        });
      } catch (error) {
        console.error('Auto-save failed:', error);
      }
    },
    [blockId, getCell, cellUpsertMutation]
  );

  const updateCell = useCallback(
    (rowIdx: number, weekNum: number, dayNum: number, field: keyof CellData, value: string | boolean) => {
      const key = cellKey(rowIdx, weekNum, dayNum);
      setGrid((prev) => {
        const newGrid = {
          ...prev,
          [key]: {
            ...(prev[key] || { ...emptyCellData }),
            [field]: value,
          },
        };

        // Auto-copy exercise names from Week 1 to all other weeks
        if (field === 'exerciseName' && weekNum === 1 && typeof value === 'string') {
          // Copy to Week 2, 3, 4...
          for (let w = 2; w <= 4; w++) {
            const targetKey = cellKey(rowIdx, w, dayNum);
            newGrid[targetKey] = {
              ...(newGrid[targetKey] || { ...emptyCellData }),
              exerciseName: value,
            };
          }
        }

        return newGrid;
      });
      setHasChanges(true);
    },
    []
  );

  // Add exercise row
  const addRow = useCallback(() => {
    setRows((prev) => [
      ...prev,
      {
        exerciseId: null,
        tempId: `new-${Date.now()}-${Math.random()}`,
        name: "",
      },
    ]);
    setHasChanges(true);
  }, []);

  // Remove exercise row
  const removeRow = useCallback(
    (rowIdx: number) => {
      const row = rows[rowIdx];
      if (row.exerciseId) {
        deleteExerciseMutation.mutate(
          { exerciseId: row.exerciseId },
          {
            onSuccess: () => {
              setRows((prev) => prev.filter((_, i) => i !== rowIdx));
              setGrid((prev) => {
                const newGrid = { ...prev };
                Object.keys(newGrid).forEach((key) => {
                  if (key.startsWith(`${rowIdx}-`)) {
                    delete newGrid[key];
                  }
                });
                return newGrid;
              });
              toast.success("Exercise removed");
            },
          }
        );
      } else {
        setRows((prev) => prev.filter((_, i) => i !== rowIdx));
      }
    },
    [rows, deleteExerciseMutation]
  );

  // Save all changes
  const handleSave = useCallback(async () => {
    if (!blockId) return;
    setSaving(true);

    try {
      // Save all cells (exercise names are now stored in cells, not in separate exercises table)
      for (const [key, cell] of Object.entries(grid)) {
        const [rowIdxStr, weekStr, dayStr] = key.split("-");
        const rowIdx = parseInt(rowIdxStr);
        const weekNum = parseInt(weekStr);
        const dayNum = parseInt(dayStr);

        // Skip empty cells
        if (!cell.exerciseName && !cell.weight && !cell.prescription && !cell.rpe && !cell.coachComment) continue;

        // Use a dummy exerciseId (we'll use blockId as a placeholder since we're not using exercises table anymore)
        await cellUpsertMutation.mutateAsync({
          blockId: blockId,
          exerciseId: blockId, // placeholder, will be refactored later
          rowNumber: rowIdx,
          weekNumber: weekNum,
          dayNumber: dayNum,
          exerciseName: cell.exerciseName,
          weight: cell.weight,
          notes: cell.prescription,
          rpe: cell.rpe,
          coachComment: cell.coachComment,
        });
      }

      await utils.programBlocks.get.invalidate({ blockId });
      setHasChanges(false);
      toast.success("Program saved!");
    } catch (error) {
      toast.error("Failed to save program");
      console.error(error);
    } finally {
      setSaving(false);
    }
  }, [blockId, rows, grid, createExerciseMutation, updateExerciseMutation, cellUpsertMutation, utils]);

  // Generate share code
  const handleGenerateShareCode = () => {
    if (!blockId) return;
    generateShareCodeMutation.mutate({ blockId });
  };

  const handleCopyCode = () => {
    if (!shareCode) return;
    navigator.clipboard.writeText(shareCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Share code copied!");
  };

  // Remove video from cell
  const handleRemoveVideo = (rowIdx: number, week: number, day: number) => {
    const key = cellKey(rowIdx, week, day);
    const cell = grid[key];
    if (!cell?.cellId) {
      toast.error("No exercise data in this cell");
      return;
    }

    if (!confirm("Are you sure you want to remove this video?")) return;

    uploadVideoMutation.mutate(
      { cellId: cell.cellId, videoUrl: "" },
      {
        onSuccess: () => {
          setGrid((prev) => ({
            ...prev,
            [key]: { ...prev[key], videoUrl: "" },
          }));
          toast.success("Video removed!");
        },
        onError: () => toast.error("Failed to remove video"),
      }
    );
  };

  // Memoize week/day numbers
  const totalWeeks = blockData?.totalWeeks || 8;
  const daysPerWeek = blockData?.daysPerWeek || 4;
  const weekNumbers = useMemo(() => Array.from({ length: totalWeeks }, (_, i) => i + 1), [totalWeeks]);
  const dayNumbers = useMemo(() => Array.from({ length: daysPerWeek }, (_, i) => i + 1), [daysPerWeek]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b bg-primary text-primary-foreground px-4 py-3 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/coach")} className="text-primary-foreground hover:bg-white/15">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-lg font-bold text-primary-foreground">{blockData?.title || "Program"}</h1>
            <p className="text-xs text-primary-foreground/70">
              {totalWeeks} weeks &middot; {daysPerWeek} days/week
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {shareCode ? (
            <div className="flex items-center gap-1 bg-white/15 px-3 py-1.5 rounded-md">
              <Share2 className="h-3.5 w-3.5 text-primary-foreground/70" />
              <code className="text-sm font-bold text-primary-foreground">{shareCode}</code>
              <Button variant="ghost" size="icon" className="h-6 w-6 text-primary-foreground hover:bg-white/15" onClick={handleCopyCode}>
                {copied ? <Check className="h-3 w-3 text-green-500" /> : <Copy className="h-3 w-3" />}
              </Button>
            </div>
          ) : (
            <Button variant="outline" size="sm" onClick={handleGenerateShareCode} className="border-white/30 text-primary-foreground hover:bg-white/15">
              <Share2 className="h-3.5 w-3.5 mr-1" />
              Share
            </Button>
          )}
          <Button
            onClick={handleSave}
            disabled={!hasChanges || saving}
            size="sm"
            className="gap-1 bg-white text-primary hover:bg-white/90"
          >
            <Save className="h-3.5 w-3.5" />
            {saving ? "Saving..." : "Save"}
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => {
              if (confirm(`Delete "${blockData?.title}"? This cannot be undone.`)) {
                deleteProgramMutation.mutate({ blockId: Number(blockId) });
              }
            }}
            className="gap-1 bg-red-500/80 hover:bg-red-500"
          >
            <Trash2 className="h-3.5 w-3.5" />
            Delete
          </Button>
        </div>
      </div>

      {/* Week Tabs */}
      <div className="border-b bg-card px-4 flex gap-1 overflow-x-auto shadow-sm">
        {weekNumbers.map((week) => (
          <button
            key={week}
            onClick={() => setActiveWeek(week)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeWeek === week
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            Week {week}
          </button>
        ))}
      </div>

      {/* Excel Grid */}
      <div className="flex-1 overflow-auto">
        <div className="min-w-max">
          <table className="w-full border-collapse">
            {/* Header Row - Two-level: Week group + sub-columns */}
            <thead className="sticky top-0 z-10">
              {/* Week group headers */}
              <tr className="bg-muted/80 backdrop-blur">
                <th
                  className="border border-border px-2 py-2 text-left text-xs font-bold text-muted-foreground w-10 sticky left-0 bg-muted z-10"
                  rowSpan={2}
                >
                  #
                </th>
                {dayNumbers.map((day) => (
                  <th
                    key={day}
                    colSpan={6}
                    className="border border-border px-2 py-1.5 text-center text-xs font-bold text-muted-foreground bg-muted/80"
                  >
                    <span className="text-foreground">Day {day}</span>
                  </th>
                ))}
                <th
                  className="border border-border px-2 py-2 w-10"
                  rowSpan={2}
                >
                  {/* Delete */}
                </th>
              </tr>
              {/* Sub-column headers */}
              <tr className="bg-muted/60 backdrop-blur">
                {dayNumbers.map((day) => (
                  <React.Fragment key={`sub-${day}`}>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[180px]">
                      Exercise
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[100px]">
                      Weight
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[120px]">
                      Sets/Reps
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[60px]">
                      RPE
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[80px]">
                      <span className="flex items-center justify-center gap-0.5">
                        <Video className="h-2.5 w-2.5" />
                        Video
                      </span>
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-amber-600 min-w-[120px]">
                      <span className="flex items-center justify-center gap-0.5">
                        <MessageSquare className="h-2.5 w-2.5" />
                        Client Notes
                      </span>
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-blue-600 min-w-[120px]">
                      <span className="flex items-center justify-center gap-0.5">
                        <MessageSquare className="h-2.5 w-2.5" />
                        Coach Comment
                      </span>
                    </th>
                  </React.Fragment>
                ))}
              </tr>
            </thead>

            <tbody>
              {rows.map((row, rowIdx) => (
                <tr key={row.tempId} className="hover:bg-muted/20 group">
                  {/* Row number */}
                  <td className="border border-border px-2 py-1 text-xs text-muted-foreground text-center sticky left-0 bg-background z-[5]">
                    {rowIdx + 1}
                  </td>

                  {/* Day cells - Exercise Name + Weight + Sets/Reps + RPE + Video + Client Notes */}
                  {dayNumbers.map((day) => {
                    const cell = getCell(rowIdx, activeWeek, day);
                    return (
                      <React.Fragment key={`cells-${day}`}>
                        {/* Exercise Name */}
                        <td className="border border-border p-0">
                          <input
                            type="text"
                            value={cell.exerciseName}
                            onChange={(e) =>
                              updateCell(rowIdx, activeWeek, day, "exerciseName", e.target.value)
                            }
                            onBlur={() => autoSaveCell(rowIdx, activeWeek, day)}
                            placeholder="Exercise name..."
                            className="w-full px-2 py-2.5 text-sm bg-transparent border-none outline-none focus:bg-green-50 dark:focus:bg-green-950 font-medium"
                          />
                        </td>
                        {/* Weight */}
                        <td className="border border-border p-0">
                          <input
                            type="text"
                            value={cell.weight}
                            onChange={(e) =>
                              updateCell(rowIdx, activeWeek, day, "weight", e.target.value)
                            }
                            onBlur={() => autoSaveCell(rowIdx, activeWeek, day)}
                            placeholder={getWeightPlaceholder(rowIdx, activeWeek, day)}
                            className="w-full px-2 py-2.5 text-sm bg-transparent border-none outline-none focus:bg-purple-50 dark:focus:bg-purple-950 text-center"
                          />
                        </td>
                        {/* Sets/Reps */}
                        <td className="border border-border p-0">
                          <input
                            type="text"
                            value={cell.prescription}
                            onChange={(e) =>
                              updateCell(rowIdx, activeWeek, day, "prescription", e.target.value)
                            }
                            onBlur={() => autoSaveCell(rowIdx, activeWeek, day)}
                            placeholder="e.g. 3×5"
                            className="w-full px-2 py-2.5 text-sm bg-transparent border-none outline-none focus:bg-blue-50 dark:focus:bg-blue-950 text-center"
                          />
                        </td>
                        {/* RPE */}
                        <td className="border border-border p-0">
                          <input
                            type="text"
                            value={cell.rpe}
                            onChange={(e) =>
                              updateCell(rowIdx, activeWeek, day, "rpe", e.target.value)
                            }
                            onBlur={() => autoSaveCell(rowIdx, activeWeek, day)}
                            placeholder="RPE..."
                            className="w-full px-2 py-2.5 text-sm bg-transparent border-none outline-none focus:bg-yellow-50 dark:focus:bg-yellow-950 text-center font-medium"
                          />
                        </td>
                        {/* Video indicator */}
                        <td className="border border-border px-1 py-1 text-center">
                          {cell.videoUrl ? (
                            <div className="flex items-center justify-center gap-2">
                              <a
                                href={cell.videoUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-0.5 text-xs text-primary hover:underline"
                              >
                                <Video className="h-3 w-3" />
                                <span>View</span>
                              </a>
                              <button
                                onClick={async () => {
                                  const downloadUrl = `/api/download?url=${encodeURIComponent(cell.videoUrl)}`;
                                  if (Capacitor.isNativePlatform()) {
                                    await Browser.open({ url: `${window.location.origin}${downloadUrl}` });
                                  } else {
                                    window.open(downloadUrl, '_blank');
                                  }
                                }}
                                className="text-xs text-primary hover:text-primary/70"
                                title="Download video"
                              >
                                <Download className="h-3 w-3" />
                              </button>
                              <button
                                onClick={() => handleRemoveVideo(rowIdx, activeWeek, day)}
                                className="text-xs text-red-600 hover:text-red-700"
                                title="Remove video"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          ) : (
                            <span className="text-[10px] text-muted-foreground/50">—</span>
                          )}
                        </td>
                        {/* Client Notes (read-only for coach) */}
                        <td className={`border border-border px-1 py-1 text-center ${
                          cell.isCompleted ? "bg-green-50 dark:bg-green-950/20" : cell.clientNotes ? "bg-yellow-50 dark:bg-yellow-950/20" : ""
                        }`}>
                          {cell.clientNotes ? (
                            <div className={`text-xs rounded px-1 py-0.5 max-w-[120px] truncate ${
                              cell.isCompleted ? "text-green-700 dark:text-green-400" : "text-amber-700 dark:text-amber-400"
                            }`} title={cell.clientNotes}>
                              {cell.clientNotes}
                            </div>
                          ) : (
                            <span className="text-[10px] text-muted-foreground/40">—</span>
                          )}
                        </td>
                        <td className="border border-border p-0">
                          <input
                            type="text"
                            value={cell.coachComment}
                            onChange={(e) => updateCell(rowIdx, activeWeek, day, "coachComment", e.target.value)}
                            onBlur={() => autoSaveCell(rowIdx, activeWeek, day)}
                            placeholder="Add comment..."
                            className="w-full px-2 py-2.5 text-sm bg-transparent border-none outline-none focus:bg-blue-50 dark:focus:bg-blue-950"
                          />
                        </td>
                      </React.Fragment>
                    );
                  })}

                  {/* Delete button */}
                  <td className="border border-border px-1 py-1 text-center">
                    <button
                      onClick={() => removeRow(rowIdx)}
                      className="text-muted-foreground hover:text-destructive transition-colors p-1 opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}

              {/* Add Row button */}
              <tr>
                <td
                  colSpan={2 + weekNumbers.length * 4 + 1}
                  className="border border-border border-dashed"
                >
                  <button
                    onClick={addRow}
                    className="w-full px-4 py-2.5 text-sm text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors flex items-center justify-center gap-1"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Add Exercise
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Unsaved changes indicator */}
      {hasChanges && (
        <div className="fixed bottom-4 right-4 bg-primary text-primary-foreground px-4 py-2 rounded-lg shadow-lg text-sm flex items-center gap-2 z-30">
          <div className="h-2 w-2 bg-yellow-400 rounded-full animate-pulse" />
          Unsaved changes
          <Button size="sm" variant="secondary" onClick={handleSave} disabled={saving}>
            {saving ? "Saving..." : "Save Now"}
          </Button>
        </div>
      )}
    </div>
  );
}
