import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Search,
  Plus,
  Users,
  FileText,
  Check,
  X,
  LogOut,
  MessageSquare,
  ChevronDown,
  ChevronRight,
  Share2,
  Copy,
  Trash2,
  TrendingUp,
  Activity,
  ClipboardList,
} from "lucide-react";
import { UpgradeModal } from "@/components/UpgradeModal";
import { TierBadge } from "@/components/TierBadge";
import { AccountFrozenOverlay } from "@/components/AccountFrozenOverlay";
import { PrivacyPolicy } from "@/components/PrivacyPolicy";
import { TermsOfService } from "@/components/TermsOfService";

export default function CoachDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [newProgramDialog, setNewProgramDialog] = useState(false);
  const [programTitle, setProgramTitle] = useState("");
  const [totalWeeks, setTotalWeeks] = useState(8);
  const [daysPerWeek, setDaysPerWeek] = useState(4);
  const [selectedClientId, setSelectedClientId] = useState<number | undefined>();
  const [expandedClients, setExpandedClients] = useState<Set<number>>(new Set());
  const [coachCodeDialog, setCoachCodeDialog] = useState(false);
  const [clientSearch, setClientSearch] = useState("");
  const [coachCode, setCoachCode] = useState("");
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState("");

  useEffect(() => {
    if (user?.userCode) {
      setCoachCode(user.userCode);
    }
  }, [user]);

  const utils = trpc.useUtils();
  const { data: planStatus } = trpc.billing.getMyPlanStatus.useQuery();
  const { data: clients } = trpc.clients.list.useQuery(undefined, {
    refetchInterval: 10000,
  });

  const { data: pendingRequests } = trpc.clients.pendingRequests.useQuery();
  const { data: programs } = trpc.programBlocks.list.useQuery();
  const { data: unreadComments } = trpc.notifications.unreadComments.useQuery(undefined, {
    refetchInterval: 10000,
  });
  const { data: clientPrograms } = trpc.notifications.clientPrograms.useQuery(undefined, {
    refetchInterval: 10000,
  });

  // Filter clients based on search
  const filteredClients = clientPrograms?.filter((client: any) => {
    if (!clientSearch) return true;
    const searchLower = clientSearch.toLowerCase();
    return (
      client.clientName?.toLowerCase().includes(searchLower) ||
      client.clientEmail?.toLowerCase().includes(searchLower)
    );
  }) || [];

  const acceptRequestMutation = trpc.clients.acceptRequest.useMutation({
    onSuccess: () => {
      toast.success("Client accepted!");
      utils.clients.list.invalidate();
      utils.clients.pendingRequests.invalidate();
      utils.notifications.clientPrograms.invalidate();
      utils.billing.getMyPlanStatus.invalidate();
    },
    onError: (error) => {
      // If server returns FORBIDDEN due to client limit, show upgrade modal
      if (error.data?.code === "FORBIDDEN") {
        setUpgradeModalOpen(true);
      } else {
        toast.error(`Failed to accept client: ${error.message}`);
      }
    },
  });

  const rejectRequestMutation = trpc.clients.rejectRequest.useMutation({
    onSuccess: () => {
      toast.success("Request rejected");
      utils.clients.pendingRequests.invalidate();
    },
  });

  const deleteClientMutation = trpc.clients.deleteClient.useMutation({
    onSuccess: () => {
      toast.success("Client removed");
      utils.clients.list.invalidate();
      utils.notifications.clientPrograms.invalidate();
      utils.billing.getMyPlanStatus.invalidate();
    },
    onError: (error) => {
      toast.error(`Failed to remove client: ${error.message}`);
    },
  });
  const generateCoachCodeMutation = trpc.auth.generateCoachCode.useMutation({
    onSuccess: (data) => {
      setCoachCode(data.code);
      toast.success("Coach code generated!");
    },
    onError: (error: any) => {
      toast.error(`Failed to generate code: ${error.message}`);
    },
  });

  const handleGenerateCoachCode = () => {
    // Check if user has reached client limit
    if (planStatus && planStatus.clientLimit !== null && planStatus.clientCount >= planStatus.clientLimit) {
      setUpgradeModalOpen(true);
      return;
    }
    generateCoachCodeMutation.mutate();
  };

  const handleAcceptRequest = (clientId: number) => {
    // Check if user has reached client limit
    if (planStatus && planStatus.clientLimit !== null && planStatus.clientCount >= planStatus.clientLimit) {
      setUpgradeModalOpen(true);
      return;
    }
    acceptRequestMutation.mutate({ clientId });
  };

  const createProgramMutation = trpc.programBlocks.create.useMutation({
    onSuccess: (data: any) => {
      toast.success("Program created!");
      setNewProgramDialog(false);
      setProgramTitle("");
      setSelectedClientId(undefined);
      utils.programBlocks.list.invalidate();
      utils.notifications.clientPrograms.invalidate();
      if (data?.id) {
        navigate(`/coach/program/${data.id}`);
      }
    },
  });

  const generateShareCodeMutation = trpc.programBlocks.generateShareCode.useMutation({
    onSuccess: (data) => {
      toast.success(`Share code generated: ${data.shareCode}`);
      utils.programBlocks.list.invalidate();
    },
  });

  const deleteProgramMutation = trpc.programBlocks.delete.useMutation({
    onSuccess: async () => {
      toast.success("Program deleted successfully");
      // Force refetch to update program count immediately
      await utils.programBlocks.list.refetch();
      await utils.notifications.clientPrograms.invalidate();
    },
    onError: (error) => {
      toast.error(`Failed to delete program: ${error.message}`);
    },
  });

  const deleteAllDataMutation = trpc.account.deleteAllData.useMutation({
    onSuccess: async () => {
      toast.success("All data deleted successfully");
      await logout();
      navigate("/");
    },
    onError: (error) => {
      toast.error(`Failed to delete data: ${error.message}`);
    },
  });

  const handleCreateProgram = () => {
    if (!programTitle.trim()) {
      toast.error("Please enter a program title");
      return;
    }
    createProgramMutation.mutate({
      title: programTitle,
      totalWeeks,
      daysPerWeek,
      clientId: selectedClientId,
    });
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const toggleClient = (clientId: number) => {
    setExpandedClients((prev) => {
      const next = new Set(prev);
      if (next.has(clientId)) {
        next.delete(clientId);
      } else {
        next.add(clientId);
      }
      return next;
    });
  };

  const copyShareCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success("Share code copied!");
  };

  const getUnreadForClient = (clientId: number) => {
    if (!unreadComments) return 0;
    return unreadComments
      .filter((u: any) => u.clientId === clientId)
      .reduce((sum: number, u: any) => sum + u.unreadCount, 0);
  };

  const unassignedPrograms = programs?.filter((p: any) => !p.clientId) || [];
  const totalClients = clientPrograms?.length || 0;
  const totalPrograms = programs?.length || 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Top Header Bar */}
      <div className="bg-primary text-primary-foreground">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="text-lg font-bold tracking-tight">LiftFlow</span>
          </div>
          <div className="flex items-center gap-3">
            {/* Tier Badge */}
            {planStatus && user && (
              <TierBadge
                planStatus={planStatus}
                userId={user.id}
                userEmail={user.email || null}
              />
            )}
            <Button
              onClick={handleLogout}
              variant="ghost"
              size="sm"
              className="text-primary-foreground hover:bg-white/15"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Account Frozen Overlay */}
      {planStatus?.isFrozen && user && (
        <AccountFrozenOverlay
          clientCount={planStatus.clientCount}
          originalPlan={planStatus.originalPlan}
          userId={user.id}
          userEmail={user.email || null}
          onRemoveClients={() => navigate("/coach/manage-clients")}
        />
      )}

      <div className="max-w-5xl mx-auto px-4 pb-8">
        {/* Welcome + Stats */}
        <div className="py-5">
          <h1 className="text-2xl font-bold text-foreground">
            Coach Dashboard
          </h1>
          <p className="text-muted-foreground text-sm mt-0.5">Welcome back, {user?.name}</p>
        </div>

        {/* Quick Stats Row */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-card rounded-xl border shadow-sm p-4 text-center">
            <Users className="h-5 w-5 text-primary mx-auto mb-1" />
            <p className="text-2xl font-bold">{totalClients}</p>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Clients</p>
          </div>
          <div className="bg-card rounded-xl border shadow-sm p-4 text-center">
            <ClipboardList className="h-5 w-5 text-primary mx-auto mb-1" />
            <p className="text-2xl font-bold">{totalPrograms}</p>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Programs</p>
          </div>
          <div className="bg-card rounded-xl border shadow-sm p-4 text-center">
            <MessageSquare className="h-5 w-5 text-primary mx-auto mb-1" />
            <p className="text-2xl font-bold">
              {unreadComments?.reduce((sum: number, u: any) => sum + u.unreadCount, 0) || 0}
            </p>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Unread</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 mb-6">
          <Dialog open={coachCodeDialog} onOpenChange={setCoachCodeDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5 h-9 text-xs font-medium">
                <Share2 className="h-3.5 w-3.5" />
                My Coach Code
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-sm">
              <DialogHeader>
                <DialogTitle>Your Coach Code</DialogTitle>
              </DialogHeader>
              <p className="text-sm text-muted-foreground">
                Share this code with clients so they can send you a join request.
              </p>
              {coachCode ? (
                <div className="space-y-2 mt-2">
                  <div className="flex items-center gap-2">
                    <Input
                      value={coachCode}
                      readOnly
                      className="font-mono text-lg text-center"
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        navigator.clipboard.writeText(coachCode);
                        toast.success("Code copied!");
                      }}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={handleGenerateCoachCode}
                    disabled={generateCoachCodeMutation.isPending}
                  >
                    Generate New Code
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={handleGenerateCoachCode}
                  className="w-full mt-2"
                  disabled={generateCoachCodeMutation.isPending}
                >
                  {generateCoachCodeMutation.isPending ? "Generating..." : "Generate Code"}
                </Button>
              )}
            </DialogContent>
          </Dialog>

          <Dialog open={newProgramDialog} onOpenChange={setNewProgramDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1.5 h-9 text-xs font-medium">
                <Plus className="h-3.5 w-3.5" />
                New Program
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-sm">
              <DialogHeader>
                <DialogTitle>Create New Program</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Program Title</Label>
                  <Input
                    value={programTitle}
                    onChange={(e) => setProgramTitle(e.target.value)}
                    placeholder="e.g., 8-Week Strength Block"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Assign to Client (optional)</Label>
                  <select
                    value={selectedClientId || ""}
                    onChange={(e) =>
                      setSelectedClientId(e.target.value ? Number(e.target.value) : undefined)
                    }
                    className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="">No client (unassigned)</option>
                    {clients?.map((c: any) => (
                      <option key={c.clientId} value={c.clientId}>
                        {c.clientName || c.clientEmail}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Total Weeks</Label>
                    <Input
                      type="number"
                      min={1}
                      max={16}
                      value={totalWeeks}
                      onChange={(e) => setTotalWeeks(parseInt(e.target.value) || 8)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Days per Week</Label>
                    <Input
                      type="number"
                      min={1}
                      max={7}
                      value={daysPerWeek}
                      onChange={(e) => setDaysPerWeek(parseInt(e.target.value) || 4)}
                      className="mt-1"
                    />
                  </div>
                </div>
                <Button
                  onClick={handleCreateProgram}
                  className="w-full"
                  disabled={createProgramMutation.isPending}
                >
                  {createProgramMutation.isPending ? "Creating..." : "Create Program"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Pending Requests */}
        {pendingRequests && pendingRequests.length > 0 && (
          <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-xl mb-4 overflow-hidden">
            <div className="px-4 py-3 border-b border-amber-200 dark:border-amber-800">
              <span className="font-semibold text-sm text-amber-700 dark:text-amber-400">
                Pending Requests ({pendingRequests.length})
              </span>
            </div>
            <div className="divide-y divide-amber-100 dark:divide-amber-900">
              {pendingRequests.map((request: any) => (
                <div
                  key={request.id}
                  className="flex items-center justify-between px-4 py-3"
                >
                  <div>
                    <p className="font-medium text-sm">{request.clientName || "Unknown"}</p>
                    <p className="text-xs text-muted-foreground">{request.clientEmail}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="h-7 text-xs gap-1"
                      onClick={() => handleAcceptRequest(request.clientId)}
                      disabled={acceptRequestMutation.isPending}
                    >
                      <Check className="h-3 w-3" />
                      Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 text-xs gap-1"
                      onClick={() => rejectRequestMutation.mutate({ clientId: request.clientId })}
                      disabled={rejectRequestMutation.isPending}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* My Clients */}
        <div className="bg-card rounded-xl border shadow-sm mb-4">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              <span className="font-semibold text-sm">My Clients</span>
            </div>
            <span className="text-xs text-muted-foreground">
              {totalClients} client{totalClients !== 1 ? "s" : ""}
            </span>
          </div>

          {/* Search Bar */}
          {clientPrograms && clientPrograms.length > 0 && (
            <div className="px-4 py-3 border-b bg-muted/30">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search clients by name or email..."
                  value={clientSearch}
                  onChange={(e) => setClientSearch(e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
            </div>
          )}

          {filteredClients && filteredClients.length > 0 ? (
            <div className="divide-y">
              {filteredClients.map((client: any) => {
                const isExpanded = expandedClients.has(client.clientId);
                const unreadCount = getUnreadForClient(client.clientId);

                return (
                  <div key={client.clientId}>
                    {/* Client Row */}
                    <div className="flex items-center justify-between px-4 py-3 hover:bg-accent/50 transition-colors">
                      <div
                        className="flex items-center gap-3 flex-1 cursor-pointer"
                        onClick={() => toggleClient(client.clientId)}
                      >
                        <div className="relative">
                          <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                            {(client.clientName || "?")[0]?.toUpperCase()}
                          </div>
                          {unreadCount > 0 && (
                            <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center">
                              {unreadCount}
                            </span>
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-sm flex items-center gap-2">
                            {client.clientName || "Unknown"}
                            {unreadCount > 0 && (
                              <span className="inline-flex items-center gap-0.5 text-[10px] text-red-500 font-normal">
                                <MessageSquare className="h-2.5 w-2.5" />
                                {unreadCount}
                              </span>
                            )}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {client.programs?.length || 0} program{(client.programs?.length || 0) !== 1 ? "s" : ""}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 w-7 p-0 text-primary hover:bg-primary/10"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/coach/progress/${client.clientId}`);
                          }}
                          title="View progress"
                        >
                          <TrendingUp className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 w-7 p-0 text-destructive hover:bg-destructive/10"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`Remove ${client.clientName || "this client"}?`)) {
                              deleteClientMutation.mutate({ clientId: client.clientId });
                            }
                          }}
                          title="Remove client"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                        <button
                          onClick={() => toggleClient(client.clientId)}
                          className="p-1 hover:bg-muted rounded"
                        >
                          {isExpanded ? (
                            <ChevronDown className="h-4 w-4 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-4 w-4 text-muted-foreground" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Expanded Programs */}
                    {isExpanded && (
                      <div className="bg-muted/30 px-4 py-3 space-y-2">
                        {client.programs && client.programs.length > 0 ? (
                          client.programs.map((program: any) => (
                            <div
                              key={program.id}
                              className="flex items-center justify-between p-3 bg-card border rounded-lg hover:shadow-sm cursor-pointer transition-all"
                              onClick={() => navigate(`/coach/program/${program.id}`)}
                            >
                              <div className="flex-1 min-w-0">
                                <p className="font-medium text-sm truncate">{program.title}</p>
                                <p className="text-xs text-muted-foreground">
                                  {program.totalWeeks}w &middot; {program.daysPerWeek}d/wk
                                </p>
                              </div>
                              <div className="flex items-center gap-2">
                                {program.shareCode ? (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      copyShareCode(program.shareCode);
                                    }}
                                    className="flex items-center gap-1 text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full hover:bg-primary/20 transition-colors font-mono"
                                  >
                                    <Copy className="h-2.5 w-2.5" />
                                    {program.shareCode}
                                  </button>
                                ) : (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      generateShareCodeMutation.mutate({ blockId: program.id });
                                    }}
                                    className="text-[10px] text-muted-foreground hover:text-primary transition-colors"
                                  >
                                    <Share2 className="h-3 w-3" />
                                  </button>
                                )}
                                <span
                                  className={`text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wider ${
                                    program.status === "active"
                                      ? "bg-primary/10 text-primary"
                                      : program.status === "completed"
                                      ? "bg-blue-50 text-blue-600"
                                      : "bg-muted text-muted-foreground"
                                  }`}
                                >
                                  {program.status}
                                </span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (confirm(`Delete "${program.title}"? This cannot be undone.`)) {
                                      deleteProgramMutation.mutate({ blockId: program.id });
                                    }
                                  }}
                                  className="text-destructive/60 hover:text-destructive transition-colors"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-xs text-muted-foreground text-center py-2">
                            No programs assigned yet
                          </p>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full text-xs gap-1 h-8"
                          onClick={() => {
                            setSelectedClientId(client.clientId);
                            setNewProgramDialog(true);
                          }}
                        >
                          <Plus className="h-3 w-3" />
                          New Program for {client.clientName?.split(" ")[0] || "Client"}
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : clientSearch ? (
            <div className="text-center py-12 px-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Search className="h-6 w-6 text-primary" />
              </div>
              <p className="text-sm font-medium text-foreground mb-1">No clients found</p>
              <p className="text-xs text-muted-foreground">
                No clients match "{clientSearch}". Try a different search term.
              </p>
            </div>
          ) : (
            <div className="text-center py-12 px-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <p className="text-sm font-medium text-foreground mb-1">No clients yet</p>
              <p className="text-xs text-muted-foreground">
                Share your coach code to start connecting with clients.
              </p>
            </div>
          )}
        </div>

        {/* Unassigned Programs */}
        {unassignedPrograms.length > 0 && (
          <div className="bg-card rounded-xl border shadow-sm">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-primary" />
                <span className="font-semibold text-sm">Program Templates</span>
                <span className="text-[10px] bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded-full font-medium">Reusable</span>
              </div>
            </div>
            <div className="divide-y">
              {unassignedPrograms.map((program: any) => (
                <div
                  key={program.id}
                  className="flex items-center justify-between px-4 py-3 hover:bg-accent/50 cursor-pointer transition-colors"
                  onClick={() => navigate(`/coach/program/${program.id}`)}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{program.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {program.totalWeeks} weeks &middot; {program.daysPerWeek} days/week
                      {program.shareCode && (
                        <span className="ml-2 text-blue-600 dark:text-blue-400">• Shareable</span>
                      )}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wider ${
                        program.status === "active"
                          ? "bg-primary/10 text-primary"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {program.status}
                    </span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Upgrade Modal */}
      {planStatus && user && (
        <UpgradeModal
          open={upgradeModalOpen}
          onClose={() => setUpgradeModalOpen(false)}
          currentClientCount={planStatus.clientCount}
          clientLimit={planStatus.clientLimit || 1}
          userId={user.id}
          userEmail={user.email || null}
        />
      )}

      {/* Delete Account Section */}
      <div className="max-w-5xl mx-auto px-4 pb-8">
        <div className="border-t pt-6 mt-2 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            className="text-destructive hover:text-destructive hover:bg-destructive/10 text-xs"
            onClick={() => setDeleteDialogOpen(true)}
          >
            <Trash2 className="h-3.5 w-3.5 mr-1.5" />
            Delete All My Data
          </Button>
          <div className="flex items-center gap-3">
            <PrivacyPolicy
              trigger={
                <button className="text-xs text-muted-foreground underline hover:text-foreground transition-colors">
                  Privacy Policy
                </button>
              }
            />
            <span className="text-xs text-muted-foreground">&middot;</span>
            <TermsOfService
              trigger={
                <button className="text-xs text-muted-foreground underline hover:text-foreground transition-colors">
                  Terms of Service
                </button>
              }
            />
          </div>
        </div>
      </div>

      {/* Delete All Data Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={(open) => {
        setDeleteDialogOpen(open);
        if (!open) setDeleteConfirmText(""); // Reset on close
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete All My Data</DialogTitle>
            <DialogDescription>
              This will permanently delete all your data including:
            </DialogDescription>
          </DialogHeader>
          <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1 px-2">
            <li>All programs you've created</li>
            <li>All client relationships</li>
            <li>All progress records and PRs</li>
            <li>All uploaded videos</li>
          </ul>
          <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 space-y-3">
            <p className="text-sm font-semibold text-destructive">
              ⚠️ WARNING: This action is PERMANENT and IRREVERSIBLE
            </p>
            <p className="text-sm text-muted-foreground">
              Your account and all associated data will be permanently deleted from our servers. You will not be able to recover this data.
            </p>
            <div className="space-y-2">
              <label className="text-sm font-medium">
                Type <span className="font-mono bg-muted px-1.5 py-0.5 rounded">DELETE</span> to confirm:
              </label>
              <input
                type="text"
                value={deleteConfirmText}
                onChange={(e) => setDeleteConfirmText(e.target.value)}
                placeholder="Type DELETE here"
                className="w-full px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-destructive"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                deleteAllDataMutation.mutate();
                setDeleteConfirmText(""); // Reset after deletion
              }}
              disabled={deleteAllDataMutation.isPending || deleteConfirmText !== "DELETE"}
            >
              {deleteAllDataMutation.isPending ? "Deleting..." : "Delete Everything"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}
