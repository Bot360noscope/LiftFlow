import { useState, useRef, useEffect, useMemo, useCallback, Fragment, ChangeEvent } from "react";
import { useLocation, useRoute } from "wouter";
import { Capacitor } from "@capacitor/core";
import { Browser } from "@capacitor/browser";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { CameraRecorder } from "@/components/CameraRecorder";
import { toast } from "sonner";
import {
  ArrowLeft,
  CheckCircle2,
  Circle,
  Video,
  Upload,
  MessageSquare,
  X,
  Loader2,
  Download,
} from "lucide-react";

interface CellData {
  cellId: number | null;
  exerciseName: string;
  weight: string;
  prescription: string;
  rpe: string;
  videoUrl: string;
  isCompleted: boolean;
  clientNotes: string;
  coachComment: string;
}

type GridState = Record<string, CellData>;

function cellKey(rowIdx: number, weekNum: number, dayNum: number) {
  return `${rowIdx}-${weekNum}-${dayNum}`;
}

const emptyCellData: CellData = {
  cellId: null,
  exerciseName: "",
  weight: "",
  prescription: "",
  rpe: "",
  videoUrl: "",
  isCompleted: false,
  clientNotes: "",
  coachComment: "",
};

export default function ClientProgram() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [, params] = useRoute("/client/program/:id");
  const blockId = params?.id ? parseInt(params.id) : null;

  const [activeWeek, setActiveWeek] = useState(1);
  const [grid, setGrid] = useState<GridState>({});
  const [exerciseNames, setExerciseNames] = useState<string[]>([]);
  const [uploadingCell, setUploadingCell] = useState<string | null>(null);
  const [recordingCell, setRecordingCell] = useState<{ rowIdx: number; week: number; day: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadCellRef = useRef<{ rowIdx: number; week: number; day: number } | null>(null);

  const { data: blockData, isLoading } = trpc.programBlocks.get.useQuery(
    { blockId: blockId! },
    { enabled: !!blockId }
  );

  const completionMutation = trpc.cells.updateCompletion.useMutation();
  const uploadVideoMutation = trpc.cells.uploadVideo.useMutation();
  const utils = trpc.useUtils();

  // Initialize from data
  useEffect(() => {
    if (!blockData) return;

    // Load cells from database and figure out how many rows we need
    const newGrid: GridState = {};
    let maxRowNumber = 0;

    for (const cell of blockData.cells) {
      if (cell.rowNumber !== null && cell.rowNumber !== undefined) {
        const key = cellKey(cell.rowNumber, cell.weekNumber, cell.dayNumber);
        newGrid[key] = {
          cellId: cell.id,
          exerciseName: cell.exerciseName || "",
          weight: cell.weight || "",
          prescription: cell.notes || "",
          rpe: cell.rpe || "",
          videoUrl: cell.videoUrl || "",
          isCompleted: cell.isCompleted || false,
          clientNotes: cell.clientNotes || "",
          coachComment: (cell as any).coachComment || "",
        };
        maxRowNumber = Math.max(maxRowNumber, cell.rowNumber);
      }
    }

    // Create rows based on max row number found in cells, or default to 5 empty rows
    const numRows = Math.max(maxRowNumber + 1, 5);
    const names = Array.from({ length: numRows }, () => "");
    setExerciseNames(names);
    setGrid(newGrid);
  }, [blockData]);

  const toggleCompletion = useCallback(
    (rowIdx: number, weekNum: number, dayNum: number) => {
      const key = cellKey(rowIdx, weekNum, dayNum);
      const cell = grid[key];
      if (!cell?.cellId) {
        toast.error("No exercise data in this cell");
        return;
      }

      const newCompleted = !cell.isCompleted;
      setGrid((prev) => ({
        ...prev,
        [key]: { ...prev[key], isCompleted: newCompleted },
      }));

      completionMutation.mutate(
        {
          cellId: cell.cellId,
          isCompleted: newCompleted,
          clientNotes: cell.clientNotes,
        },
        {
          onError: () => {
            setGrid((prev) => ({
              ...prev,
              [key]: { ...prev[key], isCompleted: !newCompleted },
            }));
            toast.error("Failed to update");
          },
        }
      );
    },
    [grid, completionMutation]
  );

  const updateClientNotes = useCallback(
    (rowIdx: number, weekNum: number, dayNum: number, notes: string) => {
      const key = cellKey(rowIdx, weekNum, dayNum);
      setGrid((prev) => ({
        ...prev,
        [key]: {
          ...(prev[key] || { ...emptyCellData }),
          clientNotes: notes,
        },
      }));
    },
    []
  );

  const saveNotes = useCallback(
    (rowIdx: number, weekNum: number, dayNum: number) => {
      const key = cellKey(rowIdx, weekNum, dayNum);
      const cell = grid[key];
      if (!cell?.cellId) return;

      completionMutation.mutate({
        cellId: cell.cellId,
        isCompleted: cell.isCompleted,
        clientNotes: cell.clientNotes,
      });
    },
    [grid, completionMutation]
  );

  // Handle camera recording
  const handleCameraRecord = async (blob: Blob) => {
    if (!recordingCell) return;

    const { rowIdx, week, day } = recordingCell;
    const key = cellKey(rowIdx, week, day);
    const cell = grid[key];

    if (!cell?.cellId) {
      toast.error("No exercise data in this cell");
      setRecordingCell(null);
      return;
    }

    try {
      setUploadingCell(key);

      // Upload blob to server
      const formData = new FormData();
      formData.append("file", blob, "recording.webm");

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const { url } = await response.json();

      // Save video URL to cell
      await uploadVideoMutation.mutateAsync({
        cellId: cell.cellId,
        videoUrl: url,
      });

      setGrid((prev) => ({
        ...prev,
        [key]: { ...prev[key], videoUrl: url },
      }));

      toast.success("Video recorded and uploaded!");
      await utils.programBlocks.get.invalidate({ blockId: blockId! });
      setRecordingCell(null);
    } catch (error) {
      console.error("Upload error:", error);
      toast.error("Failed to upload video.");
    } finally {
      setUploadingCell(null);
    }
  };

  // Video upload handling
  const handleVideoDownload = async (videoUrl: string) => {
    const downloadUrl = `/api/download?url=${encodeURIComponent(videoUrl)}`;
    
    if (Capacitor.isNativePlatform()) {
      // On mobile, open in system browser
      await Browser.open({ url: `${window.location.origin}${downloadUrl}` });
    } else {
      // On web, open in new tab
      window.open(downloadUrl, '_blank');
    }
  };

  const handleVideoClick = (rowIdx: number, week: number, day: number) => {
    uploadCellRef.current = { rowIdx, week, day };
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !uploadCellRef.current) return;

    const { rowIdx, week, day } = uploadCellRef.current;
    const key = cellKey(rowIdx, week, day);
    const cell = grid[key];

    if (!cell?.cellId) {
      toast.error("No exercise data in this cell");
      return;
    }

    // Check file size (16MB limit)
    if (file.size > 16 * 1024 * 1024) {
      toast.error("Video must be under 16MB");
      return;
    }

    setUploadingCell(key);

    try {
      // Upload to server via FormData
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const { url } = await response.json();

      // Save video URL to cell
      await uploadVideoMutation.mutateAsync({
        cellId: cell.cellId,
        videoUrl: url,
      });

      setGrid((prev) => ({
        ...prev,
        [key]: { ...prev[key], videoUrl: url },
      }));

      toast.success("Video uploaded!");
      await utils.programBlocks.get.invalidate({ blockId: blockId! });
    } catch (error) {
      console.error("Upload error:", error);
      toast.error("Failed to upload video. You can paste a video URL instead.");
    } finally {
      setUploadingCell(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  // Manual URL entry for video
  const handleVideoUrlEntry = (rowIdx: number, week: number, day: number) => {
    const key = cellKey(rowIdx, week, day);
    const cell = grid[key];
    if (!cell?.cellId) {
      toast.error("No exercise data in this cell");
      return;
    }

    const url = prompt("Paste your video URL (YouTube, Google Drive, etc.):");
    if (!url) return;

    uploadVideoMutation.mutate(
      { cellId: cell.cellId, videoUrl: url },
      {
        onSuccess: () => {
          setGrid((prev) => ({
            ...prev,
            [key]: { ...prev[key], videoUrl: url },
          }));
          toast.success("Video link saved!");
        },
        onError: () => toast.error("Failed to save video link"),
      }
    );
  };

  // Remove video from cell
  const handleRemoveVideo = (rowIdx: number, week: number, day: number) => {
    const key = cellKey(rowIdx, week, day);
    const cell = grid[key];
    if (!cell?.cellId) {
      toast.error("No exercise data in this cell");
      return;
    }

    if (!confirm("Are you sure you want to remove this video?")) return;

    uploadVideoMutation.mutate(
      { cellId: cell.cellId, videoUrl: "" },
      {
        onSuccess: () => {
          setGrid((prev) => ({
            ...prev,
            [key]: { ...prev[key], videoUrl: "" },
          }));
          toast.success("Video removed!");
        },
        onError: () => toast.error("Failed to remove video"),
      }
    );
  };

  const totalWeeks = blockData?.totalWeeks || 8;
  const daysPerWeek = blockData?.daysPerWeek || 4;
  const weekNumbers = useMemo(
    () => Array.from({ length: totalWeeks }, (_, i) => i + 1),
    [totalWeeks]
  );
  const dayNumbers = useMemo(
    () => Array.from({ length: daysPerWeek }, (_, i) => i + 1),
    [daysPerWeek]
  );

  const getCell = useCallback(
    (rowIdx: number, weekNum: number, dayNum: number): CellData => {
      const key = cellKey(rowIdx, weekNum, dayNum);
      return grid[key] || { ...emptyCellData, exerciseName: exerciseNames[rowIdx] || "" };
    },
    [grid, exerciseNames]
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Hidden file input for video upload */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* Header */}
      <div className="border-b bg-primary text-primary-foreground px-4 py-3 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/client")} className="text-primary-foreground hover:bg-white/15">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-lg font-bold text-primary-foreground">{blockData?.title || "Program"}</h1>
            <p className="text-xs text-primary-foreground/70">
              {totalWeeks} weeks &middot; {daysPerWeek} days/week
            </p>
          </div>
        </div>
      </div>

      {/* Week Tabs */}
      <div className="border-b bg-card px-4 flex gap-1 overflow-x-auto shadow-sm">
        {weekNumbers.map((week) => (
          <button
            key={week}
            onClick={() => setActiveWeek(week)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeWeek === week
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            Week {week}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-auto">
        <div className="min-w-max">
          <table className="w-full border-collapse">
            <thead className="sticky top-0 z-10">
              {/* Week group headers */}
              <tr className="bg-muted/80 backdrop-blur">
                <th
                  className="border border-border px-2 py-2 text-left text-xs font-bold text-muted-foreground w-10 sticky left-0 bg-muted/80 z-10"
                  rowSpan={2}
                >
                  #
                </th>
                {dayNumbers.map((day) => (
                  <th
                    key={day}
                    colSpan={6}
                    className="border border-border px-2 py-1.5 text-center text-xs font-bold bg-muted"
                  >
                    <span className="text-foreground">Day {day}</span>
                  </th>
                ))}
              </tr>
              {/* Sub-column headers */}
              <tr className="bg-muted/60 backdrop-blur">
                {dayNumbers.map((day) => (
                  <th key={`sub-${day}`} className="contents">
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[140px]">
                      Exercise
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[100px]">
                      Weight
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[120px]">
                      Sets/Reps
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[100px]">
                      <span className="flex items-center justify-center gap-0.5">
                        <MessageSquare className="h-2.5 w-2.5" />
                        RPE
                      </span>
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-blue-600 min-w-[120px]">
                      <span className="flex items-center justify-center gap-0.5">
                        <MessageSquare className="h-2.5 w-2.5" />
                        Coach Comment
                      </span>
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[80px]">
                      <span className="flex items-center justify-center gap-0.5">
                        <Video className="h-2.5 w-2.5" />
                        Video
                      </span>
                    </th>
                    <th className="border border-border px-1 py-1 text-center text-[10px] font-medium text-muted-foreground min-w-[110px]">
                      Status / Notes
                    </th>
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {exerciseNames.map((name, rowIdx) => (
                <tr key={rowIdx} className="hover:bg-muted/20 group">
                  {/* Row number */}
                  <td className="border border-border px-2 py-1 text-xs text-muted-foreground text-center sticky left-0 bg-background z-[5]">
                    {rowIdx + 1}
                  </td>

                  {/* Day cells */}
                  {dayNumbers.map((day) => {
                    const cell = getCell(rowIdx, activeWeek, day);
                    const key = cellKey(rowIdx, activeWeek, day);
                    const hasPrescription = !!cell.prescription;
                    const isUploading = uploadingCell === key;

                    return (
                      <Fragment key={`cells-${day}`}>
                        {/* Exercise Name (read-only) */}
                        <td className="border border-border px-2 py-2 text-sm font-medium">
                          {cell.exerciseName || <span className="text-muted-foreground/40">&mdash;</span>}
                        </td>

                        {/* Weight (read-only) */}
                        <td className="border border-border px-2 py-2 text-sm text-center">
                          {cell.weight ? (
                            <span>{cell.weight}</span>
                          ) : (
                            <span className="text-muted-foreground/40">&mdash;</span>
                          )}
                        </td>

                        {/* Sets/Reps (read-only) */}
                        <td className="border border-border px-2 py-2 text-sm text-center">
                          {hasPrescription ? (
                            <span>{cell.prescription}</span>
                          ) : (
                            <span className="text-muted-foreground/40">&mdash;</span>
                          )}
                        </td>

                        {/* RPE (read-only from coach) */}
                        <td className="border border-border px-1 py-1 text-center">
                          {cell.rpe ? (
                            <div className="text-sm font-semibold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 rounded px-1 py-0.5">
                              {cell.rpe}
                   </div>
                          ) : (
                            <span className="text-[10px] text-muted-foreground/40">&mdash;</span>
                          )}
                        </td>

                        {/* Coach Comment */}
                        <td className="border border-border px-1 py-1 text-center">
                          {cell.coachComment ? (
                            <div className="text-xs rounded px-1 py-0.5 max-w-[120px] truncate text-blue-700 dark:text-blue-400" title={cell.coachComment}>
                              {cell.coachComment}
                            </div>
                          ) : (
                            <span className="text-[10px] text-muted-foreground/40">—</span>
                          )}
                        </td>

                        {/* Video (optional upload) */}
                        <td className="border border-border px-1 py-1 text-center">
                          {isUploading ? (
                            <Loader2 className="h-4 w-4 animate-spin mx-auto text-primary" />
                          ) : cell.videoUrl ? (
                            <div className="flex items-center justify-center gap-1">
                              <a
                                href={cell.videoUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs text-primary hover:underline flex items-center gap-0.5"
                              >
                                <Video className="h-3 w-3" />
                                View
                              </a>
                              <button
                                onClick={() => handleVideoDownload(cell.videoUrl)}
                                className="text-xs text-primary hover:text-primary/70"
                                title="Download video"
                              >
                                <Download className="h-3 w-3" />
                              </button>
                              <button
                                onClick={() => handleRemoveVideo(rowIdx, activeWeek, day)}
                                className="text-xs text-red-600 hover:text-red-700"
                                title="Remove video"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          ) : hasPrescription ? (
                            <div className="flex flex-col items-center gap-0.5">
                              <button
                                onClick={() => setRecordingCell({ rowIdx, week: activeWeek, day })}
                                className="text-[10px] text-muted-foreground hover:text-primary transition-colors flex items-center gap-0.5"
                                title="Record video from camera"
                              >
                                <Video className="h-2.5 w-2.5" />
                                Record
                              </button>
                              <button
                                onClick={() => handleVideoClick(rowIdx, activeWeek, day)}
                                className="text-[10px] text-muted-foreground hover:text-primary transition-colors flex items-center gap-0.5"
                                title="Upload video file"
                              >
                                <Upload className="h-2.5 w-2.5" />
                                Upload
                              </button>
                              <button
                                onClick={() => handleVideoUrlEntry(rowIdx, activeWeek, day)}
                                className="text-[10px] text-muted-foreground hover:text-primary transition-colors"
                                title="Paste video URL"
                              >
                                or paste link
                              </button>
                            </div>
                          ) : (
                            <span className="text-[10px] text-muted-foreground/40">&mdash;</span>
                          )}
                        </td>

                        {/* Status + Client Notes */}
                        <td className={`border border-border px-1 py-1 ${
                          hasPrescription
                            ? cell.isCompleted
                              ? "bg-green-50 dark:bg-green-950/20"
                              : "bg-yellow-50 dark:bg-yellow-950/20"
                            : ""
                        }`}>
                          {hasPrescription ? (
                            <div className="space-y-1">
                              <button
                                onClick={() => toggleCompletion(rowIdx, activeWeek, day)}
                                className="flex items-center gap-1 text-xs transition-colors mx-auto"
                              >
                                {cell.isCompleted ? (
                                  <CheckCircle2 className="h-3.5 w-3.5 text-green-500" />
                                ) : (
                                  <Circle className="h-3.5 w-3.5 text-muted-foreground" />
                                )}
                                <span
                                  className={
                                    cell.isCompleted
                                      ? "text-green-600 font-medium"
                                      : "text-muted-foreground"
                                  }
                                >
                                  {cell.isCompleted ? "Done" : "Todo"}
                                </span>
                              </button>
                              <input
                                type="text"
                                value={cell.clientNotes}
                                onChange={(e) =>
                                  updateClientNotes(rowIdx, activeWeek, day, e.target.value)
                                }
                                onBlur={() => saveNotes(rowIdx, activeWeek, day)}
                                placeholder="My notes..."
                                className="w-full text-[10px] px-1 py-0.5 bg-muted/50 rounded border-none outline-none focus:bg-blue-50 dark:focus:bg-blue-950"
                              />
                            </div>
                          ) : (
                            <span className="text-[10px] text-muted-foreground/40 text-center block">
                              &mdash;
                            </span>
                          )}
                        </td>
                      </Fragment>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {recordingCell && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-background rounded-lg w-full max-w-md max-h-[90vh] overflow-auto">
            <div className="p-4 border-b flex items-center justify-between">
              <h2 className="text-lg font-semibold">Record Exercise Video</h2>
              <button
                onClick={() => setRecordingCell(null)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <CameraRecorder
              onVideoReady={handleCameraRecord}
              isUploading={uploadingCell !== null}
            />
          </div>
        </div>
      )}
    </div>
  );
}
