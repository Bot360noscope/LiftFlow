import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import {
  Dumbbell,
  Users,
  Video,
  TrendingUp,
  Activity,
  ChevronRight,
  Shield,
  Zap,
} from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { PrivacyPolicy } from "@/components/PrivacyPolicy";
import { TermsOfService } from "@/components/TermsOfService";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const updateRole = trpc.auth.updateRole.useMutation();

  const handleRoleSelection = async (role: "coach" | "client") => {
    try {
      await updateRole.mutateAsync({ role });
      toast.success(`Role updated to ${role}`);
      if (role === "coach") {
        setLocation("/coach");
      } else {
        setLocation("/client");
      }
    } catch (error) {
      toast.error("Failed to update role");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-10 w-10 border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        {/* Hero Section */}
        <div className="bg-primary text-primary-foreground">
          <div className="max-w-5xl mx-auto px-4 py-6 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="text-lg font-bold tracking-tight">LiftFlow</span>
            </div>
            <Button
              size="sm"
              className="bg-white text-primary hover:bg-white/90 font-semibold"
              onClick={() => (window.location.href = getLoginUrl())}
            >
              Sign In
            </Button>
          </div>

          <div className="max-w-5xl mx-auto px-4 pb-16 pt-12 text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
              Your Coaching,
              <br />
              <span className="text-white/90">Simplified.</span>
            </h1>
            <p className="text-lg text-primary-foreground/80 max-w-xl mx-auto mb-8">
              Build programs, track progress, and review form — all in one place.
              The platform built for serious coaches and dedicated athletes.
            </p>
            <Button
              size="lg"
              className="bg-white text-primary hover:bg-white/90 font-semibold text-base px-8 h-12 rounded-full shadow-lg"
              onClick={() => (window.location.href = getLoginUrl())}
            >
              Get Started Free
              <ChevronRight className="h-5 w-5 ml-1" />
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="max-w-5xl mx-auto px-4 -mt-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: Dumbbell, label: "Programs", desc: "Excel-style builder" },
              { icon: Users, label: "Clients", desc: "Manage & track" },
              { icon: Video, label: "Form Checks", desc: "Video review" },
              { icon: TrendingUp, label: "Progress", desc: "PR tracking" },
            ].map(({ icon: Icon, label, desc }) => (
              <div
                key={label}
                className="bg-card rounded-xl border shadow-sm p-4 text-center"
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <p className="font-semibold text-sm">{label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Why Section */}
        <div className="max-w-5xl mx-auto px-4 py-16">
          <h2 className="text-2xl font-bold text-center mb-8">
            Built for Real Coaches
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-1">Fast Program Design</h3>
              <p className="text-sm text-muted-foreground">
                Build multi-week programs with an Excel-like grid. Copy exercises across weeks in seconds.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Video className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-1">Video Form Review</h3>
              <p className="text-sm text-muted-foreground">
                Clients record lifts directly in the app. Review and comment on form without leaving the program.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-1">Simple & Secure</h3>
              <p className="text-sm text-muted-foreground">
                Share codes connect coaches and clients. No complex setup, no data sharing with third parties.
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="bg-primary/5 border-t">
          <div className="max-w-5xl mx-auto px-4 py-12 text-center">
            <h2 className="text-2xl font-bold mb-3">Ready to coach smarter?</h2>
            <p className="text-muted-foreground mb-6">
              Free to start. No credit card required.
            </p>
            <Button
              size="lg"
              className="font-semibold text-base px-8 h-12 rounded-full"
              onClick={() => (window.location.href = getLoginUrl())}
            >
              Create Your Account
              <ChevronRight className="h-5 w-5 ml-1" />
            </Button>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t">
          <div className="max-w-5xl mx-auto px-4 py-6 flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              LiftFlow &mdash; Built for coaches who care about their athletes.
            </p>
            <div className="flex items-center gap-3">
              <PrivacyPolicy
                trigger={
                  <button className="text-xs text-muted-foreground underline hover:text-foreground transition-colors">
                    Privacy Policy
                  </button>
                }
              />
              <span className="text-xs text-muted-foreground">&middot;</span>
              <TermsOfService
                trigger={
                  <button className="text-xs text-muted-foreground underline hover:text-foreground transition-colors">
                    Terms of Service
                  </button>
                }
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Authenticated: role selection
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center gap-2">
          <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="text-lg font-bold tracking-tight">LiftFlow</span>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold">
            Welcome, {user?.name?.split(" ")[0] || "User"}!
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Choose your role to get started
          </p>
        </div>

        <div className="space-y-4">
          {/* Coach Card */}
          <div
            className="bg-card rounded-xl border shadow-sm p-6 cursor-pointer hover:shadow-md hover:border-primary/30 transition-all"
            onClick={() => handleRoleSelection("coach")}
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-bold mb-1">I'm a Coach</h2>
                <p className="text-sm text-muted-foreground mb-3">
                  Create programs, manage clients, and track their progress.
                </p>
                <div className="flex flex-wrap gap-2">
                  {["Programs", "Clients", "Video Review", "Analytics"].map((f) => (
                    <span
                      key={f}
                      className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium"
                    >
                      {f}
                    </span>
                  ))}
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground mt-1" />
            </div>
          </div>

          {/* Client Card */}
          <div
            className="bg-card rounded-xl border shadow-sm p-6 cursor-pointer hover:shadow-md hover:border-primary/30 transition-all"
            onClick={() => handleRoleSelection("client")}
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <Dumbbell className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-bold mb-1">I'm a Client</h2>
                <p className="text-sm text-muted-foreground mb-3">
                  Follow your program, log workouts, and track your PRs.
                </p>
                <div className="flex flex-wrap gap-2">
                  {["Workouts", "Form Videos", "PR Tracking", "Coach Chat"].map((f) => (
                    <span
                      key={f}
                      className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium"
                    >
                      {f}
                    </span>
                  ))}
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground mt-1" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
