import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import ProgressTracker from "@/components/ProgressTracker";

export default function CoachClientProgress() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [, params] = useRoute("/coach/progress/:clientId");
  const clientId = params?.clientId ? parseInt(params.clientId) : null;

  if (!user || !clientId) return null;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b bg-primary text-primary-foreground px-4 py-3 flex items-center gap-3 sticky top-0 z-20">
        <Button variant="ghost" size="icon" onClick={() => navigate("/coach")} className="text-primary-foreground hover:bg-white/15">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-lg font-bold text-primary-foreground">Client Progress</h1>
          <p className="text-xs text-primary-foreground/70">Track personal records</p>
        </div>
      </div>

      {/* Progress Tracker */}
      <div className="flex-1 overflow-auto">
        <ProgressTracker
          clientId={clientId}
          coachId={user.id}
        />
      </div>
    </div>
  );
}
