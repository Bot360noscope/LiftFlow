import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Capacitor } from '@capacitor/core';

/**
 * Check if running in a native mobile app (iOS/Android)
 */
export function isNativePlatform(): boolean {
  return Capacitor.isNativePlatform();
}

/**
 * Get video from native camera or gallery
 * Returns a File object that can be uploaded to S3
 */
export async function captureVideo(): Promise<File | null> {
  if (!isNativePlatform()) {
    // Fall back to web file input
    return null;
  }

  try {
    // Note: @capacitor/camera doesn't support video directly
    // For video, we need to use the native file picker or a custom plugin
    // For now, we'll use photos as a placeholder
    const photo = await Camera.getPhoto({
      resultType: CameraResultType.Uri,
      source: CameraSource.Camera,
      quality: 90,
    });

    if (!photo.webPath) {
      return null;
    }

    // Convert to File object
    const response = await fetch(photo.webPath);
    const blobData = await response.blob();
    const file = new File([blobData], 'video.mp4', { type: 'video/mp4' });
    
    return file;
  } catch (error) {
    console.error('Error capturing video:', error);
    return null;
  }
}

/**
 * Request camera permissions
 */
export async function requestCameraPermissions(): Promise<boolean> {
  if (!isNativePlatform()) {
    return true; // Web doesn't need explicit permission request
  }

  try {
    const permissions = await Camera.requestPermissions();
    return permissions.camera === 'granted';
  } catch (error) {
    console.error('Error requesting camera permissions:', error);
    return false;
  }
}
