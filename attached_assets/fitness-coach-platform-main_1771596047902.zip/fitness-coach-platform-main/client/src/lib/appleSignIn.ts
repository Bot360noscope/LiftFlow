import { SignInWithApple, SignInWithAppleResponse, SignInWithAppleOptions } from '@capacitor-community/apple-sign-in';
import { Capacitor } from '@capacitor/core';

/**
 * Check if Sign in with Apple is available on this platform
 */
export function isAppleSignInAvailable(): boolean {
  return Capacitor.getPlatform() === 'ios';
}

/**
 * Sign in with Apple
 * Returns user info and identity token
 */
export async function signInWithApple(): Promise<SignInWithAppleResponse | null> {
  if (!isAppleSignInAvailable()) {
    console.warn('Sign in with Apple is only available on iOS');
    return null;
  }

  try {
    const options: SignInWithAppleOptions = {
      clientId: 'com.liftflow.app',
      redirectURI: 'https://liftflow.manus.space/auth/apple/callback',
      scopes: 'email name',
      state: '12345',
      nonce: 'nonce',
    };

    const response = await SignInWithApple.authorize(options);
    
    console.log('Apple Sign In response:', response);
    return response;
  } catch (error) {
    console.error('Error signing in with Apple:', error);
    return null;
  }
}

/**
 * Example of how to use the Apple Sign In response:
 * 
 * const appleResponse = await signInWithApple();
 * if (appleResponse) {
 *   // Send to your backend for verification
 *   const result = await fetch('/api/auth/apple', {
 *     method: 'POST',
 *     headers: { 'Content-Type': 'application/json' },
 *     body: JSON.stringify({
 *       identityToken: appleResponse.response.identityToken,
 *       authorizationCode: appleResponse.response.authorizationCode,
 *       user: appleResponse.response.user,
 *     }),
 *   });
 * }
 */
