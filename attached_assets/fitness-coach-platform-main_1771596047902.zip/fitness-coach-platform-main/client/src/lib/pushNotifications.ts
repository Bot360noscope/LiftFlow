import { PushNotifications, Token, PushNotificationSchema, ActionPerformed } from '@capacitor/push-notifications';
import { Capacitor } from '@capacitor/core';

/**
 * Initialize push notifications for mobile app
 * Call this on app startup (in main.tsx or App.tsx)
 */
export async function initializePushNotifications(
  onTokenReceived: (token: string) => void,
  onNotificationReceived?: (notification: PushNotificationSchema) => void,
  onNotificationAction?: (action: ActionPerformed) => void
): Promise<void> {
  if (!Capacitor.isNativePlatform()) {
    console.log('Push notifications only available on native platforms');
    return;
  }

  try {
    // Request permission
    const permissionStatus = await PushNotifications.requestPermissions();
    
    if (permissionStatus.receive === 'granted') {
      // Register with Apple / Google to receive push via APNS/FCM
      await PushNotifications.register();
    } else {
      console.warn('Push notification permission not granted');
      return;
    }

    // Listen for registration success
    await PushNotifications.addListener('registration', (token: Token) => {
      console.log('Push registration success, token:', token.value);
      onTokenReceived(token.value);
    });

    // Listen for registration errors
    await PushNotifications.addListener('registrationError', (error: any) => {
      console.error('Push registration error:', error);
    });

    // Listen for push notifications received while app is in foreground
    if (onNotificationReceived) {
      await PushNotifications.addListener('pushNotificationReceived', (notification: PushNotificationSchema) => {
        console.log('Push notification received:', notification);
        onNotificationReceived(notification);
      });
    }

    // Listen for notification actions (user tapped notification)
    if (onNotificationAction) {
      await PushNotifications.addListener('pushNotificationActionPerformed', (action: ActionPerformed) => {
        console.log('Push notification action performed:', action);
        onNotificationAction(action);
      });
    }
  } catch (error) {
    console.error('Error initializing push notifications:', error);
  }
}

/**
 * Get current notification delivery status
 */
export async function getDeliveredNotifications() {
  if (!Capacitor.isNativePlatform()) {
    return [];
  }

  const notificationList = await PushNotifications.getDeliveredNotifications();
  return notificationList.notifications;
}

/**
 * Remove specific notifications from notification center
 */
export async function removeDeliveredNotifications(notificationIds: string[]) {
  if (!Capacitor.isNativePlatform()) {
    return;
  }

  const notifications = notificationIds.map(id => ({
    id,
    title: '',
    body: '',
    data: {},
  }));
  await PushNotifications.removeDeliveredNotifications({ notifications });
}

/**
 * Remove all notifications from notification center
 */
export async function removeAllDeliveredNotifications() {
  if (!Capacitor.isNativePlatform()) {
    return;
  }

  await PushNotifications.removeAllDeliveredNotifications();
}
