import { Capacitor } from "@capacitor/core";
import { Browser } from "@capacitor/browser";

export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// Generate login URL at runtime so redirect URI reflects the current origin.
export const getLoginUrl = () => {
  const oauthPortalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL;
  const appId = import.meta.env.VITE_APP_ID;
  
  // On native mobile, use the production URL for OAuth callback
  // On web, use the current origin
  const isNative = Capacitor.isNativePlatform();
  const redirectUri = isNative 
    ? `https://your-production-domain.com/api/oauth/callback`  // TODO: Replace with actual production domain
    : `${window.location.origin}/api/oauth/callback`;
    
  const state = btoa(redirectUri);

  const url = new URL(`${oauthPortalUrl}/app-auth`);
  url.searchParams.set("appId", appId);
  url.searchParams.set("redirectUri", redirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("type", "signIn");

  return url.toString();
};

// Handle OAuth login - opens in system browser on mobile
export const handleLogin = async () => {
  const loginUrl = getLoginUrl();
  
  if (Capacitor.isNativePlatform()) {
    // Open in system browser on mobile
    await Browser.open({ url: loginUrl });
  } else {
    // Regular redirect on web
    window.location.href = loginUrl;
  }
};
