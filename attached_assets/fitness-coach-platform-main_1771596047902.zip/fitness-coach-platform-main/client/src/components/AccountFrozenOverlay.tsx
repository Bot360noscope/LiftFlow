import { useState } from "react";
import { AlertTriangle, Crown, Shield, Sparkles, Zap, Users, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";

interface AccountFrozenOverlayProps {
  clientCount: number;
  originalPlan: string;
  userId: number;
  userEmail: string | null;
  onRemoveClients: () => void;
}

const PLAN_LABELS: Record<string, string> = {
  free: "Free",
  per_user: "Per User",
  per_user_10: "Pro 10",
  enterprise: "Enterprise",
};

export function AccountFrozenOverlay({
  clientCount,
  originalPlan,
  userId,
  userEmail,
  onRemoveClients,
}: AccountFrozenOverlayProps) {
  const handleUpgrade = (tier: string) => {
    const paymentUrl = new URL("https://liftflowpay.manus.space/pricing");
    paymentUrl.searchParams.set("userId", userId.toString());
    paymentUrl.searchParams.set("tier", tier);
    if (userEmail) {
      paymentUrl.searchParams.set("email", userEmail);
    }
    window.open(paymentUrl.toString(), "_blank");
  };

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-card border rounded-2xl shadow-2xl overflow-hidden">
        {/* Warning Header */}
        <div className="bg-destructive/10 border-b border-destructive/20 px-6 py-5 text-center">
          <div className="w-14 h-14 rounded-full bg-destructive/15 flex items-center justify-center mx-auto mb-3">
            <Lock className="h-7 w-7 text-destructive" />
          </div>
          <h2 className="text-xl font-bold text-foreground">Account Frozen</h2>
          <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">
            Your <strong>{PLAN_LABELS[originalPlan] || originalPlan}</strong> subscription has expired.
            You have <strong>{clientCount} clients</strong>, which exceeds the free tier limit of 1.
          </p>
        </div>

        {/* Action Area */}
        <div className="px-6 py-5 space-y-4">
          <p className="text-sm text-center text-muted-foreground">
            To continue using your coach dashboard, please either:
          </p>

          {/* Option 1: Upgrade */}
          <div className="space-y-2">
            <Button
              onClick={() => handleUpgrade("per_user_10")}
              className="w-full gap-2"
              size="lg"
            >
              <Sparkles className="h-4 w-4" />
              Renew Subscription
            </Button>
            <div className="flex gap-2">
              <Button
                onClick={() => handleUpgrade("per_user_10")}
                variant="outline"
                size="sm"
                className="flex-1 text-xs gap-1"
              >
                <Zap className="h-3 w-3 text-amber-500" />
                Pro 10 — $29/mo
              </Button>
              <Button
                onClick={() => handleUpgrade("enterprise")}
                variant="outline"
                size="sm"
                className="flex-1 text-xs gap-1"
              >
                <Shield className="h-3 w-3 text-violet-500" />
                Enterprise — $79/mo
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">or</span>
            </div>
          </div>

          {/* Option 2: Remove Clients */}
          <Button
            onClick={onRemoveClients}
            variant="ghost"
            className="w-full text-muted-foreground hover:text-foreground"
            size="sm"
          >
            <Users className="h-4 w-4 mr-2" />
            Remove clients to stay on Free tier
          </Button>

          <p className="text-[10px] text-center text-muted-foreground leading-relaxed">
            Your data is safe. No programs, clients, or videos have been deleted.
            Removing clients only unlinks them — their data remains intact.
          </p>
        </div>
      </div>
    </div>
  );
}
