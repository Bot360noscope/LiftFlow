import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Trash2, Plus, TrendingUp, Trophy } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface ProgressTrackerProps {
  clientId: number;
  coachId: number;
  readOnly?: boolean;
}

const LIFT_COLORS = {
  squat: "#ef4444",    // red
  deadlift: "#3b82f6", // blue
  bench: "#22c55e",    // green
};

const LIFT_LABELS = {
  squat: "Squat",
  deadlift: "Deadlift",
  bench: "Bench Press",
};

type LiftType = "squat" | "deadlift" | "bench";

export default function ProgressTracker({ clientId, coachId, readOnly = false }: ProgressTrackerProps) {
  const [newLiftType, setNewLiftType] = useState<LiftType>("squat");
  const [newWeight, setNewWeight] = useState("");
  const [newDate, setNewDate] = useState(new Date().toISOString().split("T")[0]);
  const [newNotes, setNewNotes] = useState("");

  const utils = trpc.useUtils();
  const { data: prs = [], isLoading } = trpc.liftPRs.list.useQuery({ clientId });

  const addPR = trpc.liftPRs.add.useMutation({
    onSuccess: () => {
      utils.liftPRs.list.invalidate({ clientId });
      setNewWeight("");
      setNewNotes("");
      toast.success("PR added!");
    },
    onError: () => toast.error("Failed to add PR"),
  });

  const deletePR = trpc.liftPRs.delete.useMutation({
    onSuccess: () => {
      utils.liftPRs.list.invalidate({ clientId });
      toast.success("PR deleted");
    },
    onError: () => toast.error("Failed to delete PR"),
  });

  // Transform data for the chart - merge all lifts into one timeline
  const chartData = useMemo(() => {
    if (!prs.length) return [];

    // Group by date, merge lift types
    const dateMap = new Map<string, Record<string, number>>();

    for (const pr of prs) {
      const dateStr = new Date(pr.date).toISOString().split("T")[0];
      if (!dateMap.has(dateStr)) {
        dateMap.set(dateStr, {});
      }
      const entry = dateMap.get(dateStr)!;
      // For deadlift, treat sumo and conventional as the same
      const liftKey = pr.liftType;
      const weight = parseFloat(pr.weight);
      // If multiple entries on same date for same lift, take the highest
      if (!entry[liftKey] || weight > entry[liftKey]) {
        entry[liftKey] = weight;
      }
    }

    // Sort by date and format
    const sorted = Array.from(dateMap.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, lifts]) => ({
        date: new Date(date).toLocaleDateString("en-GB", { day: "numeric", month: "short" }),
        rawDate: date,
        ...lifts,
      }));

    return sorted;
  }, [prs]);

  // Calculate current PRs (highest weight for each lift)
  const currentPRs = useMemo(() => {
    const best: Record<string, { weight: number; date: string }> = {};
    for (const pr of prs) {
      const w = parseFloat(pr.weight);
      if (!best[pr.liftType] || w > best[pr.liftType].weight) {
        best[pr.liftType] = { weight: w, date: new Date(pr.date).toISOString().split("T")[0] };
      }
    }
    return best;
  }, [prs]);

  const handleAddPR = () => {
    if (!newWeight || parseFloat(newWeight) <= 0) {
      toast.error("Please enter a valid weight");
      return;
    }
    addPR.mutate({
      clientId,
      coachId,
      liftType: newLiftType,
      weight: newWeight,
      date: newDate,
      notes: newNotes || undefined,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4">
      {/* Current PRs Summary */}
      <div className="grid grid-cols-3 gap-3">
        {(["squat", "deadlift", "bench"] as LiftType[]).map((lift) => (
          <Card key={lift} className="border-l-4" style={{ borderLeftColor: LIFT_COLORS[lift] }}>
            <CardContent className="p-3">
              <div className="flex items-center gap-1.5 mb-1">
                <Trophy className="h-3.5 w-3.5" style={{ color: LIFT_COLORS[lift] }} />
                <span className="text-xs font-medium text-muted-foreground">{LIFT_LABELS[lift]}</span>
              </div>
              <div className="text-xl font-bold">
                {currentPRs[lift] ? `${currentPRs[lift].weight} kg` : "—"}
              </div>
              {currentPRs[lift] && (
                <div className="text-[10px] text-muted-foreground">
                  {new Date(currentPRs[lift].date).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Weight Progression Chart */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Weight Progression
          </CardTitle>
        </CardHeader>
        <CardContent>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 11 }}
                  tickMargin={8}
                />
                <YAxis
                  tick={{ fontSize: 11 }}
                  tickMargin={8}
                  label={{ value: "kg", angle: -90, position: "insideLeft", style: { fontSize: 11 } }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                  formatter={(value: number, name: string) => [
                    `${value} kg`,
                    LIFT_LABELS[name as LiftType] || name,
                  ]}
                />
                <Legend
                  formatter={(value: string) => LIFT_LABELS[value as LiftType] || value}
                  wrapperStyle={{ fontSize: "12px" }}
                />
                <Line
                  type="monotone"
                  dataKey="squat"
                  stroke={LIFT_COLORS.squat}
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                  connectNulls
                  name="squat"
                />
                <Line
                  type="monotone"
                  dataKey="deadlift"
                  stroke={LIFT_COLORS.deadlift}
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                  connectNulls
                  name="deadlift"
                />
                <Line
                  type="monotone"
                  dataKey="bench"
                  stroke={LIFT_COLORS.bench}
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                  connectNulls
                  name="bench"
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <TrendingUp className="h-10 w-10 mb-3 opacity-30" />
              <p className="text-sm">No data yet</p>
              <p className="text-xs">Add your first PR below to start tracking</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add New PR Form */}
      {!readOnly && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Log Weight
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Lift</label>
                <select
                  value={newLiftType}
                  onChange={(e) => setNewLiftType(e.target.value as LiftType)}
                  className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
                >
                  <option value="squat">Squat</option>
                  <option value="deadlift">Deadlift / Sumo</option>
                  <option value="bench">Bench Press</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Weight (kg)</label>
                <Input
                  type="number"
                  placeholder="0"
                  value={newWeight}
                  onChange={(e) => setNewWeight(e.target.value)}
                  className="h-9"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Date</label>
                <Input
                  type="date"
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="h-9"
                />
              </div>
            </div>
            <div className="mt-3">
              <label className="text-xs text-muted-foreground mb-1 block">Notes (optional)</label>
              <Input
                placeholder="e.g. Sumo, paused..."
                value={newNotes}
                onChange={(e) => setNewNotes(e.target.value)}
                className="h-9"
              />
            </div>
            <Button
              onClick={handleAddPR}
              disabled={addPR.isPending || !newWeight}
              className="mt-3 w-full sm:w-auto"
              size="sm"
            >
              {addPR.isPending ? "Adding..." : "Add Entry"}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* PR History Table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">History</CardTitle>
        </CardHeader>
        <CardContent>
          {prs.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">Date</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">Lift</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">Weight</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">Notes</th>
                    {!readOnly && <th className="text-right py-2 px-2 text-xs font-medium text-muted-foreground"></th>}
                  </tr>
                </thead>
                <tbody>
                  {[...prs].reverse().map((pr) => (
                    <tr key={pr.id} className="border-b last:border-0 hover:bg-muted/50">
                      <td className="py-2 px-2 text-xs">
                        {new Date(pr.date).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                      </td>
                      <td className="py-2 px-2">
                        <span
                          className="text-xs font-medium px-2 py-0.5 rounded-full"
                          style={{
                            backgroundColor: `${LIFT_COLORS[pr.liftType as LiftType]}20`,
                            color: LIFT_COLORS[pr.liftType as LiftType],
                          }}
                        >
                          {LIFT_LABELS[pr.liftType as LiftType]}
                        </span>
                      </td>
                      <td className="py-2 px-2 text-xs font-semibold">{pr.weight} kg</td>
                      <td className="py-2 px-2 text-xs text-muted-foreground">{pr.notes || "—"}</td>
                      {!readOnly && (
                        <td className="py-2 px-2 text-right">
                          <button
                            onClick={() => deletePR.mutate({ id: pr.id })}
                            className="text-muted-foreground hover:text-destructive transition-colors"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground text-center py-4">No entries yet</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
