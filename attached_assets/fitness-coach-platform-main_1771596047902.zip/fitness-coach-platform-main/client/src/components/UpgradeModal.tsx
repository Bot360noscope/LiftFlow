import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Sparkles, Check } from "lucide-react";

interface UpgradeModalProps {
  open: boolean;
  onClose: () => void;
  currentClientCount: number;
  clientLimit: number;
  userId: number;
  userEmail: string | null;
}

export function UpgradeModal({ open, onClose, currentClientCount, clientLimit, userId, userEmail }: UpgradeModalProps) {
  const handleUpgrade = () => {
    // Redirect to external payment site with user info
    const paymentUrl = new URL("https://liftflowpay.manus.space/pricing");
    paymentUrl.searchParams.set("userId", userId.toString());
    if (userEmail) {
      paymentUrl.searchParams.set("email", userEmail);
    }
    window.open(paymentUrl.toString(), "_blank");
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
            <Sparkles className="h-6 w-6 text-primary" />
          </div>
          <DialogTitle className="text-center text-xl">Upgrade to Premium</DialogTitle>
          <DialogDescription className="text-center">
            You've reached your free client limit ({currentClientCount}/{clientLimit})
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-muted/50 rounded-lg p-4">
            <h3 className="font-semibold mb-3">Premium Benefits</h3>
            <ul className="space-y-2">
              {[
                "Unlimited clients",
                "Unlimited programs",
                "Priority support",
                "Advanced analytics",
              ].map((benefit) => (
                <li key={benefit} className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-primary shrink-0" />
                  <span>{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="text-center">
            <div className="text-2xl font-bold mb-1">$29<span className="text-base font-normal text-muted-foreground">/month</span></div>
            <p className="text-xs text-muted-foreground">Cancel anytime</p>
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Maybe Later
          </Button>
          <Button onClick={handleUpgrade} className="flex-1 gap-2">
            <Sparkles className="h-4 w-4" />
            Upgrade Now
          </Button>
        </div>

        <p className="text-xs text-center text-muted-foreground mt-2">
          You'll be redirected to our secure payment page
        </p>
      </DialogContent>
    </Dialog>
  );
}
