import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Video, Square, AlertCircle, Check, RotateCcw } from "lucide-react";
import { Capacitor } from "@capacitor/core";
import { FFmpeg } from "@ffmpeg/ffmpeg";
import { fetchFile, toBlobURL } from "@ffmpeg/util";

interface CameraRecorderProps {
  onVideoReady: (blob: Blob) => void;
  isUploading?: boolean;
}

export function CameraRecorder({ onVideoReady, isUploading = false }: CameraRecorderProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const previewVideoRef = useRef<HTMLVideoElement>(null);
  const previewStreamRef = useRef<MediaStream | null>(null);
  const recordingStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const animationRef = useRef<number | null>(null);
  const isDrawingRef = useRef(false);

  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [cameraReady, setCameraReady] = useState(false);
  const [permissionError, setPermissionError] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showTrimmer, setShowTrimmer] = useState(false);
  const [videoDuration, setVideoDuration] = useState(0);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(0);

  // Check if we're on a native mobile platform
  const isNativeMobile = Capacitor.isNativePlatform();

  // Canvas drawing loop (only for web)
  const startCanvasPreview = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) {
      console.error("Video or canvas ref missing in startCanvasPreview");
      return;
    }

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    isDrawingRef.current = true;

    const draw = () => {
      if (!isDrawingRef.current) return;

      const v = videoRef.current;
      const c = canvasRef.current;
      if (!v || !c) return;

      if (v.videoWidth && v.videoHeight) {
        if (c.width !== v.videoWidth || c.height !== v.videoHeight) {
          c.width = v.videoWidth;
          c.height = v.videoHeight;
        }
        ctx.drawImage(v, 0, 0, c.width, c.height);
      }

      animationRef.current = requestAnimationFrame(draw);
    };

    draw();
  };

  const stopCanvasPreview = () => {
    isDrawingRef.current = false;
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }
  };

  // Initialize camera when component mounts (web only)
  useEffect(() => {
    if (isNativeMobile) {
      // On mobile, we don't need preview - native camera handles it
      setCameraReady(true);
      return;
    }

    let mounted = true;

    const initCamera = async () => {
      try {
        // Get camera stream
        const previewStream = await navigator.mediaDevices.getUserMedia({
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 },
            facingMode: "environment",
          },
          audio: false,
        });

        if (!mounted) {
          previewStream.getTracks().forEach((t) => t.stop());
          return;
        }

        previewStreamRef.current = previewStream;

        const video = videoRef.current;
        if (!video) {
          console.error("videoRef is null after getUserMedia");
          return;
        }

        video.srcObject = previewStream;
        video.muted = true;
        video.playsInline = true;

        // Wait for video metadata to load
        await new Promise<void>((resolve) => {
          const onLoaded = () => {
            video.removeEventListener("loadedmetadata", onLoaded);
            resolve();
          };
          video.addEventListener("loadedmetadata", onLoaded);
          video.play().catch(() => resolve());
        });

        if (!mounted) return;

        // Now start drawing to canvas
        startCanvasPreview();
        setCameraReady(true);
      } catch (error) {
        console.error("Camera initialization error:", error);
        if (mounted) {
          setPermissionError(true);
        }
      }
    };

    initCamera();

    return () => {
      mounted = false;
      stopCanvasPreview();
      previewStreamRef.current?.getTracks().forEach((t) => t.stop());
      recordingStreamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, [isNativeMobile]);

  // Timer for recording
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime((t) => t + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  // Clean up preview URL when component unmounts or video changes
  useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  // Handle file selection on mobile
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('video/')) {
      setSelectedVideo(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
    // Reset the input so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Confirm and upload the selected video (with optional trimming)
  const handleConfirmVideo = async () => {
    if (!selectedVideo) return;

    // If trimming is enabled and user has adjusted the range
    if (showTrimmer && (trimStart > 0 || trimEnd < videoDuration)) {
      try {
        const ffmpeg = new FFmpeg();
        const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
        await ffmpeg.load({
          coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
          wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
        });

        // Write input file
        await ffmpeg.writeFile('input.webm', await fetchFile(selectedVideo));

        // Trim video
        await ffmpeg.exec([
          '-i', 'input.webm',
          '-ss', trimStart.toString(),
          '-to', trimEnd.toString(),
          '-c', 'copy',
          'output.webm'
        ]);

        // Read output file
        const data = await ffmpeg.readFile('output.webm');
        const trimmedBlob = new Blob([data as BlobPart], { type: 'video/webm' });

        onVideoReady(trimmedBlob);
      } catch (error) {
        console.error('Trimming error:', error);
        // Fallback to original video if trimming fails
        onVideoReady(selectedVideo);
      }
    } else {
      // No trimming, use original video
      onVideoReady(selectedVideo);
    }

    // Clean up
    setSelectedVideo(null);
    setShowTrimmer(false);
    setTrimStart(0);
    setTrimEnd(0);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
  };

  // Retake - clear selection and allow recording again
  const handleRetake = () => {
    setSelectedVideo(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    // Reset trimming state
    setShowTrimmer(false);
    setTrimStart(0);
    setTrimEnd(0);
    setVideoDuration(0);
    
    // Restart camera preview on web
    // After clearing selectedVideo, React will re-render and put the canvas back in the DOM.
    // We use requestAnimationFrame to wait for the DOM update, then re-attach stream and restart preview.
    if (!isNativeMobile && previewStreamRef.current) {
      const stream = previewStreamRef.current;
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          const video = videoRef.current;
          const canvas = canvasRef.current;
          if (video && canvas) {
            // Re-attach the preview stream to the hidden video element
            video.srcObject = stream;
            video.muted = true;
            video.playsInline = true;
            video.play().then(() => {
              startCanvasPreview();
            }).catch((err) => {
              console.error("Failed to restart video preview:", err);
            });
          }
        });
      });
    }
  };

  // Trigger file input on mobile
  const startRecordingNative = () => {
    fileInputRef.current?.click();
  };

  // Web recording using MediaRecorder
  const startRecordingWeb = async () => {
    try {
      const recordingStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: "environment",
        },
        audio: true,
      });

      recordingStreamRef.current = recordingStream;

      let mediaRecorder: MediaRecorder;
      try {
        mediaRecorder = new MediaRecorder(recordingStream, {
          mimeType: "video/webm;codecs=vp9,opus",
        });
      } catch {
        mediaRecorder = new MediaRecorder(recordingStream);
      }

      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "video/webm" });
        // Show preview instead of auto-uploading
        setSelectedVideo(blob);
        const url = URL.createObjectURL(blob);
        setPreviewUrl(url);
        chunksRef.current = [];
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
    } catch (error) {
      console.error("Recording error:", error);
      setPermissionError(true);
    }
  };

  const startRecording = async () => {
    if (isNativeMobile) {
      startRecordingNative();
    } else {
      await startRecordingWeb();
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      recordingStreamRef.current?.getTracks().forEach((t) => t.stop());
      recordingStreamRef.current = null;
      setIsRecording(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // On native mobile, show simplified UI with file picker
  if (isNativeMobile) {
    return (
      <div className="space-y-4 p-4">
        {/* Hidden file input for mobile video capture/selection */}
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          capture="environment"
          onChange={handleFileSelect}
          style={{ display: 'none' }}
        />

        {/* Show preview if video is selected */}
        {selectedVideo && previewUrl ? (
          <div className="space-y-4">
            <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
              <video
                ref={previewVideoRef}
                src={previewUrl}
                controls
                playsInline
                className="w-full h-full object-contain"
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleRetake}
                disabled={isUploading}
                variant="outline"
                className="flex-1"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Retake
              </Button>
              <Button
                onClick={handleConfirmVideo}
                disabled={isUploading}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                <Check className="w-4 h-4 mr-2" />
                Use This
              </Button>
            </div>
          </div>
        ) : (
          <>
            <div className="relative bg-black rounded-lg overflow-hidden aspect-video flex items-center justify-center">
              <div className="text-white text-center p-4">
                <Video className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Tap below to record or select a video</p>
                <p className="text-xs text-gray-400 mt-2">Your device's camera app will open</p>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={startRecording}
                disabled={isUploading}
                className="flex-1 bg-red-600 hover:bg-red-700"
              >
                <Video className="w-4 h-4 mr-2" />
                Record Video
              </Button>
            </div>
          </>
        )}

        {isUploading && (
          <div className="flex items-center justify-center p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
            <span className="text-sm text-blue-700">Uploading video...</span>
          </div>
        )}
      </div>
    );
  }

  // Web version with live preview
  return (
    <div className="space-y-4 p-4">
      {/* Hidden video element - ALWAYS in the DOM */}
      <video
        ref={videoRef}
        style={{ position: "absolute", width: 0, height: 0, opacity: 0, pointerEvents: "none" }}
        autoPlay
        playsInline
        muted
      />

      {/* Show preview if video is recorded */}
      {selectedVideo && previewUrl ? (
        <div className="space-y-4">
          <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
            <video
              ref={previewVideoRef}
              src={previewUrl}
              controls
              playsInline
              className="w-full h-full object-contain"
              onLoadedMetadata={(e) => {
                const duration = (e.target as HTMLVideoElement).duration;
                setVideoDuration(duration);
                setTrimEnd(duration);
              }}
            />
          </div>

          {/* Trimming controls */}
          {showTrimmer && videoDuration > 0 && (
            <div className="space-y-3 p-4 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Trim Video</span>
                <span className="text-xs text-muted-foreground">
                  {trimEnd - trimStart > 0 ? `${(trimEnd - trimStart).toFixed(1)}s` : '0s'}
                </span>
              </div>

              <div className="space-y-2">
                <div>
                  <label className="text-xs text-muted-foreground">Start: {trimStart.toFixed(1)}s</label>
                  <input
                    type="range"
                    min="0"
                    max={videoDuration}
                    step="0.1"
                    value={trimStart}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      if (val < trimEnd) setTrimStart(val);
                    }}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="text-xs text-muted-foreground">End: {trimEnd.toFixed(1)}s</label>
                  <input
                    type="range"
                    min="0"
                    max={videoDuration}
                    step="0.1"
                    value={trimEnd}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      if (val > trimStart) setTrimEnd(val);
                    }}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <Button
              onClick={handleRetake}
              disabled={isUploading}
              variant="outline"
              className="flex-1"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Retake
            </Button>
            <Button
              onClick={() => setShowTrimmer(!showTrimmer)}
              disabled={isUploading}
              variant="outline"
              className="flex-1"
            >
              Trim
            </Button>
            <Button
              onClick={handleConfirmVideo}
              disabled={isUploading}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              <Check className="w-4 h-4 mr-2" />
              Use This
            </Button>
          </div>

          {isUploading && (
            <div className="flex items-center justify-center p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
              <span className="text-sm text-blue-700">Uploading video...</span>
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Canvas for live preview - ALWAYS in the DOM */}
          <div className="relative bg-black rounded-lg overflow-hidden">
            <canvas
              ref={canvasRef}
              className="w-full aspect-video"
              style={{ display: "block" }}
            />

        {/* Loading overlay on top of canvas */}
        {!cameraReady && !permissionError && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/80">
            <div className="flex items-center gap-2 text-white">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
              <span>Initializing camera...</span>
            </div>
          </div>
        )}

        {/* Permission error overlay */}
        {permissionError && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/80">
            <div className="flex items-center gap-2 p-4 text-center">
              <AlertCircle className="w-5 h-5 text-red-400" />
              <div>
                <p className="font-semibold text-red-300">Camera Permission Denied</p>
                <p className="text-sm text-red-400">Please allow camera access</p>
              </div>
            </div>
          </div>
        )}

        {/* Recording indicator */}
        {isRecording && (
          <div className="absolute top-4 right-4 flex items-center gap-2 bg-red-600 text-white px-3 py-1 rounded-full">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span className="text-sm font-semibold">{formatTime(recordingTime)}</span>
          </div>
        )}
      </div>

      {/* Recording controls */}
      <div className="flex gap-2">
        {!isRecording ? (
          <Button
            onClick={startRecording}
            disabled={isUploading || !cameraReady}
            className="flex-1 bg-red-600 hover:bg-red-700"
          >
            <Video className="w-4 h-4 mr-2" />
            Start Recording
          </Button>
        ) : (
          <Button
            onClick={stopRecording}
            disabled={isUploading}
            className="flex-1 bg-red-600 hover:bg-red-700"
          >
            <Square className="w-4 h-4 mr-2" />
            Stop Recording
          </Button>
        )}
      </div>

      {isUploading && (
        <div className="flex items-center justify-center p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
          <span className="text-sm text-blue-700">Uploading video...</span>
        </div>
      )}
        </>
      )}
    </div>
  );
}
