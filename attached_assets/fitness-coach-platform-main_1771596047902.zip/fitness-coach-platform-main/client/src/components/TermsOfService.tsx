import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ReactNode } from "react";

interface TermsOfServiceProps {
  trigger: ReactNode;
}

export function TermsOfService({ trigger }: TermsOfServiceProps) {
  return (
    <Dialog>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh]">
        <DialogHeader>
          <DialogTitle className="text-xl">LiftFlow Terms of Service</DialogTitle>
          <DialogDescription>Last updated: February 2026</DialogDescription>
        </DialogHeader>
        <ScrollArea className="h-[65vh] pr-4">
          <div className="space-y-6 text-sm text-muted-foreground leading-relaxed">
            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">1. Acceptance of Terms</h3>
              <p>
                These Terms of Service ("Terms") govern your access to and use of LiftFlow (the "Service").
              </p>
              <p className="mt-2">
                LiftFlow is operated by Sam Albaayno, acting as an independent software developer.
              </p>
              <p className="mt-2">
                By accessing or using the Service, you agree to be bound by these Terms. If you do not agree, you may not access or use the Service. These Terms apply to all users, including coaches and clients.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">2. Description of the Service</h3>
              <p>
                LiftFlow is a fitness coaching platform that enables coaches and clients to manage training programs, track workout completion, share notes, upload and review form check videos, and communicate within the platform.
              </p>
              <p className="mt-2">
                LiftFlow is a technology platform only. We do not create workout programs, provide coaching advice, or supervise training. The Service is provided on an "as is" and "as available" basis.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">3. Eligibility</h3>
              <p>
                The Service is not intended for use by individuals under the age of 16.
              </p>
              <p className="mt-2">
                By using the Service, you confirm that you are at least 16 years old and legally capable of entering into these Terms.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">4. User Accounts</h3>
              <p>
                To access certain features, you must create an account through an authentication provider.
              </p>
              <p className="mt-2">You are responsible for:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Maintaining the confidentiality of your account credentials</li>
                <li>All activities that occur under your account</li>
              </ul>
              <p className="mt-2">
                You agree to notify us immediately of any unauthorized use of your account.
              </p>
              <p className="mt-2">Users may register as a coach, a client, or both.</p>
              <p className="mt-2">
                LiftFlow does not verify or guarantee the qualifications, certifications, or competence of any coach using the platform.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">5. User Roles and Responsibilities</h3>

              <h4 className="font-medium text-foreground mt-3 mb-1">5.1 Coaches</h4>
              <p>As a coach, you agree to:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Provide programming and guidance at your own professional discretion</li>
                <li>Respect client privacy</li>
                <li>Only access data shared with you through the platform</li>
                <li>Not distribute client content outside the platform without consent</li>
                <li>Comply with applicable laws and professional standards</li>
              </ul>
              <p className="mt-2">
                You acknowledge that you are solely responsible for the programs you create and the guidance you provide.
              </p>

              <h4 className="font-medium text-foreground mt-3 mb-1">5.2 Clients</h4>
              <p>As a client, you agree to:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Consult a qualified medical professional before starting any exercise program</li>
                <li>Exercise at your own risk and within your physical limits</li>
                <li>Provide accurate information about your fitness level</li>
                <li>Accept full responsibility for your training decisions</li>
              </ul>
              <p className="mt-2">
                You acknowledge that LiftFlow is not responsible for injuries, health complications, or outcomes related to workouts.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">6. Content and Intellectual Property</h3>
              <p>
                You retain ownership of all content you upload or create, including programs, videos, and notes.
              </p>
              <p className="mt-2">
                By uploading content, you grant LiftFlow a non-exclusive, worldwide, royalty-free license to store, process, and display such content solely for the purpose of operating the Service.
              </p>
              <p className="mt-2">
                You agree not to upload content that is unlawful, abusive, harmful, or inappropriate. LiftFlow reserves the right to remove content that violates these Terms.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">7. Video Content</h3>
              <p>The Service allows users to record and upload form check videos.</p>
              <p className="mt-2">By using this feature, you acknowledge that:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Videos are stored on secure cloud servers</li>
                <li>Videos are accessible only to you and connected users (e.g. your coach)</li>
                <li>You are responsible for the content you upload</li>
                <li>LiftFlow is not responsible for content shared outside the platform by other users</li>
              </ul>
              <p className="mt-2">
                You may delete your videos at any time through the Service.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">8. Subscriptions and Payments</h3>
              <p>
                Certain features of the Service may require a paid subscription.
              </p>
              <p className="mt-2">
                Payments for subscriptions are processed via Stripe on an external website. LiftFlow does not store payment card details.
              </p>

              <h4 className="font-medium text-foreground mt-3 mb-1">8.1 Subscription Tiers</h4>
              <p>The Service offers the following tiers:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li><strong>Free:</strong> 1 client, unlimited programs, video form checks</li>
                <li><strong>Pro 10:</strong> Up to 10 clients, priority support</li>
                <li><strong>Enterprise:</strong> Unlimited clients, dedicated support, advanced analytics</li>
              </ul>
              <p className="mt-2">
                Subscription plans, pricing, and usage limits are displayed outside the app and may change with reasonable notice.
              </p>

              <h4 className="font-medium text-foreground mt-3 mb-1">8.2 Subscription Expiry</h4>
              <p>
                Paid subscriptions have a defined duration. When a subscription expires:
              </p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Your account reverts to the Free tier limits</li>
                <li>If you have more clients than the Free tier allows (1 client), your coach account will be temporarily frozen</li>
                <li>While frozen, you cannot access your coach dashboard, create new programs, or accept new clients</li>
                <li>Your data (programs, clients, videos) is preserved and not deleted</li>
                <li>To restore access, you may either renew your subscription or remove clients to comply with the Free tier limit</li>
              </ul>
              <p className="mt-2">
                Failure to pay applicable fees may result in restricted access or account suspension as described above.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">9. Disclaimer of Medical and Fitness Advice</h3>
              <p>
                LiftFlow does not provide medical, health, or rehabilitation advice.
              </p>
              <p className="mt-2">
                The Service does not replace professional medical consultation, diagnosis, or treatment. Any fitness activities performed using the Service are undertaken at your own risk.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">10. Disclaimer of Warranties</h3>
              <p className="uppercase font-medium text-foreground">
                THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE," WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
              </p>
              <p className="mt-2">
                We do not guarantee that the Service will be uninterrupted, error-free, or secure.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">11. Limitation of Liability</h3>
              <p className="uppercase font-medium text-foreground">
                TO THE MAXIMUM EXTENT PERMITTED BY LAW, LIFTFLOW SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL, OR PUNITIVE DAMAGES, INCLUDING LOSS OF DATA, PROFITS, OR USE, ARISING FROM OR RELATED TO YOUR USE OF THE SERVICE.
              </p>
              <p className="mt-2">
                LiftFlow shall not be liable for injuries, health issues, or damages arising from workout programs created by coaches or performed by users.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">12. Account Termination</h3>
              <p>
                You may delete your account at any time using the in-app account deletion feature.
              </p>
              <p className="mt-2">
                LiftFlow reserves the right to suspend or terminate accounts that violate these Terms or misuse the Service.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">13. Changes to These Terms</h3>
              <p>
                We may update these Terms from time to time. Changes will be reflected by updating the "Last Updated" date.
              </p>
              <p className="mt-2">
                Your continued use of the Service after changes are posted constitutes acceptance of the revised Terms.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">14. Governing Law</h3>
              <p>
                These Terms shall be governed by and construed in accordance with the laws of England and Wales, without regard to conflict of law principles.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">15. Contact</h3>
              <p>
                If you have any questions about these Terms, you may contact:
              </p>
              <p className="mt-2 font-medium text-foreground">Sam Albaayno</p>
              <p className="font-medium text-foreground">Email: sambaayno@gmail.com</p>
            </section>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
