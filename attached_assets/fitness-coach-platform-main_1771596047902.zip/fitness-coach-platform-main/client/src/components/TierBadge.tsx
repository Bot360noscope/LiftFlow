import { useState } from "react";
import { Crown, Clock, CalendarClock, ExternalLink } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface PlanStatus {
  plan: string;
  originalPlan: string;
  clientCount: number;
  clientLimit: number | null;
  userCount?: number;
  isFrozen: boolean;
  isExpired: boolean;
  planExpiresAt: Date | string | null;
  daysRemaining: number | null;
}

interface TierBadgeProps {
  planStatus: PlanStatus;
  userId: number;
  userEmail: string | null;
}

export function TierBadge({ planStatus, userId, userEmail }: TierBadgeProps) {
  const [modalOpen, setModalOpen] = useState(false);

  const getPlanLabel = (plan: string): string => {
    switch (plan) {
      case "free":
        return "Free";
      case "starter":
        return "Starter";
      case "growth":
        return "Growth";
      case "professional":
        return "Professional";
      case "enterprise":
        return "Enterprise";
      default:
        return "Free";
    }
  };

  const formatTimeRemaining = (days: number | null): string => {
    if (days === null) return "";
    if (days === 0) return "Expires today";
    if (days === 1) return "1 day left";
    if (days < 30) return `${days} days left`;
    const months = Math.floor(days / 30);
    return months === 1 ? "1 month left" : `${months} months left`;
  };

  const formatExpiryDate = (date: Date | string | null): string => {
    if (!date) return "";
    const d = typeof date === "string" ? new Date(date) : date;
    return d.toLocaleDateString("en-US", { 
      year: "numeric", 
      month: "long", 
      day: "numeric" 
    });
  };

  const isPremium = planStatus.plan !== "free";
  const isExpired = planStatus.isExpired;
  const timeText = formatTimeRemaining(planStatus.daysRemaining);

  // Build badge text based on plan
  // Shows stacked total: e.g. "Per User 3/15" where 15 = 1 free + 14 purchased
  const getBadgeText = () => {
    if (isExpired) return "Expired";

    const label = getPlanLabel(planStatus.plan);

    // Show client count / limit for all plans except enterprise
    if (planStatus.clientLimit !== null) {
      return `${label} ${planStatus.clientCount}/${planStatus.clientLimit}`;
    }

    // For enterprise (unlimited), just show the label
    return label;
  };

  const handleUpgrade = () => {
    const paymentUrl = new URL("https://liftflowpay.manus.space/pricing");
    paymentUrl.searchParams.set("userId", userId.toString());
    if (userEmail) {
      paymentUrl.searchParams.set("email", userEmail);
    }
    window.open(paymentUrl.toString(), "_blank");
  };

  return (
    <>
      <button
        onClick={() => setModalOpen(true)}
        className={`
          flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium
          transition-all hover:scale-105 active:scale-95
          ${
            isExpired
              ? "bg-destructive/10 text-destructive border border-destructive/20"
              : isPremium
              ? "bg-gradient-to-r from-amber-500/10 to-orange-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20"
              : "bg-muted text-muted-foreground border border-border"
          }
        `}
      >
        {isPremium && !isExpired && <Crown className="h-3 w-3" />}
        <span className="font-semibold">{getBadgeText()}</span>
        {!isExpired && timeText && (
          <>
            <span className="opacity-50">·</span>
            <Clock className="h-3 w-3 opacity-70" />
            <span className="opacity-80">{timeText}</span>
          </>
        )}
      </button>

      {/* Plan Details Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl">Your Plan</DialogTitle>
            <DialogDescription className="text-center">
              {isExpired
                ? "Your subscription has expired"
                : "Current subscription details"
              }
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* Current Plan Info */}
            <div className={`rounded-lg px-4 py-4 ${
              isExpired 
                ? "bg-destructive/10 border border-destructive/20" 
                : "bg-muted/50"
            }`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  {isPremium && !isExpired && <Crown className="h-5 w-5 text-amber-500" />}
                  <div>
                    <h3 className="font-semibold text-lg">
                      {getPlanLabel(isExpired ? planStatus.originalPlan : planStatus.plan)}
                    </h3>
                    {isExpired && (
                      <p className="text-xs text-destructive mt-0.5">Expired</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                {/* Client Count */}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Clients</span>
                  <span className="font-medium">
                    {planStatus.clientCount}
                    {planStatus.clientLimit !== null && ` / ${planStatus.clientLimit}`}
                    {planStatus.clientLimit === null && " (unlimited)"}
                  </span>
                </div>

                {/* Expiry Date */}
                {planStatus.planExpiresAt && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {isExpired ? "Expired on" : "Expires on"}
                    </span>
                    <span className={`font-medium flex items-center gap-1.5 ${
                      isExpired ? "text-destructive" : ""
                    }`}>
                      <CalendarClock className="h-3.5 w-3.5" />
                      {formatExpiryDate(planStatus.planExpiresAt)}
                    </span>
                  </div>
                )}

                {/* Days Remaining */}
                {!isExpired && planStatus.daysRemaining !== null && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Time remaining</span>
                    <span className={`font-medium ${
                      planStatus.daysRemaining <= 7 ? "text-amber-600" : ""
                    }`}>
                      {timeText}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Upgrade Button */}
            <Button
              onClick={handleUpgrade}
              className="w-full"
              size="lg"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              {isExpired ? "Renew Subscription" : "Upgrade Plan"}
            </Button>

            {planStatus.plan === "free" && !isExpired && (
              <p className="text-xs text-center text-muted-foreground">
                Upgrade to add more clients and unlock premium features
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
