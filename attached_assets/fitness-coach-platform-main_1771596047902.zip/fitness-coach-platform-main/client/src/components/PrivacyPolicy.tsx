import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ReactNode } from "react";

interface PrivacyPolicyProps {
  trigger: ReactNode;
}

export function PrivacyPolicy({ trigger }: PrivacyPolicyProps) {
  return (
    <Dialog>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh]">
        <DialogHeader>
          <DialogTitle className="text-xl">LiftFlow Privacy Policy</DialogTitle>
          <DialogDescription>Last updated: February 2026</DialogDescription>
        </DialogHeader>
        <ScrollArea className="h-[65vh] pr-4">
          <div className="space-y-6 text-sm text-muted-foreground leading-relaxed">
            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">1. Introduction</h3>
              <p>
                LiftFlow ("we", "our", or "us") operates the LiftFlow fitness coaching platform (the "Service").
              </p>
              <p className="mt-2">
                LiftFlow is operated by Sam Albaayno, acting as an independent software developer. For the purposes of applicable data protection law, LiftFlow acts as the data controller of personal data collected through the Service.
              </p>
              <p className="mt-2">
                If you have any questions about this Privacy Policy or your data, you may contact us at:
              </p>
              <p className="mt-1 font-medium text-foreground">
                Email: sambaayno@gmail.com
              </p>
              <p className="mt-2">
                By using the Service, you agree to the collection and use of information in accordance with this Privacy Policy.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">2. Information We Collect</h3>

              <h4 className="font-medium text-foreground mt-3 mb-1">2.1 Personal Information</h4>
              <p>When you create an account, we collect:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Name and email address (via OAuth login)</li>
                <li>Profile information provided by your authentication provider</li>
                <li>Account role (coach or client)</li>
              </ul>

              <h4 className="font-medium text-foreground mt-3 mb-1">2.2 Fitness &amp; Training Data</h4>
              <p>When using the Service, we collect:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Workout programs created by coaches</li>
                <li>Exercise completion logs</li>
                <li>Personal records (e.g., squat, bench press, deadlift)</li>
                <li>Bodyweight and progression data</li>
                <li>Notes and comments between coaches and clients</li>
                <li>Rate of Perceived Exertion (RPE) ratings</li>
              </ul>

              <h4 className="font-medium text-foreground mt-3 mb-1">2.3 Video Content</h4>
              <p>When you upload or record videos through the Service:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Form check videos recorded or uploaded</li>
                <li>Video metadata (duration, file size, format)</li>
              </ul>
              <p className="mt-1">Videos are securely stored using Amazon S3 cloud infrastructure.</p>

              <h4 className="font-medium text-foreground mt-3 mb-1">2.4 Technical Data</h4>
              <p>We may automatically collect:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Device type and browser type</li>
                <li>IP address and approximate location</li>
                <li>Usage data and feature interactions</li>
                <li>Session cookies necessary for authentication</li>
              </ul>
              <p className="mt-2 font-medium text-foreground">We do not sell personal data.</p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">3. How We Use Your Information</h3>
              <p>We use collected information to:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Provide, operate, and maintain the Service</li>
                <li>Enable coach-client collaboration</li>
                <li>Store and display workout history and performance data</li>
                <li>Facilitate video uploads and review</li>
                <li>Manage subscriptions and account tiers</li>
                <li>Maintain security and prevent fraud</li>
                <li>Comply with legal obligations</li>
              </ul>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">4. Legal Basis for Processing (UK GDPR / EU GDPR)</h3>
              <p>We process personal data under the following lawful bases:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li><span className="font-medium text-foreground">Performance of a contract</span> – to provide the Service you register for.</li>
                <li><span className="font-medium text-foreground">Legitimate interests</span> – to improve, secure, and operate the Service.</li>
                <li><span className="font-medium text-foreground">Legal obligation</span> – where required by applicable law.</li>
                <li><span className="font-medium text-foreground">Consent</span> – for optional permissions such as camera and microphone access.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">5. Data Sharing &amp; Disclosure</h3>

              <h4 className="font-medium text-foreground mt-3 mb-1">5.1 Coach-Client Functionality</h4>
              <p>
                When you connect with a coach or client, relevant training data is shared between connected parties as part of the Service functionality.
              </p>

              <h4 className="font-medium text-foreground mt-3 mb-1">5.2 Third-Party Service Providers</h4>
              <p>We use trusted third-party providers to operate the Service, including:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Authentication provider (OAuth)</li>
                <li>Amazon S3 (cloud storage for videos and files)</li>
                <li>TiDB (database infrastructure)</li>
                <li>Stripe (payment processing via external website only)</li>
                <li>Hosting and infrastructure providers</li>
              </ul>
              <p className="mt-2">
                Payments are processed securely via Stripe on our external website. LiftFlow does not store full payment card details.
              </p>

              <h4 className="font-medium text-foreground mt-3 mb-1">5.3 Legal Requirements</h4>
              <p>
                We may disclose personal information if required by law or in response to valid legal requests.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">6. Data Storage &amp; Security</h3>
              <p>
                Personal data is stored on secure servers using encryption in transit (HTTPS/TLS). Video files are stored with access controls and encryption.
              </p>
              <p className="mt-2">
                While we implement industry-standard safeguards, no system can guarantee absolute security.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">7. Data Retention</h3>
              <p>
                We retain personal data while your account is active.
              </p>
              <p className="mt-2">
                You may delete your account at any time from within the app's Settings section. Account deletion permanently removes associated personal data, including:
              </p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Workout programs</li>
                <li>Client connections</li>
                <li>Videos</li>
                <li>Personal records</li>
                <li>Account information</li>
              </ul>
              <p className="mt-2">
                Backup copies may remain for up to 30 days before permanent deletion.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">8. Your Data Protection Rights</h3>
              <p>Under applicable data protection laws, you have the right to:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Access your personal data</li>
                <li>Correct inaccurate data</li>
                <li>Request deletion of your data</li>
                <li>Request data portability</li>
                <li>Restrict processing</li>
                <li>Object to processing</li>
                <li>Withdraw consent at any time</li>
              </ul>
              <p className="mt-2">
                To exercise your rights, use the in-app account deletion feature or contact:
              </p>
              <p className="mt-1 font-medium text-foreground">sambaayno@gmail.com</p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">9. Cookies &amp; Tracking</h3>
              <p>
                We use essential cookies for authentication and security purposes. These are necessary for the Service to function.
              </p>
              <p className="mt-2">
                We do not use advertising cookies or sell personal data.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">10. Children's Privacy</h3>
              <p>
                The Service is not intended for individuals under the age of 16. We do not knowingly collect personal data from children under 16.
              </p>
              <p className="mt-2">
                If we become aware that such data has been collected, we will take steps to delete it.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">11. Camera &amp; Microphone Usage</h3>
              <p>
                The app may request access to your device's camera and microphone solely for recording form check videos when initiated by you.
              </p>
              <p className="mt-2">
                Permissions can be revoked at any time through your device settings.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">12. Changes to This Policy</h3>
              <p>
                We may update this Privacy Policy from time to time. Updates will be posted with a revised "Last Updated" date.
              </p>
            </section>

            <section>
              <h3 className="text-base font-semibold text-foreground mb-2">13. Contact</h3>
              <p>
                If you have questions about this Privacy Policy or your personal data, please contact:
              </p>
              <p className="mt-2 font-medium text-foreground">Sam Albaayno</p>
              <p className="font-medium text-foreground">Email: sambaayno@gmail.com</p>
            </section>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
